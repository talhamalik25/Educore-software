import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

// Pages
import LoginPage from '../pages/auth/Loginpage'
import SuperAdminLoginPage from '../pages/auth/SuperAdminLoginPage'
import SuperAdminDashboard from '../pages/superadmin/Dashboard'
import AdminDashboard from '../pages/admin/Dashboard'
import AdminStudents from '../pages/admin/Students'
import AdminFees from '../pages/admin/Fees'
import AdminUsers from '../pages/admin/Users'
import AdminNotifications from '../pages/admin/Notifications'
import AdminTimetable from '../pages/admin/Timetable'
import AdminResults from '../pages/admin/Results'
import AdminReportCards from '../pages/admin/ReportCards'
import SchoolSettings from '../pages/admin/SchoolSettings'
import AdminComplaints from '../pages/admin/Complaints'
import AdminAIAnalyzer from '../pages/admin/AIAnalyzer'
import TeacherDashboard from '../pages/teacher/Dashboard'
import TeacherAttendance from '../pages/teacher/Attendance'
import TeacherHomework from '../pages/teacher/Homework'
import TeacherTimetable from '../pages/teacher/Timetable'
import TeacherResults from '../pages/teacher/Results'
import TeacherComplaints from '../pages/teacher/Complaints'
import TeacherAIAnalyzer from '../pages/teacher/AIAnalyzer'
import TeacherReportCards from '../pages/teacher/ReportCards'
import ParentDashboard from '../pages/parent/Dashboard'
import ParentHomework from '../pages/parent/Homework'
import ParentResults from '../pages/parent/Results'
import ParentComplaints from '../pages/parent/Complaints'
import ParentAIReport from '../pages/parent/AIReport'
import ParentReportCard from '../pages/parent/ReportCard'
import ForgotPassword from '../pages/ForgotPassword'
import ResetPassword from '../pages/ResetPassword'

// Route Guards
import ProtectedRoute from './ProtectedRoute'
import RoleRoute from './RoleRoute'

const AppRouter = () => {
  const { user } = useAuth()

  return (
    <Routes>
      {/* Public Routes */}
      <Route
        path="/login"
        element={user ? <Navigate to="/dashboard" replace /> : <LoginPage />}
      />
      <Route
        path="/superadmin/login"
        element={user?.role === 'superadmin' ? <Navigate to="/superadmin/dashboard" replace /> : <SuperAdminLoginPage />}
      />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password/:token" element={<ResetPassword />} />

      {/* Protected Routes */}
      <Route element={<ProtectedRoute />}>
        {/* Smart Redirect based on role */}
        <Route
          path="/dashboard"
          element={
            user?.role === 'superadmin' ? <Navigate to="/superadmin/dashboard" replace /> :
            user?.role === 'admin' ? <Navigate to="/admin/dashboard" replace /> :
            user?.role === 'teacher' ? <Navigate to="/teacher/dashboard" replace /> :
            user?.role === 'parent' ? <Navigate to="/parent/dashboard" replace /> :
            <Navigate to="/login" replace />
          }
        />

        {/* SuperAdmin Routes */}
        <Route element={<RoleRoute allowedRoles={['superadmin']} />}>
          <Route path="/superadmin/dashboard" element={<SuperAdminDashboard />} />
        </Route>

        {/* Admin Routes */}
        <Route element={<RoleRoute allowedRoles={['admin']} />}>
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/students" element={<AdminStudents />} />
          <Route path="/admin/fees" element={<AdminFees />} />
          <Route path="/admin/users" element={<AdminUsers />} />
          <Route path="/admin/notifications" element={<AdminNotifications />} />
          <Route path="/admin/timetable" element={<AdminTimetable />} />
          <Route path="/admin/results" element={<AdminResults />} />
          <Route path="/admin/report-cards" element={<AdminReportCards />} />
          <Route path="/admin/school-settings" element={<SchoolSettings />} />
          <Route path="/admin/complaints" element={<AdminComplaints />} />
          <Route path="/admin/ai-analyzer" element={<AdminAIAnalyzer />} />
        </Route>


        {/* Teacher Routes */}
        <Route element={<RoleRoute allowedRoles={['teacher']} />}>
          <Route path="/teacher/dashboard" element={<TeacherDashboard />} />
          <Route path="/teacher/attendance" element={<TeacherAttendance />} />
          <Route path="/teacher/homework" element={<TeacherHomework />} />
          <Route path="/teacher/timetable" element={<TeacherTimetable />} />
          <Route path="/teacher/results" element={<TeacherResults />} />
          <Route path="/teacher/report-cards" element={<TeacherReportCards />} />
          <Route path="/teacher/complaints" element={<TeacherComplaints />} />
          <Route path="/teacher/ai-analyzer" element={<TeacherAIAnalyzer />} />
        </Route>

        {/* Parent Routes */}
        <Route element={<RoleRoute allowedRoles={['parent']} />}>
          <Route path="/parent/dashboard" element={<ParentDashboard />} />
          <Route path="/parent/homework" element={<ParentHomework />} />
          <Route path="/parent/results" element={<ParentResults />} />
          <Route path="/parent/report-card" element={<ParentReportCard />} />
          <Route path="/parent/complaints" element={<ParentComplaints />} />
          <Route path="/parent/ai-report" element={<ParentAIReport />} />
        </Route>
      </Route>

      {/* Default Fallback */}
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  )
}

export default AppRouter
