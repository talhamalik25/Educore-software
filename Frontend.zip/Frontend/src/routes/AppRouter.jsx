import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

// Pages
import LoginPage from '../pages/auth/Loginpage'
import SuperAdminLoginPage from '../pages/auth/SuperAdminLoginPage'
import SuperAdminDashboard from '../pages/superadmin/Dashboard'
import AdminDashboard from '../pages/admin/Dashboard'
import AdminStudents from '../pages/admin/Students'
import AdminFees from '../pages/admin/Fees'
import AdminUsers from '../pages/admin/Users'
import AdminNotifications from '../pages/admin/Notifications'
import TeacherDashboard from '../pages/teacher/Dashboard'
import TeacherAttendance from '../pages/teacher/Attendance'
import TeacherHomework from '../pages/teacher/Homework'
import ParentDashboard from '../pages/parent/Dashboard'
import ParentHomework from '../pages/parent/Homework'
import ForgotPassword from '../pages/ForgotPassword'
import ResetPassword from '../pages/ResetPassword'

// Route Guards
import ProtectedRoute from './ProtectedRoute'
import RoleRoute from './RoleRoute'

const AppRouter = () => {
  const { user } = useAuth()

  return (
    <Routes>
      {/* Public Routes */}
      <Route
        path="/login"
        element={user ? <Navigate to="/dashboard" replace /> : <LoginPage />}
      />
      <Route
        path="/superadmin/login"
        element={user?.role === 'superadmin' ? <Navigate to="/superadmin/dashboard" replace /> : <SuperAdminLoginPage />}
      />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password/:token" element={<ResetPassword />} />

      {/* Protected Routes */}
      <Route element={<ProtectedRoute />}>
        {/* Smart Redirect based on role */}
        <Route
          path="/dashboard"
          element={
            user?.role === 'superadmin' ? <Navigate to="/superadmin/dashboard" replace /> :
            user?.role === 'admin' ? <Navigate to="/admin/dashboard" replace /> :
            user?.role === 'teacher' ? <Navigate to="/teacher/dashboard" replace /> :
            user?.role === 'parent' ? <Navigate to="/parent/dashboard" replace /> :
            <Navigate to="/login" replace />
          }
        />

        {/* SuperAdmin Routes */}
        <Route element={<RoleRoute allowedRoles={['superadmin']} />}>
          <Route path="/superadmin/dashboard" element={<SuperAdminDashboard />} />
        </Route>

        {/* Admin Routes */}
        <Route element={<RoleRoute allowedRoles={['admin']} />}>
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/students" element={<AdminStudents />} />
          <Route path="/admin/fees" element={<AdminFees />} />
          <Route path="/admin/users" element={<AdminUsers />} />
          <Route path="/admin/notifications" element={<AdminNotifications />} />
        </Route>

        {/* Teacher Routes */}
        <Route element={<RoleRoute allowedRoles={['teacher']} />}>
          <Route path="/teacher/dashboard" element={<TeacherDashboard />} />
          <Route path="/teacher/attendance" element={<TeacherAttendance />} />
          <Route path="/teacher/homework" element={<TeacherHomework />} />
        </Route>

        {/* Parent Routes */}
        <Route element={<RoleRoute allowedRoles={['parent']} />}>
          <Route path="/parent/dashboard" element={<ParentDashboard />} />
          <Route path="/parent/homework" element={<ParentHomework />} />
        </Route>
      </Route>

      {/* Default Fallback */}
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  )
}

export default AppRouter
