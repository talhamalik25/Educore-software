import React from "react"
import { cn } from "../../lib/utils"

const Button = React.forwardRef(({ className, variant = "primary", size = "md", isLoading, children, ...props }, ref) => {
  const variants = {
    primary: "bg-primary-600 text-white shadow-glow hover:bg-primary-500 focus-visible:ring-primary-500",
    secondary: "bg-surface-elevated text-white border border-surface-border hover:bg-muted-800 focus-visible:ring-muted-700",
    outline: "bg-transparent border border-muted-700 text-muted-300 hover:border-muted-500 hover:text-white",
    ghost: "bg-transparent text-muted-400 hover:bg-white/5 hover:text-white",
    danger: "bg-accent-rose/10 border border-accent-rose/20 text-accent-rose hover:bg-accent-rose hover:text-white",
  }

  const sizes = {
    sm: "h-9 px-3 text-xs",
    md: "h-11 px-6 text-sm",
    lg: "h-14 px-8 text-base",
  }

  return (
    <button
      ref={ref}
      disabled={isLoading}
      className={cn(
        "inline-flex items-center justify-center rounded-2xl font-bold uppercase tracking-wider transition-all duration-300 active:scale-95 disabled:opacity-50 disabled:pointer-events-none focus:outline-none focus-visible:ring-2",
        variants[variant],
        sizes[size],
        className
      )}
      {...props}
    >
      {isLoading ? (
        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-current" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
        </svg>
      ) : null}
      {children}
    </button>
  )
})

Button.displayName = "Button"

export default Button
