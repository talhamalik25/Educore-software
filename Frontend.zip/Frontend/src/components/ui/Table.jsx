import React from "react"
import { cn } from "../../lib/utils"

const Table = ({ children, className, ...props }) => (
  <div className="w-full overflow-x-auto rounded-[2rem] border border-surface-border bg-surface-elevated shadow-saas">
    <table className={cn("w-full text-left border-collapse", className)} {...props}>
      {children}
    </table>
  </div>
)

const TableHeader = ({ children, className, ...props }) => (
  <thead className={cn("bg-muted-950/50 border-b border-surface-border", className)} {...props}>
    {children}
  </thead>
)

const TableBody = ({ children, className, ...props }) => (
  <tbody className={cn("divide-y divide-surface-border", className)} {...props}>
    {children}
  </tbody>
)

const TableHead = ({ children, className, ...props }) => (
  <th className={cn("px-6 py-5 text-muted-500 text-[10px] font-black uppercase tracking-[0.2em]", className)} {...props}>
    {children}
  </th>
)

const TableRow = ({ children, className, ...props }) => (
  <tr className={cn("group hover:bg-white/[0.02] transition-colors duration-200", className)} {...props}>
    {children}
  </tr>
)

const TableCell = ({ children, className, ...props }) => (
  <td className={cn("px-6 py-5 text-sm font-medium text-muted-300", className)} {...props}>
    {children}
  </td>
)

export { Table, TableHeader, TableBody, TableHead, TableRow, TableCell }
