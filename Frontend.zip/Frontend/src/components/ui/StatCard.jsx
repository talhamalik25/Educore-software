import React from "react"
import { motion } from "framer-motion"
import { Card } from "./Card"
import { cn } from "../../lib/utils"
import { ArrowUpRight, ArrowDownRight } from "lucide-react"

const StatCard = ({ label, value, icon: Icon, trend, trendValue, color = "primary", loading }) => {
  const colors = {
    primary: "text-primary-400 bg-primary-500/10 border-primary-500/20",
    blue: "text-accent-blue bg-accent-blue/10 border-accent-blue/20",
    purple: "text-accent-purple bg-accent-purple/10 border-accent-purple/20",
    amber: "text-accent-amber bg-accent-amber/10 border-accent-amber/20",
    rose: "text-accent-rose bg-accent-rose/10 border-accent-rose/20",
  }

  return (
    <Card className="group relative overflow-hidden transition-all duration-500 hover:scale-[1.02] hover:shadow-saas-heavy active:scale-[0.98]">
      {loading ? (
        <div className="h-24 animate-pulse bg-white/5 rounded-2xl" />
      ) : (
        <>
          <div className="flex items-center justify-between mb-6">
            <div className={cn("p-4 rounded-2xl border transition-transform duration-500 group-hover:rotate-6", colors[color])}>
              {Icon && <Icon size={24} strokeWidth={2.5} />}
            </div>
            {trend && (
              <div className={cn(
                "flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black tracking-widest uppercase",
                trend === 'up' ? "bg-primary-500/10 text-primary-400" : "bg-accent-rose/10 text-accent-rose"
              )}>
                {trend === 'up' ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                {trendValue}%
              </div>
            )}
          </div>
          
          <h3 className="text-4xl font-syne font-bold text-white tracking-tighter mb-1.5 whitespace-nowrap">
            {value}
          </h3>
          <p className="text-muted-500 text-xs font-bold uppercase tracking-[0.2em]">
            {label}
          </p>

          <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-white/5 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
        </>
      )}
    </Card>
  )
}

export default StatCard
