import React from "react"
import { cn } from "../../lib/utils"

const Badge = ({ className, variant = "default", children, ...props }) => {
  const variants = {
    default: "bg-muted-800 text-muted-400 border-muted-700",
    success: "bg-primary-500/10 text-primary-400 border-primary-500/20",
    warning: "bg-accent-amber/10 text-accent-amber border-accent-amber/20",
    danger: "bg-accent-rose/10 text-accent-rose border-accent-rose/20",
    info: "bg-accent-blue/10 text-accent-blue border-accent-blue/20",
  }

  return (
    <div
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-[10px] font-black uppercase tracking-widest transition-colors",
        variants[variant],
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}

export default Badge
