import React from "react"
import { cn } from "../../lib/utils"

const Card = ({ className, variant = "default", children, ...props }) => {
  const variants = {
    default: "bg-surface-elevated border-surface-border",
    glass: "glass-dark border-white/5",
    primary: "bg-primary-900/10 border-primary-500/20",
  }

  return (
    <div
      className={cn(
        "rounded-[2rem] border p-6 shadow-saas transition-all duration-300",
        variants[variant],
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}

const CardHeader = ({ className, children, ...props }) => (
  <div className={cn("flex flex-col space-y-1.5 p-0 mb-6", className)} {...props}>
    {children}
  </div>
)

const CardContent = ({ className, children, ...props }) => (
  <div className={cn("p-0", className)} {...props}>
    {children}
  </div>
)

export { Card, CardHeader, CardContent }
