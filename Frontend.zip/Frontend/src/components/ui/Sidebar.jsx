import { useState } from 'react'
import { NavLink } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { 
  BarChart3, 
  Users, 
  Wallet, 
  UserCircle, 
  Bell, 
  BookOpen, 
  CheckSquare, 
  Home, 
  LogOut,
  ChevronLeft,
  ChevronRight,
  School,
  CalendarDays,
  MessageSquare,
  Sparkles,
  Award,
  Settings
} from 'lucide-react'
import { cn } from '../../lib/utils'

const adminLinks = [
  { to: '/admin/dashboard', label: 'Dashboard', icon: BarChart3 },
  { to: '/admin/students', label: 'Students', icon: UserCircle },
  { to: '/admin/fees', label: 'Fees', icon: Wallet },
  { to: '/admin/users', label: 'Staff Management', icon: Users },
  { to: '/admin/notifications', label: 'Notifications', icon: Bell },
  { to: '/admin/timetable', label: 'Timetable', icon: CalendarDays },
  { to: '/admin/results', label: 'Results & Analytics', icon: BarChart3 },
  { to: '/admin/report-cards', label: 'Report Cards', icon: Award },
  { to: '/admin/school-settings', label: 'School Settings', icon: Settings },
  { to: '/admin/complaints', label: 'Feedback Hub', icon: MessageSquare },
  { to: '/admin/ai-analyzer', label: 'AI Analyzer', icon: Sparkles },
]

const teacherLinks = [
  { to: '/teacher/dashboard', label: 'Dashboard', icon: BarChart3 },
  { to: '/teacher/attendance', label: 'Attendance', icon: CheckSquare },
  { to: '/teacher/homework', label: 'Homework', icon: BookOpen },
  { to: '/teacher/timetable', label: 'Timetable', icon: CalendarDays },
  { to: '/teacher/results', label: 'Results & Grading', icon: BarChart3 },
  { to: '/teacher/report-cards', label: 'Report Cards', icon: Award },
  { to: '/teacher/complaints', label: 'Support', icon: MessageSquare },
  { to: '/teacher/ai-analyzer', label: 'AI Analyzer', icon: Sparkles },
]

const parentLinks = [
  { to: '/parent/dashboard', label: 'Child Progress', icon: Home },
  { to: '/parent/homework', label: 'Homework', icon: BookOpen },
  { to: '/parent/results', label: 'Academic Results', icon: Award },
  { to: '/parent/report-card', label: 'Report Card', icon: Award },
  { to: '/parent/complaints', label: 'Feedback', icon: MessageSquare },
  { to: '/parent/ai-report', label: 'My Report', icon: Sparkles },
]

const superadminLinks = [
  { to: '/superadmin/dashboard', label: 'School Network', icon: School },
]

const Sidebar = () => {
  const { user, logout } = useAuth()
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [isMobileOpen, setIsMobileOpen] = useState(false)

  const links = user?.role === 'superadmin' ? superadminLinks :
                user?.role === 'teacher' ? teacherLinks :
                user?.role === 'parent' ? parentLinks :
                adminLinks

  return (
    <>
      {/* Mobile Toggle */}
      <div className="lg:hidden fixed top-6 left-6 z-50">
        <button
          onClick={() => setIsMobileOpen(!isMobileOpen)}
          className="p-3 bg-primary-600 text-white rounded-2xl shadow-glow"
        >
          <Home size={20} />
        </button>
      </div>

      {/* Sidebar Container */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 bg-surface-elevated border-r border-surface-border flex flex-col transition-all duration-500 ease-in-out lg:static",
          isCollapsed ? "w-24" : "w-72",
          isMobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {/* Header/Logo */}
        <div className="h-24 flex items-center px-8 border-b border-surface-border relative">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-10 h-10 shrink-0 bg-primary-600 rounded-xl flex items-center justify-center shadow-glow">
              <School className="text-white" size={20} strokeWidth={2.5} />
            </div>
            {!isCollapsed && (
              <motion.span 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="font-syne text-xl font-bold text-white tracking-tight"
              >
                EduCore
              </motion.span>
            )}
          </div>
          
          {/* Collapse Toggle (Desktop) */}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="hidden lg:flex absolute -right-4 top-1/2 -translate-y-1/2 w-8 h-8 bg-surface-elevated border border-surface-border rounded-full items-center justify-center text-muted-400 hover:text-white transition-colors z-50 shadow-saas"
          >
            {isCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto overflow-x-hidden pt-8">
          {links.map((link) => {
            const Icon = link.icon
            return (
              <NavLink
                key={link.to}
                to={link.to}
                onClick={() => setIsMobileOpen(false)}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-4 px-4 py-4 rounded-2xl transition-all duration-300 group relative",
                    isActive
                      ? "bg-primary-600/10 text-primary-400 font-bold"
                      : "text-muted-400 hover:bg-white/5 hover:text-white"
                  )
                }
              >
                <div className={cn(
                  "shrink-0 transition-transform duration-300 group-hover:scale-110",
                  "flex items-center justify-center"
                )}>
                  <Icon size={22} strokeWidth={isCollapsed ? 2.5 : 2} />
                </div>
                {!isCollapsed && (
                  <span className="text-sm tracking-wide whitespace-nowrap animate-fade-in">
                    {link.label}
                  </span>
                )}

                {/* Active Indicator */}
                <span className={cn(
                  "absolute left-0 w-1 bg-primary-600 rounded-r-full transition-all duration-300",
                  "opacity-0 h-0 group-[.active]:h-6 group-[.active]:opacity-100"
                )} />
              </NavLink>
            )
          })}
        </nav>

        {/* Footer / User Profile */}
        <div className="p-4 border-t border-surface-border">
          <button
            onClick={logout}
            className={cn(
              "w-full flex items-center transition-all duration-300 rounded-2xl mb-4",
              isCollapsed ? "justify-center p-4 bg-accent-rose/10 text-accent-rose hover:bg-accent-rose hover:text-white" : "gap-4 px-4 py-4 text-muted-400 hover:bg-accent-rose/10 hover:text-accent-rose"
            )}
          >
            <LogOut size={22} />
            {!isCollapsed && (
              <span className="text-sm font-bold uppercase tracking-widest">Logout System</span>
            )}
          </button>

          {!isCollapsed && (
            <div className="bg-surface-base rounded-[1.5rem] p-4 border border-white/5">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-600 text-center">
                System Version 4.2.0
              </p>
            </div>
          )}
        </div>
      </aside>

      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-md z-30 lg:hidden"
          onClick={() => setIsMobileOpen(false)}
        />
      )}
    </>
  )
}

// Add motion import inside if needed, though we can stick to Tailwind for this
import { motion } from 'framer-motion'

export default Sidebar
