import { useState } from 'react'
import { NavLink } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

const adminLinks = [
  { to: '/admin/dashboard', label: 'Dashboard', icon: '📊' },
  { to: '/admin/students', label: 'Students', icon: '🎓' },
  { to: '/admin/fees', label: 'Fees', icon: '💰' },
  { to: '/admin/users', label: 'Staff', icon: '👥' },
  { to: '/admin/notifications', label: 'Notifications', icon: '🔔' },
]

const teacherLinks = [
  { to: '/teacher/dashboard', label: 'Dashboard', icon: '📊' },
  { to: '/teacher/attendance', label: 'Attendance', icon: '✅' },
]

const parentLinks = [
  { to: '/parent/dashboard', label: 'Dashboard', icon: '👨‍👩‍👦' },
]

const superadminLinks = [
  { to: '/superadmin/dashboard', label: 'Schools', icon: '🏫' },
]

const Sidebar = () => {
  const { user, logout } = useAuth()
  const [isOpen, setIsOpen] = useState(false)

  const links = user?.role === 'superadmin' ? superadminLinks :
                user?.role === 'teacher' ? teacherLinks :
                user?.role === 'parent' ? parentLinks :
                adminLinks

  return (
    <>
      {/* Mobile Header (Dark) */}
      <div className="lg:hidden flex items-center justify-between px-4 py-3 bg-muted-800 border-b border-muted-700 sticky top-0 z-50">
        <h1 className="font-syne text-xl font-bold text-primary-400 mt-2">EduCore</h1>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="p-2 -mr-2 text-muted-400 hover:text-primary-400 transition-colors"
        >
          {isOpen ? (
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          ) : (
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
            </svg>
          )}
        </button>
      </div>

      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Aside (Reverted to Dark) */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-muted-800 border-r border-muted-700 flex flex-col transition-transform duration-300 transform lg:translate-x-0 lg:static lg:inset-0 ${isOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
      >
        {/* Logo (Desktop) */}
        <div className="hidden lg:block p-8 border-b border-muted-700/50">
          <h1 className="font-syne text-2xl font-bold text-primary-400 flex items-center gap-2">
            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
            </svg>
            EduCore
          </h1>
          <p className="text-muted-500 text-[10px] mt-1.5 font-bold uppercase tracking-[0.2em]">
            {user?.role} Portal
          </p>
        </div>

        {/* Mobile Header Link */}
        <div className="lg:hidden p-8 border-b border-muted-700/50 text-center">
          <h1 className="font-syne text-xl font-bold text-primary-400 font-syne uppercase tracking-wider">EduCore</h1>
          <p className="text-muted-500 text-xs mt-1 capitalize">{user?.role} Portal</p>
        </div>

        {/* Nav Links */}
        <nav className="flex-1 p-6 space-y-1 overflow-y-auto">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              onClick={() => setIsOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-5 py-4 rounded-2xl text-sm transition-all duration-300 ${isActive
                  ? 'bg-primary-500/10 text-primary-400 font-bold shadow-[0_0_20px_rgba(16,185,129,0.05)] ring-1 ring-primary-500/20'
                  : 'text-muted-400 hover:bg-muted-700 hover:text-white'
                }`
              }
            >
              <span className="text-lg">{link.icon}</span>
              {link.label}
            </NavLink>
          ))}
        </nav>

        {/* User + Logout */}
        <div className="p-6 border-t border-muted-700/50 mt-auto">
          <div className="flex items-center gap-3 mb-5 bg-muted-900/50 rounded-2xl p-4 border border-muted-700/30">
            <div className="w-10 h-10 shrink-0 rounded-xl bg-primary-500/10 flex items-center justify-center text-primary-400 font-black text-lg shadow-inner">
              {user?.name?.charAt(0)?.toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white text-sm font-bold truncate leading-tight">{user?.name}</p>
              <p className="text-muted-500 text-[10px] uppercase font-bold tracking-wider truncate mt-0.5">{user?.role}</p>
            </div>
          </div>
          <button
            onClick={logout}
            className="w-full flex items-center justify-center gap-2 text-muted-400 hover:text-red-400 hover:bg-red-500/10 text-xs font-bold uppercase tracking-widest px-4 py-3 rounded-2xl transition-all duration-300 border border-transparent hover:border-red-500/20 active:scale-95 cursor-pointer"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
            </svg>
            Logout
          </button>
        </div>
      </aside>
    </>
  )
}

export default Sidebar
