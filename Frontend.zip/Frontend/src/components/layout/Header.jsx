import React from "react"
import { useAuth } from "../../context/AuthContext"
import { Bell, Search, User, LogOut, Settings } from "lucide-react"
import Button from "../ui/Button"
import Badge from "../ui/Badge"

const Header = () => {
  const { user, logout } = useAuth()

  return (
    <header className="h-24 px-8 flex items-center justify-between border-b border-surface-border glass sticky top-0 z-40">
      <div className="flex-1 max-w-xl">
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-500 group-focus-within:text-primary-500 transition-colors" size={18} />
          <input
            type="text"
            placeholder="Search students, records, or tools..."
            className="w-full bg-surface-base border border-surface-border rounded-2xl py-3 pl-12 pr-4 text-sm text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20 transition-all shadow-inner"
          />
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" className="relative p-2 h-auto rounded-xl">
            <Bell size={20} className="text-muted-400" />
            <span className="absolute top-1 right-1 w-2h-2 rounded-full bg-accent-rose shadow-[0_0_10px_rgba(244,63,94,0.5)] border-2 border-surface-elevated h-2 w-2" />
          </Button>
          <Button variant="ghost" size="sm" className="p-2 h-auto rounded-xl">
            <Settings size={20} className="text-muted-400" />
          </Button>
        </div>

        <div className="h-8 w-[1px] bg-surface-border mx-2" />

        <div className="flex items-center gap-4 group cursor-pointer">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-bold text-white leading-tight">{user?.name}</p>
            <Badge variant="info" className="mt-1 lowercase">{user?.role}</Badge>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-primary-600/10 border border-primary-500/20 flex items-center justify-center text-primary-400 shadow-glow group-hover:bg-primary-600 group-hover:text-white transition-all duration-300">
            <User size={22} strokeWidth={2.5} />
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header
