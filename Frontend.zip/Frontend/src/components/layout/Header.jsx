import React, { useState, useEffect, useRef } from "react"
import { useNavigate, Link } from "react-router-dom"
import { useAuth } from "../../context/AuthContext"
import { 
  Bell, 
  Search, 
  User, 
  LogOut, 
  Settings, 
  Key, 
  Shield, 
  UserX, 
  Clock, 
  Wallet, 
  CheckCircle, 
  BookOpen, 
  Loader2 
} from "lucide-react"
import Button from "../ui/Button"
import Badge from "../ui/Badge"
import axiosInstance from "../../api/axiosInstance"
import { cn } from "../../lib/utils"

const Header = () => {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  
  // Notification State
  const [showNotifications, setShowNotifications] = useState(false)
  const [notifications, setNotifications] = useState([])
  const [notiLoading, setNotiLoading] = useState(false)
  const notificationsRef = useRef(null)

  // Settings State
  const [showSettings, setShowSettings] = useState(false)
  const settingsRef = useRef(null)

  // Fetch Notifications
  const fetchNotifications = async () => {
    setNotiLoading(true)
    try {
      const response = await axiosInstance.get('/notifications')
      const data = response.data.data || response.data
      setNotifications(Array.isArray(data) ? data.slice(0, 10) : [])
    } catch (error) {
      console.error("Error fetching notifications:", error)
    } finally {
      setNotiLoading(false)
    }
  }

  // Handle Bell Click
  const handleBellClick = () => {
    if (!showNotifications) {
      fetchNotifications()
    }
    setShowNotifications(!showNotifications)
    setShowSettings(false)
  }

  // Handle Click Outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (notificationsRef.current && !notificationsRef.current.contains(event.target)) {
        setShowNotifications(false)
      }
      if (settingsRef.current && !settingsRef.current.contains(event.target)) {
        setShowSettings(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  // Helper: Format Time Ago
  const formatTimeAgo = (dateString) => {
    if (!dateString) return ''
    const date = new Date(dateString)
    const now = new Date()
    const diffInSeconds = Math.floor((now - date) / 1000)
    
    if (diffInSeconds < 60) return 'just now'
    
    const diffInMinutes = Math.floor(diffInSeconds / 60)
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`
    
    const diffInHours = Math.floor(diffInMinutes / 60)
    if (diffInHours < 24) return `${diffInHours}h ago`
    
    const diffInDays = Math.floor(diffInHours / 24)
    if (diffInDays < 7) return `${diffInDays}d ago`
    
    return date.toLocaleDateString()
  }

  // Helper: Get Notification Icon/Color
  const getNotificationConfig = (type) => {
    switch (type) {
      case 'attendance_absent':
        return { icon: UserX, color: 'text-accent-rose', bg: 'bg-accent-rose/10' }
      case 'attendance_late':
        return { icon: Clock, color: 'text-amber-500', bg: 'bg-amber-500/10' }
      case 'fee_reminder':
        return { icon: Wallet, color: 'text-blue-500', bg: 'bg-blue-500/10' }
      case 'fee_received':
        return { icon: CheckCircle, color: 'text-emerald-500', bg: 'bg-emerald-500/10' }
      case 'homework_assigned':
        return { icon: BookOpen, color: 'text-purple-500', bg: 'bg-purple-500/10' }
      default:
        return { icon: Bell, color: 'text-primary-400', bg: 'bg-primary-400/10' }
    }
  }

  return (
    <header className="h-24 px-8 flex items-center justify-between border-b border-surface-border glass sticky top-0 z-40">
      <div className="flex-1 max-w-xl">
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-500 group-focus-within:text-primary-500 transition-colors" size={18} />
          <input
            type="text"
            placeholder="Search students, records, or tools..."
            className="w-full bg-surface-base border border-surface-border rounded-2xl py-3 pl-12 pr-4 text-sm text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20 transition-all shadow-inner"
          />
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          {/* Notifications Bell */}
          <div className="relative" ref={notificationsRef}>
            <Button 
              variant="ghost" 
              size="sm" 
              className="relative p-2 h-auto rounded-xl"
              onClick={handleBellClick}
            >
              <Bell size={20} className={cn("transition-colors", showNotifications ? "text-primary-400" : "text-muted-400")} />
              {notifications.length > 0 && (
                <span className="absolute top-1 right-1 w-2h-2 rounded-full bg-accent-rose shadow-[0_0_10px_rgba(244,63,94,0.5)] border-2 border-surface-elevated h-2 w-2" />
              )}
            </Button>

            {/* Notifications Dropdown */}
            {showNotifications && (
              <div className="absolute top-full mt-2 right-0 w-[380px] bg-surface-elevated border border-surface-border rounded-2xl shadow-2xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-300">
                <div className="p-4 border-b border-surface-border flex items-center justify-between bg-white/[0.02]">
                  <h3 className="font-syne font-bold text-white">Notifications</h3>
                  <button 
                    onClick={() => {
                      setShowNotifications(false)
                      navigate('/admin/notifications')
                    }}
                    className="text-xs text-primary-400 hover:text-primary-300 transition-colors font-medium"
                  >
                    View All
                  </button>
                </div>

                <div className="max-h-[400px] overflow-y-auto">
                  {notiLoading ? (
                    <div className="py-12 flex flex-col items-center justify-center gap-3">
                      <Loader2 className="text-primary-500 animate-spin" size={24} />
                      <p className="text-xs text-muted-500">Loading notifications...</p>
                    </div>
                  ) : notifications.length > 0 ? (
                    <div className="divide-y divide-surface-border">
                      {notifications.map((noti) => {
                        const { icon: NotiIcon, color, bg } = getNotificationConfig(noti.type)
                        return (
                          <div key={noti._id} className="p-4 hover:bg-white/[0.03] transition-colors flex gap-4">
                            <div className={cn("w-10 h-10 rounded-full flex items-center justify-center shrink-0", bg)}>
                              <NotiIcon size={18} className={color} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm text-white mb-0.5">
                                <span className="font-bold">{noti.studentName || 'Student'}</span>
                              </p>
                              <p className="text-xs text-muted-400 truncate pr-4">
                                {noti.message}
                              </p>
                              <div className="flex items-center gap-2 mt-2">
                                <span className="text-[10px] text-muted-500 uppercase tracking-wider">{formatTimeAgo(noti.createdAt)}</span>
                                <span className={cn(
                                  "w-1.5 h-1.5 rounded-full",
                                  noti.status === 'sent' ? 'bg-emerald-500' :
                                  noti.status === 'failed' ? 'bg-accent-rose' : 'bg-amber-500 shadow-glow-amber'
                                )} />
                              </div>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  ) : (
                    <div className="py-12 flex flex-col items-center justify-center text-center">
                      <div className="w-12 h-12 rounded-full bg-surface-base flex items-center justify-center mb-3">
                        <Bell className="text-muted-600" size={20} />
                      </div>
                      <p className="text-sm text-muted-400">🔔 No notifications yet</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Quick Settings */}
          <div className="relative" ref={settingsRef}>
            <Button 
              variant="ghost" 
              size="sm" 
              className="p-2 h-auto rounded-xl"
              onClick={() => {
                setShowSettings(!showSettings)
                setShowNotifications(false)
              }}
            >
              <Settings size={20} className={cn("transition-colors", showSettings ? "text-primary-400" : "text-muted-400")} />
            </Button>

            {showSettings && (
              <div className="absolute top-full mt-2 right-0 w-[220px] bg-surface-elevated border border-surface-border rounded-2xl shadow-2xl p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-300">
                <div className="space-y-1">
                  {user?.role === 'admin' && (
                    <button
                      onClick={() => {
                        setShowSettings(false)
                        navigate('/admin/school-settings')
                      }}
                      className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 text-muted-300 hover:text-white transition-all group"
                    >
                      <Settings size={16} className="group-hover:rotate-45 transition-transform" />
                      <span className="text-sm font-medium">School Settings</span>
                    </button>
                  )}
                  
                  <button
                    onClick={() => {
                      setShowSettings(false)
                      navigate('/forgot-password')
                    }}
                    className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 text-muted-300 hover:text-white transition-all"
                  >
                    <Key size={16} />
                    <span className="text-sm font-medium">Change Password</span>
                  </button>

                  <div className="h-[1px] bg-surface-border my-1 mx-2" />

                  <button
                    onClick={() => {
                      setShowSettings(false)
                      logout()
                    }}
                    className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-accent-rose/10 text-muted-400 hover:text-accent-rose transition-all"
                  >
                    <LogOut size={16} />
                    <span className="text-sm font-bold uppercase tracking-widest text-[10px]">Logout</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="h-8 w-[1px] bg-surface-border mx-2" />

        <div className="flex items-center gap-4 group cursor-pointer" onClick={() => setShowSettings(!showSettings)}>
          <div className="text-right hidden sm:block">
            <p className="text-sm font-bold text-white leading-tight">{user?.name}</p>
            <Badge variant="info" className="mt-1 lowercase">{user?.role}</Badge>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-primary-600/10 border border-primary-500/20 flex items-center justify-center text-primary-400 shadow-glow group-hover:bg-primary-600 group-hover:text-white transition-all duration-300">
            <User size={22} strokeWidth={2.5} />
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header
