import React from "react"
import { motion, AnimatePresence } from "framer-motion"
import Sidebar from "../ui/Sidebar"
import Header from "./Header"

const DashboardLayout = ({ children }) => {
  return (
    <div className="flex min-h-screen bg-surface-base text-muted-100 selection:bg-primary-500/30">
      {/* SaaS Sidebar */}
      <Sidebar />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        
        <main className="flex-1 p-6 lg:p-10 overflow-x-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>

        <footer className="px-10 py-6 border-t border-surface-border text-center">
          <p className="text-[10px] font-black uppercase tracking-[0.3em] text-muted-600">
            © 2026 EduCore AI Platform — Secure SaaS Education Environment
          </p>
        </footer>
      </div>
    </div>
  )
}

export default DashboardLayout
