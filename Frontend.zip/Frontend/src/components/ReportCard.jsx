import React from 'react';
import { cn } from '../lib/utils';

const ReportCard = ({ student, school, results, summary, examType }) => {
  if (!student || !school || !results) return null;

  const getGradeColor = (grade) => {
    switch (grade) {
      case 'A+': return 'text-green-800';
      case 'A': return 'text-green-600';
      case 'B': return 'text-blue-600';
      case 'C': return 'text-yellow-600';
      case 'D': return 'text-orange-600';
      case 'F': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="report-card bg-white text-black p-8 md:p-12 shadow-2xl max-w-5xl mx-auto my-10 border border-gray-200">
      <style dangerouslySetInnerHTML={{ __html: `
        @media print {
          body * { visibility: hidden; }
          .report-card, .report-card * { visibility: visible; }
          .report-card { 
            position: absolute; 
            left: 0; 
            top: 0; 
            width: 100%; 
            padding: 0;
            margin: 0;
            box-shadow: none;
            border: none;
          }
          .no-print { display: none !important; }
        }
      `}} />

      {/* HEADER */}
      <header className="flex items-center justify-between border-b-4 border-[#00A896] pb-6 mb-8">
        <div className="flex items-center gap-6">
          {school.logoUrl && (
            <img src={school.logoUrl} alt="Logo" className="w-[60px] h-[60px] object-contain" />
          )}
          <div className="text-center md:text-left">
            <h1 className="text-2xl md:text-3xl font-bold uppercase tracking-tight">{school.name}</h1>
            <p className="text-sm text-gray-600">{school.city}</p>
            <p className="text-xs italic text-gray-500">{school.motto}</p>
          </div>
        </div>
        <div className="text-right">
          <div className="bg-[#00A896] text-white px-4 py-2 rounded-lg font-black uppercase tracking-widest text-sm mb-2">
            Report Card
          </div>
          <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">{examType || 'Overall Analysis'}</p>
        </div>
      </header>

      {/* STUDENT INFO SECTION */}
      <section className="bg-gray-50 rounded-2xl p-6 mb-8 grid grid-cols-1 md:grid-cols-2 gap-y-4 md:gap-x-12 border border-gray-100">
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-xs font-black uppercase tracking-widest text-gray-400">Student Name</span>
            <span className="text-sm font-bold">{student.name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs font-black uppercase tracking-widest text-gray-400">Roll Number</span>
            <span className="text-sm font-bold">{student.rollNumber}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs font-black uppercase tracking-widest text-gray-400">Class & Section</span>
            <span className="text-sm font-bold">{student.class} - {student.section}</span>
          </div>
        </div>
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-xs font-black uppercase tracking-widest text-gray-400">Exam Type</span>
            <span className="text-sm font-bold uppercase">{examType || 'Final Term'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs font-black uppercase tracking-widest text-gray-400">Academic Year</span>
            <span className="text-sm font-bold">{summary.academicYear || '2023-24'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs font-black uppercase tracking-widest text-gray-400">Date Generated</span>
            <span className="text-sm font-bold">{new Date().toLocaleDateString()}</span>
          </div>
        </div>
      </section>

      {/* RESULTS TABLE */}
      <div className="overflow-x-auto mb-10">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-800 text-white uppercase text-[10px] tracking-[0.2em]">
              <th className="p-4 text-left">Sr.</th>
              <th className="p-4 text-left">Subject</th>
              <th className="p-4 text-center">Total Marks</th>
              <th className="p-4 text-center">Marks Obtained</th>
              <th className="p-4 text-center">Percentage</th>
              <th className="p-4 text-center">Grade</th>
            </tr>
          </thead>
          <tbody className="text-sm">
            {results.map((res, idx) => (
              <tr key={idx} className={cn(idx % 2 === 0 ? "bg-white" : "bg-gray-50", "border-b border-gray-100")}>
                <td className="p-4 font-medium text-gray-500">{idx + 1}</td>
                <td className="p-4 font-bold text-gray-800">{res.subject}</td>
                <td className="p-4 text-center font-medium">{res.totalMarks}</td>
                <td className="p-4 text-center font-bold text-[#00A896]">{res.obtainedMarks}</td>
                <td className="p-4 text-center font-medium">{res.percentage}%</td>
                <td className={cn("p-4 text-center font-black", getGradeColor(res.grade))}>{res.grade}</td>
              </tr>
            ))}
            <tr className="bg-gray-100 font-black text-gray-900 border-t-2 border-gray-300">
              <td colSpan={2} className="p-4 text-right">TOTAL</td>
              <td className="p-4 text-center">{summary.totalMarks}</td>
              <td className="p-4 text-center text-[#00A896]">{summary.totalObtained}</td>
              <td className="p-4 text-center">{summary.overallPercentage}%</td>
              <td className={cn("p-4 text-center", getGradeColor(summary.overallGrade))}>{summary.overallGrade}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* SUMMARY SECTION */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center border-t border-b border-gray-100 py-10 mb-12">
        <div className="text-center md:text-left">
          <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Aggregate Result</p>
          <div className="flex items-center justify-center md:justify-start gap-4">
            <span className="text-5xl font-black text-gray-900">{summary.overallPercentage}%</span>
            <span className={cn(
              "px-6 py-2 rounded-xl text-xl font-black border-2",
              getGradeColor(summary.overallGrade).replace('text-', 'border-').replace('800', '400').replace('600', '400')
            )}>
              {summary.overallGrade}
            </span>
          </div>
        </div>
        <div className="text-center">
          <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Class Performance</p>
          <p className="text-xl font-bold text-gray-800">
            <span className="text-[#00A896] text-3xl">{summary.classPosition.split(' ')[0]}</span> {summary.classPosition.split(' ').slice(1).join(' ')}
          </p>
        </div>
        <div className="flex justify-center md:justify-end">
          <div className={cn(
            "w-48 h-20 flex items-center justify-center text-3xl font-black tracking-widest uppercase border-4 rounded-2xl",
            summary.overallPercentage >= 50 
              ? "bg-green-50 border-green-500 text-green-600 shadow-[0_0_20px_rgba(34,197,94,0.15)]" 
              : "bg-red-50 border-red-500 text-red-600 shadow-[0_0_20px_rgba(239,68,68,0.15)]"
          )}>
            {summary.overallPercentage >= 50 ? 'PASS' : 'FAIL'}
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="mt-12">
        <div className="grid grid-cols-2 gap-20 mb-16">
          <div className="text-center">
            <div className="border-b border-gray-400 w-full mb-3"></div>
            <p className="text-[10px] font-black uppercase tracking-widest text-gray-500">Student / Parent Signature</p>
          </div>
          <div className="text-center">
            <div className="border-b border-gray-400 w-full mb-3"></div>
            <p className="text-[10px] font-black uppercase tracking-widest text-gray-500">Principal Signature</p>
            <p className="text-xs font-bold text-gray-800 mt-1 uppercase">{school.principalName}</p>
          </div>
        </div>
        <div className="text-center border-t border-gray-100 pt-6">
          <p className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-400">
            Generated by <span className="text-[#00A896]">EduCore OS</span> | CoreCraft Solutions
          </p>
        </div>
      </footer>
    </div>
  );
};

export default ReportCard;
