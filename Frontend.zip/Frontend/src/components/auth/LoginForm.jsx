import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Lock, Mail, ArrowLeft, ArrowRight, Activity } from 'lucide-react';
import axiosInstance from '../../api/axiosInstance';
import { useAuth } from '../../context/AuthContext';
import { ROLE_META, ROLE_CONFIG } from '../../constants/roleMeta';
import Button from '../ui/Button';
import Badge from '../ui/Badge';
import { cn } from '../../lib/utils';

const LoginForm = ({ role, onBack }) => {
  const { login } = useAuth();
  const navigate = useNavigate();
  
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const config = ROLE_CONFIG[role] || ROLE_CONFIG.admin;
  const meta = ROLE_META[role] || ROLE_META.admin;

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await axiosInstance.post('/auth/login', {
        email: form.email,
        password: form.password,
        role: role
      });

      const { user: userData, token } = response.data.data;

      if (userData.role !== role) {
        setError(`Access Denied: This account is not authorized as ${role}.`);
        setLoading(false);
        return;
      }

      await login(userData, token);
      navigate(`/${role}/dashboard`);
    } catch (err) {
      setError(err.response?.data?.message || 'Authentication failed. Please check credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto animate-fade-in">
      {onBack && (
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-muted-500 hover:text-white transition-colors mb-10 text-[10px] font-black uppercase tracking-[0.2em] group"
        >
          <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform" />
          System Re-selection
        </button>
      )}

      <div className="mb-10">
        <Badge variant={role === 'admin' ? 'success' : role === 'teacher' ? 'info' : 'warning'} className="mb-4 py-1.5 px-4 rounded-xl border-white/5">
           <Activity size={10} className="mr-2" />
           {role} authorized portal
        </Badge>
        <h2 className="font-syne text-4xl font-bold text-white tracking-tighter">Identity Access</h2>
        <p className="text-muted-500 text-sm mt-2 font-medium">Verify your credentials to initialize session.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <label className="block text-[10px] font-black text-muted-500 uppercase tracking-[0.2em] ml-1">
            Station Identifier
          </label>
          <div className="relative group">
            <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-muted-600 group-focus-within:text-primary-500 transition-colors" size={18} />
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder={config.placeholder || "email@educore.pk"}
              required
              className="w-full bg-surface-base border border-surface-border rounded-2xl pl-14 pr-5 py-4 text-white focus:outline-none focus:ring-4 focus:ring-primary-500/10 focus:border-primary-500 transition-all font-medium"
            />
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between ml-1">
            <label className="block text-[10px] font-black text-muted-500 uppercase tracking-[0.2em]">
              Security Key
            </label>
            <Link to="/forgot-password" strokeWidth={2.5} className="text-[10px] font-black uppercase tracking-[0.2em] text-primary-500 hover:text-primary-400 transition-colors">
              Recover
            </Link>
          </div>
          <div className="relative group">
            <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-muted-600 group-focus-within:text-primary-500 transition-colors" size={18} />
            <input
              type={showPassword ? "text" : "password"}
              name="password"
              value={form.password}
              onChange={handleChange}
              placeholder="••••••••"
              required
              className="w-full bg-surface-base border border-surface-border rounded-2xl pl-14 pr-14 py-4 text-white focus:outline-none focus:ring-4 focus:ring-primary-500/10 focus:border-primary-500 transition-all font-medium"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-5 top-1/2 -translate-y-1/2 text-muted-600 hover:text-white transition-colors"
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>
        </div>

        <div className="flex items-center gap-3 py-2 px-1">
          <input type="checkbox" id="remember" className="w-4 h-4 rounded border-surface-border bg-surface-base text-primary-600 focus:ring-primary-500/20" />
          <label htmlFor="remember" className="text-xs text-muted-500 font-bold uppercase tracking-widest">Persist Session</label>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4 flex gap-4 animate-shake">
            <div className="w-8 h-8 rounded-xl bg-red-500/20 flex items-center justify-center shrink-0">
               <ShieldAlert size={16} className="text-red-500" />
            </div>
            <p className="text-xs font-bold text-red-100 flex-1 py-1">{error}</p>
          </div>
        )}

        <Button
          type="submit"
          isLoading={loading}
          className="w-full gap-3 group"
        >
          Initialize Sync
          <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
        </Button>

        <button 
          type="button"
          className="w-full py-4 text-[10px] font-black text-muted-600 hover:text-muted-400 transition-all uppercase tracking-[0.3em]"
        >
          Bypass with Demo Access
        </button>
      </form>
    </div>
  );
};

// Simple ShieldAlert icon replacement if not available
const ShieldAlert = ({ size, className }) => (
  <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
  </svg>
)

export default LoginForm;
