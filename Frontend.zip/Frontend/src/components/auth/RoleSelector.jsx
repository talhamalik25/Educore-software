import { ROLE_META } from '../../constants/roleMeta';
import { cn } from '../../lib/utils';
import { ShieldCheck, ChevronRight } from 'lucide-react';
import Button from '../ui/Button';

const RoleSelector = ({ selectedRole, onSelect, onContinue }) => {
  const roles = ['admin', 'teacher', 'parent'];

  return (
    <div className="w-full max-w-lg mx-auto animate-fade-in text-center">
      <h2 className="font-syne text-3xl font-bold text-white mb-2">
        Initialize Session
      </h2>
      <p className="text-muted-500 text-sm mb-10 font-medium">
        Select your authorization level to access the OS grid.
      </p>

      <div className="grid grid-cols-1 gap-4">
        {roles.map((id) => {
          const meta = ROLE_META[id];
          const isSelected = selectedRole === id;
          
          return (
            <div
              key={id}
              onClick={() => onSelect(id)}
              className={cn(
                "cursor-pointer group flex items-center gap-6 p-6 rounded-3xl border-2 transition-all duration-300",
                isSelected
                  ? "bg-primary-600/10 border-primary-500 shadow-glow"
                  : "border-surface-border bg-surface-base hover:border-muted-700"
              )}
            >
              <div className={cn(
                "w-16 h-16 rounded-2xl flex items-center justify-center text-3xl transition-all duration-500",
                isSelected ? "bg-primary-600 text-white shadow-glow" : "bg-muted-900 grayscale opacity-40 group-hover:grayscale-0 group-hover:opacity-100"
              )}>
                {meta.icon}
              </div>
              
              <div className="flex-1 text-left">
                <h3 className={cn(
                  "font-bold text-lg transition-colors",
                  isSelected ? "text-white" : "text-muted-400 group-hover:text-muted-200"
                )}>
                  {meta.title}
                </h3>
                <p className="text-muted-500 text-xs mt-1 font-medium leading-relaxed">
                  {meta.description}
                </p>
              </div>

              <div className={cn(
                "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all",
                isSelected ? "border-primary-500 bg-primary-500 shadow-glow" : "border-muted-800"
              )}>
                {isSelected && <ShieldCheck size={14} className="text-white" />}
              </div>
            </div>
          );
        })}
      </div>

      <Button
        onClick={onContinue}
        disabled={!selectedRole}
        className="w-full mt-10 gap-2 group"
      >
        <span>Proceed to Authentication</span>
        <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
      </Button>
    </div>
  );
};

export default RoleSelector;
