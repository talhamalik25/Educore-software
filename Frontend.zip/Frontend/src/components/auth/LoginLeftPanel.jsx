import { ROLE_META } from '../../constants/roleMeta';
import { cn } from '../../lib/utils';
import { School, Users } from 'lucide-react';
import { motion } from 'framer-motion';

const LoginLeftPanel = ({ role }) => {
  const meta = ROLE_META[role] || {};

  return (
    <div className={cn(
      "hidden lg:flex flex-col justify-between p-16 w-[45%] min-h-full transition-all duration-700 relative overflow-hidden",
      "bg-surface-elevated border-r border-surface-border"
    )}>
      {/* Dynamic Glow Effect based on Role */}
      <div 
        className="absolute top-0 right-0 w-96 h-96 blur-[150px] opacity-20 pointer-events-none -translate-y-1/2 translate-x-1/2 rounded-full"
        style={{ backgroundColor: meta.accent }}
      />

      <div className="space-y-12 relative z-10">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white shadow-glow">
            <School size={24} strokeWidth={2.5} />
          </div>
          <div>
            <h1 className="font-syne text-2xl font-bold text-white tracking-tighter">EduCore OS</h1>
            <p className="text-[10px] font-black uppercase tracking-[0.3em] text-muted-500">Universal System</p>
          </div>
        </div>

        <div className="space-y-6 max-w-sm">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-syne text-5xl font-bold leading-[1.1] text-white tracking-tight"
          >
            Accessing {meta.title} <span className="text-primary-400">Environment</span>
          </motion.h2>
          <p className="text-muted-500 text-lg leading-relaxed font-medium">
            {meta.description}. Enter the global infrastructure to manage operations with AI-powered analytics.
          </p>
        </div>
      </div>

      <div className="relative z-10">
        <div className="space-y-6">
          <div className="flex -space-x-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="w-12 h-12 rounded-2xl border-2 border-surface-elevated bg-muted-900 overflow-hidden shadow-saas ring-1 ring-white/10">
                <img src={`https://i.pravatar.cc/150?u=${i + (role === 'teacher' ? 10 : 20)}`} alt="User" />
              </div>
            ))}
            <div className="w-12 h-12 rounded-2xl border-2 border-surface-elevated flex items-center justify-center text-xs font-black text-white bg-primary-600 shadow-glow ring-1 ring-white/10">
              +12
            </div>
          </div>
          <div className="flex items-center gap-3">
             <div className="p-2 bg-white/5 rounded-lg border border-white/10">
                <Users size={16} className="text-primary-400" />
             </div>
             <p className="text-sm font-bold text-muted-400">
               Unified with <span className="text-white font-black">2,400+</span> active {role}s
             </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginLeftPanel;
