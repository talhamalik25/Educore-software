<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>EduCore OS — Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet"/>
<style>
/* ── RESET ── */
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:       #080e14;
  --s1:       #0b1420;
  --s2:       #0f1d2e;
  --card:     #111e2e;
  --card2:    #142030;
  --bord:     rgba(255,255,255,0.055);
  --bord2:    rgba(255,255,255,0.09);
  --g1:       #00d97e;
  --g2:       #00b96b;
  --g3:       #009958;
  --gtxt:     #00d97e;
  --txt:      #f0f4f8;
  --txt2:     rgba(255,255,255,0.45);
  --txt3:     rgba(255,255,255,0.22);
  --red:      #ff4d6d;
  --amber:    #ffb547;
  --blue:     #4d9fff;
  --purple:   #a78bfa;
  --teal:     #2dd4bf;
}
html,body{height:100%;background:var(--bg);color:var(--txt);font-family:'DM Sans',sans-serif;overflow:hidden}
::-webkit-scrollbar{width:3px;height:3px}
::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.08);border-radius:3px}

/* ── LAYOUT ── */
.shell{display:flex;height:100vh;overflow:hidden}

/* ── SIDEBAR ── */
.sidebar{
  width:220px;flex-shrink:0;
  background:var(--s1);
  border-right:1px solid var(--bord);
  display:flex;flex-direction:column;
  position:relative;overflow:hidden;
}
.sidebar::before{
  content:'';position:absolute;bottom:-60px;left:-60px;
  width:200px;height:200px;border-radius:50%;
  background:radial-gradient(circle,rgba(0,217,126,0.06),transparent 70%);
  pointer-events:none;
}

.logo-wrap{padding:22px 18px 18px;border-bottom:1px solid var(--bord)}
.logo{display:flex;align-items:center;gap:10px}
.logo-mark{
  width:36px;height:36px;border-radius:10px;flex-shrink:0;
  background:linear-gradient(135deg,var(--g1),var(--teal));
  display:flex;align-items:center;justify-content:center;font-size:18px;
  box-shadow:0 4px 16px rgba(0,217,126,0.35);
}
.logo-text{font-family:'Syne',sans-serif;font-size:15px;font-weight:800;color:var(--txt);line-height:1}
.logo-sub{font-size:10px;color:var(--txt3);margin-top:3px;letter-spacing:.04em}

.school-pill{
  margin:12px 14px;border-radius:12px;padding:10px 12px;
  background:rgba(0,217,126,0.05);border:1px solid rgba(0,217,126,0.1);
}
.school-live{display:flex;align-items:center;gap:5px;margin-bottom:3px}
.live-dot{width:6px;height:6px;border-radius:50%;background:var(--g1);animation:pp 2s infinite}
.live-txt{font-size:10px;font-weight:600;color:var(--g1);letter-spacing:.05em}
.school-name{font-size:12px;font-weight:700;color:var(--txt)}
.school-meta{font-size:10px;color:var(--txt3)}

.nav-section-label{
  font-size:9px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;
  color:var(--txt3);padding:14px 18px 6px;
}
.nav-item{
  display:flex;align-items:center;gap:10px;
  padding:9px 14px;margin:1px 8px;border-radius:10px;
  font-size:13px;font-weight:500;color:var(--txt3);
  cursor:pointer;transition:all .15s;border:1px solid transparent;
  position:relative;
}
.nav-item:hover{color:rgba(255,255,255,.6);background:rgba(255,255,255,.03)}
.nav-item.active{
  color:var(--g1);background:rgba(0,217,126,.08);
  border-color:rgba(0,217,126,.15);
}
.nav-item.active::before{
  content:'';position:absolute;left:0;top:25%;bottom:25%;
  width:2.5px;border-radius:0 3px 3px 0;background:var(--g1);
}
.nav-icon{font-size:15px;width:20px;text-align:center;flex-shrink:0}
.nav-label{flex:1}
.nav-badge{
  font-size:9px;font-weight:700;padding:2px 6px;border-radius:20px;
  background:rgba(255,255,255,.06);color:rgba(255,255,255,.3);
  font-family:'JetBrains Mono',monospace;
}
.nav-item.active .nav-badge{background:rgba(0,217,126,.15);color:var(--g1)}

.sidebar-user{
  margin-top:auto;padding:14px 16px;
  border-top:1px solid var(--bord);
  display:flex;align-items:center;gap:10px;
}
.user-av{
  width:32px;height:32px;border-radius:50%;flex-shrink:0;
  background:linear-gradient(135deg,var(--g2),var(--teal));
  display:flex;align-items:center;justify-content:center;
  font-size:11px;font-weight:800;color:white;
}
.user-name{font-size:12px;font-weight:700;color:var(--txt)}
.user-role{font-size:10px;color:var(--txt3)}

/* ── MAIN ── */
.main{flex:1;display:flex;flex-direction:column;overflow:hidden}

/* TOPBAR */
.topbar{
  height:56px;flex-shrink:0;
  background:var(--s1);border-bottom:1px solid var(--bord);
  display:flex;align-items:center;justify-content:space-between;padding:0 24px;
}
.topbar-left{display:flex;align-items:center;gap:8px}
.page-title{font-family:'Syne',sans-serif;font-size:17px;font-weight:800;color:var(--txt)}
.breadcrumb{font-size:12px;color:var(--txt3)}

.topbar-right{display:flex;align-items:center;gap:8px}
.search-wrap{position:relative}
.search-input{
  background:rgba(255,255,255,.04);border:1px solid var(--bord);
  color:var(--txt);font-size:12px;font-family:'DM Sans',sans-serif;
  padding:7px 12px 7px 32px;border-radius:10px;outline:none;width:180px;
  transition:all .2s;
}
.search-input::placeholder{color:var(--txt3)}
.search-input:focus{border-color:rgba(0,217,126,.35);background:rgba(0,217,126,.04);width:210px}
.search-icon{position:absolute;left:10px;top:50%;transform:translateY(-50%);font-size:12px;color:var(--txt3)}
.icon-btn{
  width:34px;height:34px;border-radius:9px;
  background:rgba(255,255,255,.04);border:1px solid var(--bord);
  display:flex;align-items:center;justify-content:center;
  font-size:14px;cursor:pointer;transition:all .15s;position:relative;
}
.icon-btn:hover{background:rgba(255,255,255,.07);border-color:var(--bord2)}
.notif-dot{
  position:absolute;top:6px;right:6px;width:6px;height:6px;
  background:var(--red);border-radius:50%;
  box-shadow:0 0 6px rgba(255,77,109,.6);
}
.add-btn{
  display:flex;align-items:center;gap:6px;
  padding:7px 14px;border-radius:10px;
  background:linear-gradient(135deg,var(--g1),var(--teal));
  color:#051a10;font-size:12px;font-weight:700;
  cursor:pointer;transition:all .15s;border:none;
  box-shadow:0 4px 16px rgba(0,217,126,.3);
  font-family:'DM Sans',sans-serif;
}
.add-btn:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(0,217,126,.4)}
.add-btn:active{transform:scale(.97)}

/* CONTENT */
.content{flex:1;overflow-y:auto;padding:22px 24px;display:flex;flex-direction:column;gap:18px}

/* GREETING */
.greeting{display:flex;align-items:flex-end;justify-content:space-between}
.greeting-text h2{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;color:var(--txt)}
.greeting-text p{font-size:12px;color:var(--txt3);margin-top:3px}
.greeting-actions{display:flex;gap:8px}
.ghost-btn{
  padding:7px 14px;border-radius:10px;font-size:12px;font-weight:600;
  background:rgba(255,255,255,.05);border:1px solid var(--bord);
  color:var(--txt2);cursor:pointer;transition:all .15s;
  font-family:'DM Sans',sans-serif;
}
.ghost-btn:hover{background:rgba(255,255,255,.08);color:var(--txt)}

/* STAT CARDS */
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.stat-card{
  border-radius:16px;padding:18px 20px;position:relative;overflow:hidden;
  cursor:default;transition:transform .2s,box-shadow .2s;
}
.stat-card:hover{transform:translateY(-3px)}
.stat-glow{
  position:absolute;top:-30px;right:-30px;width:100px;height:100px;
  border-radius:50%;opacity:.25;filter:blur(20px);
}
.stat-emoji{
  position:absolute;bottom:10px;right:14px;font-size:36px;opacity:.1;
}
.stat-chip{
  display:inline-flex;align-items:center;gap:4px;
  font-size:9px;font-weight:700;letter-spacing:.07em;text-transform:uppercase;
  padding:3px 8px;border-radius:20px;margin-bottom:10px;
}
.stat-val{
  font-family:'Syne',sans-serif;font-size:36px;font-weight:800;
  line-height:1;margin-bottom:4px;
}
.stat-sub{font-size:11px;opacity:.6;font-weight:500}

.s-green{ background:linear-gradient(135deg,#062d1a,#0a3d24); border:1px solid rgba(0,217,126,.15); box-shadow:0 8px 32px rgba(0,217,126,.08)}
.s-green .stat-val{color:var(--g1)}
.s-green .stat-chip{background:rgba(0,217,126,.12);color:var(--g1)}
.s-green .stat-glow{background:var(--g1)}

.s-teal{ background:linear-gradient(135deg,#062228,#083035); border:1px solid rgba(45,212,191,.15); box-shadow:0 8px 32px rgba(45,212,191,.08)}
.s-teal .stat-val{color:var(--teal)}
.s-teal .stat-chip{background:rgba(45,212,191,.12);color:var(--teal)}
.s-teal .stat-glow{background:var(--teal)}

.s-blue{ background:linear-gradient(135deg,#081828,#0c2040); border:1px solid rgba(77,159,255,.15); box-shadow:0 8px 32px rgba(77,159,255,.08)}
.s-blue .stat-val{color:var(--blue)}
.s-blue .stat-chip{background:rgba(77,159,255,.12);color:var(--blue)}
.s-blue .stat-glow{background:var(--blue)}

.s-purple{ background:linear-gradient(135deg,#12082a,#1a0e38); border:1px solid rgba(167,139,250,.15); box-shadow:0 8px 32px rgba(167,139,250,.08)}
.s-purple .stat-val{color:var(--purple)}
.s-purple .stat-chip{background:rgba(167,139,250,.12);color:var(--purple)}
.s-purple .stat-glow{background:var(--purple)}

/* MIDDLE ROW */
.mid-row{display:grid;grid-template-columns:1.2fr 1fr 1fr;gap:14px}

/* PANELS */
.panel{
  background:var(--card);border:1px solid var(--bord);
  border-radius:16px;padding:20px;overflow:hidden;
}
.panel-header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:18px}
.panel-title{font-size:13px;font-weight:700;color:var(--txt)}
.panel-sub{font-size:10px;color:var(--txt3);margin-top:2px}
.panel-link{font-size:11px;font-weight:600;color:var(--g1);cursor:pointer;transition:opacity .15s}
.panel-link:hover{opacity:.7}

/* CHART */
.chart-bars{display:flex;align-items:flex-end;gap:8px;height:110px;margin-bottom:10px}
.bar-wrap{flex:1;display:flex;flex-direction:column;align-items:center;gap:5px;height:100%}
.bar-val{font-size:10px;font-weight:600;font-family:'JetBrains Mono',monospace}
.bar-track{flex:1;width:100%;border-radius:6px;overflow:hidden;background:rgba(255,255,255,.04);position:relative;display:flex;align-items:flex-end}
.bar-fill{width:100%;border-radius:6px;transition:height .8s cubic-bezier(.34,1.56,.64,1);position:relative;overflow:hidden}
.bar-fill::after{content:'';position:absolute;top:0;left:0;right:0;height:30%;background:rgba(255,255,255,.15);border-radius:6px}
.bar-fill:hover{filter:brightness(1.15)}
.bar-day{font-size:9px;font-weight:600;color:var(--txt3);letter-spacing:.03em}

/* FEE RING */
.fee-ring-wrap{display:flex;align-items:center;gap:18px}
.ring-svg{flex-shrink:0}
.fee-legend{flex:1;display:flex;flex-direction:column;gap:10px}
.legend-row{display:flex;align-items:center;justify-content:space-between}
.legend-left{display:flex;align-items:center;gap:7px}
.l-swatch{width:8px;height:8px;border-radius:2px}
.l-label{font-size:11px;color:var(--txt2)}
.l-val{font-size:12px;font-weight:700;font-family:'JetBrains Mono',monospace;color:var(--txt)}
.fee-totals{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px;padding-top:14px;border-top:1px solid var(--bord)}
.fee-total-box{border-radius:10px;padding:10px;text-align:center}
.fee-total-val{font-size:13px;font-weight:700;font-family:'JetBrains Mono',monospace}
.fee-total-label{font-size:9px;margin-top:2px;font-weight:600;letter-spacing:.04em;text-transform:uppercase}

/* ACTIVITY */
.activity-list{display:flex;flex-direction:column;gap:12px}
.act-row{display:flex;align-items:flex-start;gap:10px;cursor:default}
.act-icon-wrap{position:relative;flex-shrink:0}
.act-icon{width:32px;height:32px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:14px}
.act-line{position:absolute;left:50%;top:100%;width:1px;height:12px;transform:translateX(-50%);background:var(--bord)}
.act-title{font-size:12px;font-weight:600;color:var(--txt);line-height:1.3;transition:color .15s}
.act-row:hover .act-title{color:var(--g1)}
.act-desc{font-size:10px;color:var(--txt3);margin-top:2px}
.act-time{font-size:10px;font-family:'JetBrains Mono',monospace;color:var(--txt3);white-space:nowrap;margin-left:auto;padding-left:8px;padding-top:1px}

/* BOTTOM ROW */
.bot-row{display:grid;grid-template-columns:280px 1fr;gap:14px}

/* CLASS LIST */
.class-list{display:flex;flex-direction:column;gap:10px}
.class-row{cursor:pointer;padding:10px 12px;border-radius:11px;transition:background .15s;border:1px solid transparent}
.class-row:hover{background:rgba(255,255,255,.03);border-color:var(--bord)}
.class-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:7px}
.class-left{display:flex;align-items:center;gap:8px}
.class-badge{
  width:34px;height:34px;border-radius:9px;
  display:flex;align-items:center;justify-content:center;
  font-size:11px;font-weight:800;
  background:rgba(0,217,126,.08);color:var(--g1);
  font-family:'JetBrains Mono',monospace;
}
.class-name{font-size:12px;font-weight:700;color:var(--txt)}
.class-meta{font-size:10px;color:var(--txt3)}
.class-pct{font-size:13px;font-weight:700;font-family:'JetBrains Mono',monospace}
.prog-track{height:4px;background:rgba(255,255,255,.05);border-radius:4px;overflow:hidden}
.prog-fill{height:100%;border-radius:4px;transition:width .8s cubic-bezier(.34,1.56,.64,1)}

/* STUDENTS TABLE */
.table-wrap{overflow:hidden}
.table-controls{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.filter-tabs{display:flex;gap:4px;background:rgba(255,255,255,.03);border:1px solid var(--bord);border-radius:9px;padding:3px}
.filter-tab{
  padding:4px 12px;border-radius:6px;font-size:11px;font-weight:600;
  color:var(--txt3);cursor:pointer;transition:all .15s;border:none;background:transparent;
  font-family:'DM Sans',sans-serif;
}
.filter-tab.active{background:rgba(0,217,126,.1);color:var(--g1)}
.filter-tab:not(.active):hover{color:var(--txt2)}

table{width:100%;border-collapse:collapse}
thead th{
  font-size:9px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  color:var(--txt3);padding:6px 10px;text-align:left;
  border-bottom:1px solid var(--bord);
}
tbody tr{border-bottom:1px solid rgba(255,255,255,.03);transition:background .12s;cursor:pointer}
tbody tr:last-child{border-bottom:none}
tbody tr:hover{background:rgba(0,217,126,.03)}
td{padding:9px 10px;font-size:12px;color:var(--txt2)}

.stu-cell{display:flex;align-items:center;gap:9px}
.stu-av{
  width:30px;height:30px;border-radius:50%;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;
  font-size:10px;font-weight:800;color:white;
}
.stu-name{font-size:12px;font-weight:600;color:var(--txt)}
.stu-roll{font-size:10px;color:var(--txt3)}
.class-tag{
  font-size:10px;font-weight:700;padding:3px 8px;border-radius:6px;
  background:rgba(255,255,255,.05);color:var(--txt3);
  font-family:'JetBrains Mono',monospace;
}
.att-cell{display:flex;align-items:center;gap:7px}
.att-mini{width:44px;height:3px;background:rgba(255,255,255,.06);border-radius:3px;overflow:hidden}
.att-fill{height:100%;border-radius:3px}
.att-pct{font-size:11px;font-weight:700;font-family:'JetBrains Mono',monospace}
.badge{font-size:10px;font-weight:700;padding:3px 9px;border-radius:20px;display:inline-block}
.b-green{background:rgba(0,217,126,.1);color:var(--g1)}
.b-amber{background:rgba(255,181,71,.1);color:var(--amber)}
.b-red{background:rgba(255,77,109,.1);color:var(--red)}
.b-teal{background:rgba(45,212,191,.1);color:var(--teal)}
.view-link{font-size:11px;font-weight:700;color:var(--g1);opacity:0;transition:opacity .15s}
tbody tr:hover .view-link{opacity:1}

/* QUICK ACTIONS BANNER */
.actions-banner{
  border-radius:16px;padding:18px 22px;
  background:linear-gradient(120deg,#062a18,#072230,#0d1a30);
  border:1px solid rgba(0,217,126,.12);
  display:flex;align-items:center;justify-content:space-between;
  position:relative;overflow:hidden;
}
.actions-banner::before{
  content:'';position:absolute;top:-40px;right:80px;
  width:180px;height:180px;border-radius:50%;
  background:radial-gradient(circle,rgba(0,217,126,.06),transparent 70%);
}
.ab-left h3{font-size:14px;font-weight:700;color:var(--txt)}
.ab-left p{font-size:11px;color:var(--txt3);margin-top:2px}
.ab-actions{display:flex;gap:8px;position:relative}
.ab-btn{
  padding:8px 16px;border-radius:10px;font-size:12px;font-weight:600;
  cursor:pointer;transition:all .15s;border:none;
  font-family:'DM Sans',sans-serif;
}
.ab-primary{
  background:linear-gradient(135deg,var(--g1),var(--teal));
  color:#051a10;box-shadow:0 4px 14px rgba(0,217,126,.3);
}
.ab-primary:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(0,217,126,.4)}
.ab-ghost{
  background:rgba(255,255,255,.06);border:1px solid var(--bord);color:var(--txt2);
}
.ab-ghost:hover{background:rgba(255,255,255,.1);color:var(--txt)}

/* MODAL */
.modal-overlay{
  position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:100;
  display:flex;align-items:center;justify-content:center;padding:20px;
  backdrop-filter:blur(8px);opacity:0;transition:opacity .2s;
}
.modal-overlay.show{opacity:1}
.modal{
  background:var(--s2);border:1px solid var(--bord2);
  border-radius:20px;width:100%;max-width:400px;overflow:hidden;
  transform:translateY(20px) scale(.97);transition:all .25s;
  box-shadow:0 40px 80px rgba(0,0,0,.5);
}
.modal-overlay.show .modal{transform:translateY(0) scale(1)}
.modal-head{padding:22px 24px 18px;border-bottom:1px solid var(--bord)}
.modal-title{font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:var(--txt)}
.modal-sub{font-size:11px;color:var(--txt3);margin-top:3px}
.modal-close{
  width:28px;height:28px;border-radius:8px;background:rgba(255,255,255,.06);
  border:1px solid var(--bord);color:var(--txt3);cursor:pointer;
  display:flex;align-items:center;justify-content:center;font-size:14px;
  transition:all .15s;
}
.modal-close:hover{background:rgba(255,255,255,.1);color:var(--txt)}
.modal-body{padding:20px 24px;display:flex;flex-direction:column;gap:14px}
.field label{
  display:block;font-size:10px;font-weight:700;letter-spacing:.08em;
  text-transform:uppercase;color:var(--txt3);margin-bottom:6px;
}
.field input,.field select{
  width:100%;padding:10px 12px;border-radius:10px;
  background:rgba(255,255,255,.04);border:1px solid var(--bord);
  color:var(--txt);font-size:13px;font-family:'DM Sans',sans-serif;
  outline:none;transition:all .2s;appearance:none;
}
.field input::placeholder{color:var(--txt3)}
.field input:focus,.field select:focus{
  border-color:rgba(0,217,126,.4);background:rgba(0,217,126,.04);
  box-shadow:0 0 0 3px rgba(0,217,126,.08);
}
.field select option{background:var(--s2)}
.field-row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.modal-foot{display:flex;gap:8px;padding:0 24px 22px}
.modal-cancel{
  flex:1;padding:10px;border-radius:10px;
  background:rgba(255,255,255,.05);border:1px solid var(--bord);
  color:var(--txt3);font-size:13px;font-weight:600;cursor:pointer;
  font-family:'DM Sans',sans-serif;transition:all .15s;
}
.modal-cancel:hover{background:rgba(255,255,255,.08);color:var(--txt)}
.modal-submit{
  flex:2;padding:10px;border-radius:10px;
  background:linear-gradient(135deg,var(--g1),var(--teal));
  border:none;color:#051a10;font-size:13px;font-weight:700;cursor:pointer;
  font-family:'DM Sans',sans-serif;transition:all .15s;
  box-shadow:0 4px 14px rgba(0,217,126,.3);
}
.modal-submit:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(0,217,126,.4)}

/* ANIMATIONS */
@keyframes pp{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.3;transform:scale(.7)}}
@keyframes fadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
.fu{animation:fadeUp .4s ease both}
.fu1{animation:fadeUp .4s .05s ease both}
.fu2{animation:fadeUp .4s .1s ease both}
.fu3{animation:fadeUp .4s .15s ease both}
.fu4{animation:fadeUp .4s .2s ease both}
.fu5{animation:fadeUp .4s .25s ease both}
.fu6{animation:fadeUp .4s .3s ease both}
</style>
</head>
<body>

<div class="shell">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="logo-wrap">
      <div class="logo">
        <div class="logo-mark">🎓</div>
        <div>
          <div class="logo-text">EduCore OS</div>
          <div class="logo-sub">PHASE 1 · ADMIN</div>
        </div>
      </div>
    </div>

    <div class="school-pill">
      <div class="school-live">
        <div class="live-dot"></div>
        <span class="live-txt">LIVE</span>
      </div>
      <div class="school-name">Al-Noor Academy</div>
      <div class="school-meta">Karachi · Session 2024–25</div>
    </div>

    <div class="nav-section-label">Main</div>
    <nav id="mainNav">
      <div class="nav-item active" data-page="Dashboard">
        <span class="nav-icon">▦</span><span class="nav-label">Dashboard</span>
      </div>
      <div class="nav-item" data-page="Students">
        <span class="nav-icon">👤</span><span class="nav-label">Students</span><span class="nav-badge">247</span>
      </div>
      <div class="nav-item" data-page="Attendance">
        <span class="nav-icon">📋</span><span class="nav-label">Attendance</span>
      </div>
      <div class="nav-item" data-page="Fees">
        <span class="nav-icon">💳</span><span class="nav-label">Fees</span><span class="nav-badge">41</span>
      </div>
      <div class="nav-item" data-page="Homework">
        <span class="nav-icon">📚</span><span class="nav-label">Homework</span>
      </div>
    </nav>

    <div class="nav-section-label">School</div>
    <nav>
      <div class="nav-item" data-page="Teachers">
        <span class="nav-icon">👩‍🏫</span><span class="nav-label">Teachers</span>
      </div>
      <div class="nav-item" data-page="Reports">
        <span class="nav-icon">📈</span><span class="nav-label">Reports</span>
      </div>
      <div class="nav-item" data-page="Settings">
        <span class="nav-icon">⚙️</span><span class="nav-label">Settings</span>
      </div>
    </nav>

    <div class="sidebar-user">
      <div class="user-av">TM</div>
      <div style="flex:1;min-width:0">
        <div class="user-name">Talha Malik</div>
        <div class="user-role">Principal</div>
      </div>
      <div style="color:var(--txt3);font-size:16px;cursor:pointer">⋯</div>
    </div>
  </aside>

  <!-- MAIN -->
  <div class="main">

    <!-- TOPBAR -->
    <header class="topbar">
      <div class="topbar-left">
        <span class="page-title" id="pageTitle">Dashboard</span>
        <span class="breadcrumb">/ Overview</span>
      </div>
      <div class="topbar-right">
        <div class="search-wrap">
          <span class="search-icon">🔍</span>
          <input class="search-input" placeholder="Search students..." id="searchInput" oninput="filterStudents()"/>
        </div>
        <div class="icon-btn">🔔<div class="notif-dot"></div></div>
        <button class="add-btn" onclick="openModal()">＋ Add Student</button>
      </div>
    </header>

    <!-- CONTENT -->
    <div class="content">

      <!-- GREETING -->
      <div class="greeting fu">
        <div class="greeting-text">
          <h2>Good Morning, Talha 👋</h2>
          <p>Al-Noor Academy &nbsp;·&nbsp; Wednesday, 5 March 2025</p>
        </div>
        <div class="greeting-actions">
          <button class="ghost-btn">📤 Export</button>
          <button class="ghost-btn" style="color:var(--g1);border-color:rgba(0,217,126,.25)">📋 Mark Attendance</button>
        </div>
      </div>

      <!-- STATS -->
      <div class="stats-row fu1">
        <div class="stat-card s-green">
          <div class="stat-glow"></div>
          <div class="stat-emoji">👨‍🎓</div>
          <div class="stat-chip">Students</div>
          <div class="stat-val">247</div>
          <div class="stat-sub">+4 enrolled this week</div>
        </div>
        <div class="stat-card s-teal">
          <div class="stat-glow"></div>
          <div class="stat-emoji">✅</div>
          <div class="stat-chip">Present Today</div>
          <div class="stat-val">91%</div>
          <div class="stat-sub">224 of 247 students</div>
        </div>
        <div class="stat-card s-blue">
          <div class="stat-glow"></div>
          <div class="stat-emoji">💰</div>
          <div class="stat-chip">Fee Collected</div>
          <div class="stat-val">83%</div>
          <div class="stat-sub">41 payments pending</div>
        </div>
        <div class="stat-card s-purple">
          <div class="stat-glow"></div>
          <div class="stat-emoji">👩‍🏫</div>
          <div class="stat-chip">Teachers</div>
          <div class="stat-val">22</div>
          <div class="stat-sub">All present today</div>
        </div>
      </div>

      <!-- MID ROW -->
      <div class="mid-row fu2">

        <!-- CHART -->
        <div class="panel">
          <div class="panel-header">
            <div>
              <div class="panel-title">Attendance Trend</div>
              <div class="panel-sub">This week · Per day</div>
            </div>
            <div style="display:flex;align-items:center;gap:5px;font-size:10px;font-weight:600;color:var(--g1);background:rgba(0,217,126,.08);padding:4px 9px;border-radius:7px;border:1px solid rgba(0,217,126,.12)">
              <div style="width:5px;height:5px;border-radius:50%;background:var(--g1);animation:pp 2s infinite"></div>Live
            </div>
          </div>
          <div class="chart-bars" id="chartBars"></div>
          <div style="display:flex;gap:8px" id="chartDays"></div>
        </div>

        <!-- FEE RING -->
        <div class="panel">
          <div class="panel-header">
            <div>
              <div class="panel-title">Fee Collection</div>
              <div class="panel-sub">March 2025</div>
            </div>
            <span class="panel-link">Manage →</span>
          </div>
          <div class="fee-ring-wrap">
            <svg class="ring-svg" width="96" height="96" viewBox="0 0 96 96">
              <circle cx="48" cy="48" r="36" fill="none" stroke="rgba(255,255,255,.04)" stroke-width="14"/>
              <!-- paid 83% -->
              <circle cx="48" cy="48" r="36" fill="none" stroke="#00d97e" stroke-width="14"
                stroke-dasharray="176.6 226.2" stroke-dashoffset="56.55" stroke-linecap="round"/>
              <!-- pending 11% -->
              <circle cx="48" cy="48" r="36" fill="none" stroke="#ffb547" stroke-width="14"
                stroke-dasharray="24.88 226.2" stroke-dashoffset="-120.05" stroke-linecap="round"/>
              <!-- overdue 6% -->
              <circle cx="48" cy="48" r="36" fill="none" stroke="#ff4d6d" stroke-width="14"
                stroke-dasharray="13.57 226.2" stroke-dashoffset="-144.93" stroke-linecap="round"/>
              <text x="48" y="44" text-anchor="middle" font-size="15" font-weight="800" fill="#f0f4f8" font-family="Syne,sans-serif">83%</text>
              <text x="48" y="58" text-anchor="middle" font-size="8" fill="rgba(255,255,255,.3)" font-family="DM Sans,sans-serif">collected</text>
            </svg>
            <div class="fee-legend">
              <div class="legend-row"><div class="legend-left"><div class="l-swatch" style="background:#00d97e"></div><span class="l-label">Paid</span></div><span class="l-val" style="color:#00d97e">205</span></div>
              <div class="legend-row"><div class="legend-left"><div class="l-swatch" style="background:#ffb547"></div><span class="l-label">Pending</span></div><span class="l-val" style="color:#ffb547">27</span></div>
              <div class="legend-row"><div class="legend-left"><div class="l-swatch" style="background:#ff4d6d"></div><span class="l-label">Overdue</span></div><span class="l-val" style="color:#ff4d6d">15</span></div>
            </div>
          </div>
          <div class="fee-totals">
            <div class="fee-total-box" style="background:rgba(0,217,126,.06);border:1px solid rgba(0,217,126,.1)">
              <div class="fee-total-val" style="color:#00d97e">2.1M</div>
              <div class="fee-total-label" style="color:rgba(0,217,126,.5)">PKR In</div>
            </div>
            <div class="fee-total-box" style="background:rgba(255,77,109,.06);border:1px solid rgba(255,77,109,.1)">
              <div class="fee-total-val" style="color:#ff4d6d">430K</div>
              <div class="fee-total-label" style="color:rgba(255,77,109,.5)">PKR Out</div>
            </div>
          </div>
        </div>

        <!-- ACTIVITY -->
        <div class="panel">
          <div class="panel-header">
            <div class="panel-title">Live Activity</div>
            <span class="panel-link">All →</span>
          </div>
          <div class="activity-list" id="activityList"></div>
        </div>
      </div>

      <!-- BOTTOM ROW -->
      <div class="bot-row fu3">

        <!-- CLASSES -->
        <div class="panel">
          <div class="panel-header">
            <div>
              <div class="panel-title">Classes Today</div>
              <div class="panel-sub">Attendance by class</div>
            </div>
            <span class="panel-link">All →</span>
          </div>
          <div class="class-list" id="classList"></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px;padding-top:14px;border-top:1px solid var(--bord)">
            <div style="background:rgba(0,217,126,.06);border:1px solid rgba(0,217,126,.1);border-radius:10px;padding:10px;text-align:center">
              <div style="font-size:18px;font-weight:800;color:#00d97e;font-family:'JetBrains Mono',monospace">224</div>
              <div style="font-size:9px;color:rgba(0,217,126,.5);font-weight:700;text-transform:uppercase;letter-spacing:.05em;margin-top:2px">Present</div>
            </div>
            <div style="background:rgba(255,77,109,.06);border:1px solid rgba(255,77,109,.1);border-radius:10px;padding:10px;text-align:center">
              <div style="font-size:18px;font-weight:800;color:#ff4d6d;font-family:'JetBrains Mono',monospace">23</div>
              <div style="font-size:9px;color:rgba(255,77,109,.5);font-weight:700;text-transform:uppercase;letter-spacing:.05em;margin-top:2px">Absent</div>
            </div>
          </div>
        </div>

        <!-- TABLE -->
        <div class="panel table-wrap">
          <div class="table-controls">
            <div class="panel-title">Students</div>
            <div class="filter-tabs">
              <button class="filter-tab active" onclick="setFilter('all',this)">All</button>
              <button class="filter-tab" onclick="setFilter('paid',this)">Paid</button>
              <button class="filter-tab" onclick="setFilter('pending',this)">Pending</button>
              <button class="filter-tab" onclick="setFilter('overdue',this)">Overdue</button>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th>Student</th>
                <th>Class</th>
                <th>Attendance</th>
                <th>Fee</th>
                <th>Today</th>
                <th></th>
              </tr>
            </thead>
            <tbody id="studentTableBody"></tbody>
          </table>
        </div>
      </div>

      <!-- ACTIONS BANNER -->
      <div class="actions-banner fu4">
        <div class="ab-left">
          <h3>Quick Actions</h3>
          <p>Your Phase 1 core tools — ready to use</p>
        </div>
        <div class="ab-actions">
          <button class="ab-btn ab-primary">📋 Mark Attendance</button>
          <button class="ab-btn ab-ghost">💰 Record Payment</button>
          <button class="ab-btn ab-ghost">📚 Upload Homework</button>
          <button class="ab-btn ab-ghost">📤 Export Report</button>
        </div>
      </div>

    </div><!-- /content -->
  </div><!-- /main -->
</div><!-- /shell -->

<!-- MODAL -->
<div class="modal-overlay" id="modalOverlay" onclick="closeModal(event)">
  <div class="modal">
    <div class="modal-head" style="display:flex;align-items:flex-start;justify-content:space-between">
      <div>
        <div class="modal-title">Add New Student</div>
        <div class="modal-sub">Fill in the details below</div>
      </div>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <div class="field-row">
        <div class="field">
          <label>Full Name</label>
          <input type="text" placeholder="Ahmad Khan"/>
        </div>
        <div class="field">
          <label>Roll Number</label>
          <input type="text" placeholder="01"/>
        </div>
      </div>
      <div class="field-row">
        <div class="field">
          <label>Class</label>
          <select>
            <option value="">Select</option>
            <option>8-A</option><option>8-B</option>
            <option>9-A</option><option>9-B</option>
            <option>10-A</option><option>10-B</option>
          </select>
        </div>
        <div class="field">
          <label>Monthly Fee (PKR)</label>
          <input type="number" placeholder="8500"/>
        </div>
      </div>
      <div class="field">
        <label>Parent Phone</label>
        <input type="tel" placeholder="0300-1234567"/>
      </div>
    </div>
    <div class="modal-foot">
      <button class="modal-cancel" onclick="closeModal()">Cancel</button>
      <button class="modal-submit" onclick="closeModal()">✓ Add Student</button>
    </div>
  </div>
</div>

<script>
// ── DATA ──
const WEEK = [{d:"Mon",v:88},{d:"Tue",v:93},{d:"Wed",v:85},{d:"Thu",v:96},{d:"Fri",v:91},{d:"Sat",v:78}];

const ACTIVITY = [
  {icon:"✅",msg:"Attendance marked — Class 10-A",sub:"38/40 present · Ms. Amina Hassan",time:"2m",bg:"rgba(0,217,126,.08)",ic:"rgba(0,217,126,.15)"},
  {icon:"💰",msg:"Fee received — Ahmad Khan",sub:"PKR 8,500 · March 2025",time:"18m",bg:"rgba(77,159,255,.08)",ic:"rgba(77,159,255,.15)"},
  {icon:"🔔",msg:"Absence SMS sent — Sara Raza",sub:"Parent notified automatically",time:"1h",bg:"rgba(255,77,109,.08)",ic:"rgba(255,77,109,.15)"},
  {icon:"📚",msg:"Homework uploaded — Math 9-A",sub:"Chapter 5 · Due today",time:"2h",bg:"rgba(255,181,71,.08)",ic:"rgba(255,181,71,.15)"},
  {icon:"💸",msg:"Fee reminders sent",sub:"Bulk SMS to 41 pending parents",time:"3h",bg:"rgba(167,139,250,.08)",ic:"rgba(167,139,250,.15)"},
];

const CLASSES = [
  {n:"9-A",p:36,t:38},{n:"10-A",p:38,t:40},{n:"8-B",p:31,t:35},{n:"11-A",p:30,t:32}
];

const STUDENTS = [
  {id:1,name:"Ahmad Khan",  roll:"01",cls:"9-A", att:97, fee:"paid",   today:"present"},
  {id:2,name:"Sara Raza",   roll:"02",cls:"9-A", att:61, fee:"pending",today:"absent"},
  {id:3,name:"Zain Malik",  roll:"03",cls:"10-A",att:100,fee:"paid",   today:"present"},
  {id:4,name:"Nadia Baig",  roll:"04",cls:"8-B", att:74, fee:"overdue",today:"late"},
  {id:5,name:"Farhan Ali",  roll:"05",cls:"10-A",att:88, fee:"paid",   today:"present"},
  {id:6,name:"Hira Qureshi",roll:"06",cls:"9-A", att:92, fee:"pending",today:"present"},
  {id:7,name:"Bilal Sheikh",roll:"07",cls:"8-B", att:85, fee:"paid",   today:"present"},
];

const AVATAR_COLORS = ["#0d9488","#059669","#0ea5e9","#7c3aed","#db2777","#dc2626","#d97706","#0369a1"];
const aColor = n => AVATAR_COLORS[n.charCodeAt(0) % AVATAR_COLORS.length];
const initials = n => n.split(" ").map(x=>x[0]).join("").slice(0,2);
const barColor = v => v>=90?"#00d97e":v>=75?"#ffb547":"#ff4d6d";

let currentFilter = "all";
let currentSearch = "";

// ── RENDER CHART ──
function renderChart() {
  const barsEl = document.getElementById("chartBars");
  const daysEl = document.getElementById("chartDays");
  barsEl.innerHTML = "";
  daysEl.innerHTML = "";
  WEEK.forEach(w => {
    const col = barColor(w.v);
    const bw = document.createElement("div");
    bw.className = "bar-wrap";
    bw.innerHTML = `
      <span class="bar-val" style="color:${col}">${w.v}%</span>
      <div class="bar-track">
        <div class="bar-fill" style="height:${w.v}%;background:linear-gradient(180deg,${col},${col}66)"></div>
      </div>`;
    barsEl.appendChild(bw);
    const d = document.createElement("div");
    d.style.cssText = "flex:1;text-align:center;font-size:9px;font-weight:600;color:var(--txt3)";
    d.textContent = w.d;
    daysEl.appendChild(d);
  });
}

// ── RENDER ACTIVITY ──
function renderActivity() {
  const el = document.getElementById("activityList");
  el.innerHTML = ACTIVITY.map((a,i) => `
    <div class="act-row">
      <div class="act-icon-wrap">
        <div class="act-icon" style="background:${a.ic}">${a.icon}</div>
        ${i<ACTIVITY.length-1?'<div class="act-line"></div>':''}
      </div>
      <div style="flex:1;min-width:0;padding-top:2px">
        <div class="act-title">${a.msg}</div>
        <div class="act-desc">${a.sub}</div>
      </div>
      <div class="act-time">${a.time}</div>
    </div>`).join("");
}

// ── RENDER CLASSES ──
function renderClasses() {
  const el = document.getElementById("classList");
  el.innerHTML = CLASSES.map(c => {
    const pct = Math.round(c.p/c.t*100);
    const col = barColor(pct);
    return `
    <div class="class-row">
      <div class="class-top">
        <div class="class-left">
          <div class="class-badge">${c.n}</div>
          <div><div class="class-name">${c.n}</div><div class="class-meta">${c.t} students</div></div>
        </div>
        <div class="class-pct" style="color:${col}">${pct}%</div>
      </div>
      <div class="prog-track">
        <div class="prog-fill" style="width:${pct}%;background:linear-gradient(90deg,${col},${col}88)"></div>
      </div>
    </div>`;
  }).join("");
}

// ── RENDER STUDENTS ──
function renderStudents() {
  const tbody = document.getElementById("studentTableBody");
  const data = STUDENTS.filter(s => {
    const ms = s.name.toLowerCase().includes(currentSearch.toLowerCase());
    const mf = currentFilter==="all" || s.fee===currentFilter;
    return ms && mf;
  });

  if(!data.length) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;padding:24px;color:var(--txt3);font-size:12px">No students found</td></tr>`;
    return;
  }

  const feeBadge = f => ({
    paid:   `<span class="badge b-green">Paid</span>`,
    pending:`<span class="badge b-amber">Pending</span>`,
    overdue:`<span class="badge b-red">Overdue</span>`,
  }[f]);

  const todayBadge = s => ({
    present:`<span class="badge b-green">Present</span>`,
    absent: `<span class="badge b-red">Absent</span>`,
    late:   `<span class="badge b-amber">Late</span>`,
  }[s]);

  tbody.innerHTML = data.map(s => `
    <tr>
      <td>
        <div class="stu-cell">
          <div class="stu-av" style="background:${aColor(s.name)}">${initials(s.name)}</div>
          <div>
            <div class="stu-name">${s.name}</div>
            <div class="stu-roll">#${s.roll}</div>
          </div>
        </div>
      </td>
      <td><span class="class-tag">${s.cls}</span></td>
      <td>
        <div class="att-cell">
          <div class="att-mini"><div class="att-fill" style="width:${s.att}%;background:${barColor(s.att)}"></div></div>
          <span class="att-pct" style="color:${barColor(s.att)}">${s.att}%</span>
        </div>
      </td>
      <td>${feeBadge(s.fee)}</td>
      <td>${todayBadge(s.today)}</td>
      <td><span class="view-link">View →</span></td>
    </tr>`).join("");
}

// ── NAV ──
document.querySelectorAll(".nav-item").forEach(item => {
  item.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active"));
    item.classList.add("active");
    document.getElementById("pageTitle").textContent = item.dataset.page || "Dashboard";
  });
});

// ── FILTER ──
function setFilter(f, btn) {
  currentFilter = f;
  document.querySelectorAll(".filter-tab").forEach(t=>t.classList.remove("active"));
  btn.classList.add("active");
  renderStudents();
}

function filterStudents() {
  currentSearch = document.getElementById("searchInput").value;
  renderStudents();
}

// ── MODAL ──
function openModal() {
  const o = document.getElementById("modalOverlay");
  o.style.display = "flex";
  requestAnimationFrame(()=>o.classList.add("show"));
}
function closeModal(e) {
  if(e && e.target !== document.getElementById("modalOverlay")) return;
  const o = document.getElementById("modalOverlay");
  o.classList.remove("show");
  setTimeout(()=>o.style.display="none", 200);
}
document.getElementById("modalOverlay").style.display = "none";

// ── INIT ──
renderChart();
renderActivity();
renderClasses();
renderStudents();
</script>
</body>
</html>