import axiosInstance from './axiosInstance'

export const markAttendanceApi = async (data) => {
  const res = await axiosInstance.post('/attendance', data)
  return res.data
}

export const markBulkAttendanceApi = async (records, date) => {
  const res = await axiosInstance.post('/attendance/bulk', { records, date })
  return res.data
}

export const getAttendanceApi = async (filters = {}) => {
  const res = await axiosInstance.get('/attendance', { params: filters })
  return res.data
}

export const getStudentAttendanceApi = async (studentId, month) => {
  const res = await axiosInstance.get(`/attendance/student/${studentId}`, {
    params: { month },
  })
  return res.data
}
