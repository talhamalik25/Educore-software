import axiosInstance from './axiosInstance'

export const getFeesApi = async (filters = {}) => {
  const res = await axiosInstance.get('/fees', { params: filters })
  return res.data
}

export const getFeeSummaryApi = async (month) => {
  const res = await axiosInstance.get('/fees/summary', { params: { month } })
  return res.data
}

export const createFeeApi = async (data) => {
  const res = await axiosInstance.post('/fees', data)
  return res.data
}

export const markFeePaidApi = async (id, data) => {
  const res = await axiosInstance.put(`/fees/${id}/pay`, data)
  return res.data
}
