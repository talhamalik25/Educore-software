import axiosInstance from './axiosInstance'

export const getNotificationsApi = async () => {
  const res = await axiosInstance.get('/notifications')
  return res.data
}

