import axiosInstance from './axiosInstance'

export const getUsersApi = async () => {
  const res = await axiosInstance.get('/users')
  return res.data
}

export const createUserApi = async (data) => {
  const res = await axiosInstance.post('/users', data)
  return res.data
}

export const updateUserApi = async (id, data) => {
  const res = await axiosInstance.put(`/users/${id}`, data)
  return res.data
}

export const deleteUserApi = async (id) => {
  const res = await axiosInstance.delete(`/users/${id}`)
  return res.data
}
