import axiosInstance from './axiosInstance';

export const addResultApi = (data) => axiosInstance.post('/results', data);

export const updateResultApi = (id, data) => axiosInstance.put(`/results/${id}`, data);

export const deleteResultApi = (id) => axiosInstance.delete(`/results/${id}`);

export const getResultsByStudentApi = (studentId) => axiosInstance.get(`/results/student/${studentId}`);

export const getResultsByClassApi = (className, section, examType) => {
    let url = `/results/class?class=${className}&section=${section}`;
    if (examType) url += `&examType=${examType}`;
    return axiosInstance.get(url);
};

export const getMyResultsApi = () => axiosInstance.get('/results/my');

export const getResultStatsApi = () => axiosInstance.get('/results/stats');
