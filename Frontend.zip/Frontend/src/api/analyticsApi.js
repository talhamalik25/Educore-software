import axiosInstance from './axiosInstance'

export const getOverviewAnalytics = () => axiosInstance.get('/analytics/overview')

export const getAttendanceAnalytics = (params) => axiosInstance.get('/analytics/attendance', { params })

export const getFeeAnalytics = () => axiosInstance.get('/analytics/fees')

export const getResultsAnalytics = (params) => axiosInstance.get('/analytics/results', { params })
