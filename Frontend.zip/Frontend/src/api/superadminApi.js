import axiosInstance from './axiosInstance'

export const getSuperAdminStatsApi = async () => {
  const res = await axiosInstance.get('/superadmin/stats')
  return res.data
}

export const getAllSchoolsApi = async () => {
  const res = await axiosInstance.get('/superadmin/schools')
  return res.data
}

export const createSchoolWithAdminApi = async (data) => {
  const res = await axiosInstance.post('/superadmin/schools', data)
  return res.data
}

export const updateSchoolApi = async (id, data) => {
  const res = await axiosInstance.put(`/superadmin/schools/${id}`, data)
  return res.data
}

export const toggleSchoolStatusApi = async (id) => {
  const res = await axiosInstance.patch(`/superadmin/schools/${id}/toggle`)
  return res.data
}
