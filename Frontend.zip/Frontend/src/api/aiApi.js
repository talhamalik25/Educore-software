import axiosInstance from './axiosInstance';

export const analyzeStudentApi = (studentId) => axiosInstance.post(`/ai/analyze/${studentId}`);

export const getStudentReportApi = (studentId) => axiosInstance.get(`/ai/report/${studentId}`);

export const getClassRiskReportApi = (className, section) => axiosInstance.get(`/ai/class?class=${className}&section=${section}`);

export const getSchoolRiskSummaryApi = () => axiosInstance.get('/ai/school-summary');
