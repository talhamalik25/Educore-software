import axiosInstance from './axiosInstance';

export const createHomeworkApi = (data) => axiosInstance.post('/homework', data, {
    headers: { 'Content-Type': 'multipart/form-data' }
});

export const getHomeworkApi = (params) => axiosInstance.get('/homework', { params });

export const getHomeworkDetailsApi = (id) => axiosInstance.get(`/homework/${id}`);

export const submitHomeworkApi = (id, data) => axiosInstance.post(`/homework/${id}/submit`, data, {
    headers: { 'Content-Type': 'multipart/form-data' }
});
