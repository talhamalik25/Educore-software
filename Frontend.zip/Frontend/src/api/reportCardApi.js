import axiosInstance from './axiosInstance';

export const getReportCardData = async (studentId, examType) => {
    const res = await axiosInstance.get(`/report-card/${studentId}`, {
        params: { examType }
    });
    return res.data;
};

export const downloadReportCardPDF = async (studentId, examType, studentName) => {
    const res = await axiosInstance.get(`/report-card/${studentId}/pdf`, {
        params: { examType },
        responseType: 'blob'
    });
    
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const link = document.createElement('a');
    link.href = url;
    const fileName = `ReportCard-${studentName.replace(/\s+/g, '-')}-${examType || 'Overall'}.pdf`;
    link.setAttribute('download', fileName);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
};
