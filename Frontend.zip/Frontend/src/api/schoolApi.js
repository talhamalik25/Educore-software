import axiosInstance from './axiosInstance'

export const getSchoolDetails = async () => {
  const res = await axiosInstance.get('/schools/my')
  return res.data
}

export const updateSchoolSettings = async (data) => {
  const res = await axiosInstance.put('/schools/settings', data)
  return res.data
}

export const uploadSchoolLogo = async (formData) => {
  const res = await axiosInstance.post('/schools/logo', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
  return res.data
}

