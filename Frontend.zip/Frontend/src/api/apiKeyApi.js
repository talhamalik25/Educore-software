import axiosInstance from './axiosInstance'

export const createApiKey = (data) => axiosInstance.post('/api-keys', data)
export const getApiKeys = () => axiosInstance.get('/api-keys')
export const revokeApiKey = (id) => axiosInstance.delete(`/api-keys/${id}`)
