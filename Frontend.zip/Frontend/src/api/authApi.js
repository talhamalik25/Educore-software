import axiosInstance from './axiosInstance'

// Login
export const loginApi = async (email, password) => {
  const res = await axiosInstance.post('/auth/login', { email, password })
  return res.data
}

// Register a new school + admin (public onboarding)
export const registerSchoolApi = async (data) => {
  const res = await axiosInstance.post('/auth/register-school', data)
  return res.data
}

// Register (existing school - needs schoolId)
export const registerApi = async (data) => {
  const res = await axiosInstance.post('/auth/register', data)
  return res.data
}

// Get current logged in user
export const getMeApi = async () => {
  const res = await axiosInstance.get('/auth/me')
  return res.data
}
