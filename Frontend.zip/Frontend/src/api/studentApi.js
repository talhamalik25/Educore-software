import axiosInstance from './axiosInstance'

export const getStudentsApi = async (filters = {}) => {
  const res = await axiosInstance.get('/students', { params: filters })
  return res.data
}

export const getStudentApi = async (id) => {
  const res = await axiosInstance.get(`/students/${id}`)
  return res.data
}

export const createStudentApi = async (data) => {
  const res = await axiosInstance.post('/students', data)
  return res.data
}

export const updateStudentApi = async (id, data) => {
  const res = await axiosInstance.put(`/students/${id}`, data)
  return res.data
}

export const deleteStudentApi = async (id) => {
  const res = await axiosInstance.delete(`/students/${id}`)
  return res.data
}
