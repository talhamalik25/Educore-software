import axiosInstance from './axiosInstance'

export const generateInvoice = (data) => axiosInstance.post('/invoices', data)
export const getInvoices = (params) => axiosInstance.get('/invoices', { params })
export const getStudentInvoices = (studentId) => axiosInstance.get(`/invoices/student/${studentId}`)
export const markInvoicePaid = (id, data) => axiosInstance.put(`/invoices/${id}/pay`, data)
export const deleteInvoice = (id) => axiosInstance.delete(`/invoices/${id}`)
