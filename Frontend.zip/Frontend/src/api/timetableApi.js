import axiosInstance from './axiosInstance'

export const getTimetableByClass = async (className, section) => {
  const res = await axiosInstance.get('/timetable/class', {
    params: { class: className, section }
  })
  return res.data
}

export const getTimetableByTeacher = async (teacherId) => {
  const res = await axiosInstance.get(`/timetable/teacher/${teacherId}`)
  return res.data
}

export const createOrUpdateTimetable = async (data) => {
  const res = await axiosInstance.post('/timetable', data)
  return res.data
}

export const deleteTimetableDay = async (id) => {
  const res = await axiosInstance.delete(`/timetable/${id}`)
  return res.data
}
