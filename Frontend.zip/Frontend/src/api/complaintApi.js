import axiosInstance from './axiosInstance';

export const submitComplaintApi = (data) => axiosInstance.post('/complaints', data);

export const getMyComplaintsApi = () => axiosInstance.get('/complaints/my');

export const getAllComplaintsApi = (filters) => axiosInstance.get('/complaints', { params: filters });

export const replyToComplaintApi = (id, adminReply) => axiosInstance.put(`/complaints/${id}/reply`, { adminReply });

export const updateComplaintStatusApi = (id, status) => axiosInstance.put(`/complaints/${id}/status`, { status });

export const deleteComplaintApi = (id) => axiosInstance.delete(`/complaints/${id}`);

export const getComplaintStatsApi = () => axiosInstance.get('/complaints/stats');
