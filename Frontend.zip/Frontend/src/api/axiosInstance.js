import axios from 'axios'

const axiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3000/api',
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor - automatically attach JWT token
axiosInstance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('educore_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error)
)

// Response interceptor - handle token expiry globally
axiosInstance.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    
    // Skip refresh logic for auth endpoints — let the caller handle 401s
    const authPaths = ['/auth/login', '/auth/register', '/auth/register-school', '/auth/refresh', '/auth/forgot-password', '/auth/reset-password']
    const isAuthRequest = authPaths.some(path => originalRequest.url?.includes(path))
    
    // If 401 error, not an auth request, and not already retrying
    if (error.response?.status === 401 && !isAuthRequest && !originalRequest._retry) {
      originalRequest._retry = true;
      
      const refreshToken = localStorage.getItem('educore_refreshToken');
      
      if (!refreshToken) {
        // No refresh token - clear storage and redirect
        localStorage.removeItem('educore_token');
        localStorage.removeItem('educore_refreshToken');
        localStorage.removeItem('educore_user');
        window.location.href = '/login';
        return Promise.reject(error);
      }

      try {
        // Attempt to refresh token
        // Use axios directly to avoid interceptors loop
        const apiBase = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';
        const refreshUrl = apiBase.endsWith('/') ? `${apiBase}auth/refresh` : `${apiBase}/auth/refresh`;
        
        const res = await axios.post(refreshUrl, { refreshToken });
        
        // Structured response from backend: { success, message, data: { token } }
        const { token } = res.data.data;
        localStorage.setItem('educore_token', token);
        
        // Retry original request with new token
        originalRequest.headers.Authorization = `Bearer ${token}`;
        return axiosInstance(originalRequest);
      } catch (refreshError) {
        // Refresh token failed/expired
        localStorage.removeItem('educore_token');
        localStorage.removeItem('educore_refreshToken');
        localStorage.removeItem('educore_user');
        window.location.href = '/login';
        return Promise.reject(refreshError);
      }
    }
    
    return Promise.reject(error);
  }
);

export default axiosInstance
