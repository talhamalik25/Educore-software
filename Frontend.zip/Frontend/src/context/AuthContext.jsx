import { createContext, useContext, useState, useEffect } from 'react'
import { loginApi, registerSchoolApi } from '../api/authApi'

const AuthContext = createContext(null)

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [token, setToken] = useState(null)
  const [loading, setLoading] = useState(true)

  // On app load - restore session from localStorage
  useEffect(() => {
    const savedToken = localStorage.getItem('educore_token')
    const savedUser = localStorage.getItem('educore_user')

    if (savedToken && savedUser) {
      setToken(savedToken)
      setUser(JSON.parse(savedUser))
    }

    setLoading(false)
  }, [])

  // Login function
  const login = async (email, password) => {
    const res = await loginApi(email, password)

    const { token, user } = res.data

    // Save to localStorage
    localStorage.setItem('educore_token', token)
    localStorage.setItem('educore_user', JSON.stringify(user))

    setToken(token)
    setUser(user)

    return user
  }

  // Register school + admin function
  const registerSchool = async (formData) => {
    const res = await registerSchoolApi(formData)

    const { token, user } = res.data

    // Save to localStorage
    localStorage.setItem('educore_token', token)
    localStorage.setItem('educore_user', JSON.stringify(user))

    setToken(token)
    setUser(user)

    return user
  }

  // Logout function
  const logout = () => {
    localStorage.removeItem('educore_token')
    localStorage.removeItem('educore_user')
    setToken(null)
    setUser(null)
  }

  const value = {
    user,
    token,
    loading,
    login,
    registerSchool,
    logout,
    isAuthenticated: !!user,
  }

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  )
}

// Custom hook
export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used inside AuthProvider')
  return context
}
