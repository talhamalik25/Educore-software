import { createContext, useContext, useState, useEffect } from 'react'
import { loginApi, registerSchoolApi, getMeApi } from '../api/authApi'
import axiosInstance from '../api/axiosInstance'

const AuthContext = createContext(null)

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [token, setToken] = useState(null)
  const [loading, setLoading] = useState(true)

  // On app load - restore and validate session from localStorage
  useEffect(() => {
    const restoreSession = async () => {
      const savedToken = localStorage.getItem('educore_token')
      const savedRefreshToken = localStorage.getItem('educore_refreshToken')
      const savedUser = localStorage.getItem('educore_user')

      if (savedToken) {
        try {
          // getMeApi will trigger a token refresh if the current token is expired
          // thanks to the axios interceptor.
          const res = await getMeApi()
          
          // Re-read token from localStorage in case it was refreshed during getMeApi
          const currentToken = localStorage.getItem('educore_token')
          const currentUser = res.data.user

          setToken(currentToken)
          setUser(currentUser)
          
          // Sync localStorage with latest user data from server
          localStorage.setItem('educore_user', JSON.stringify(currentUser))
        } catch (error) {
          console.error("Session restoration failed:", error)
          // Token expired or invalid — clear everything
          localStorage.removeItem('educore_token')
          localStorage.removeItem('educore_refreshToken')
          localStorage.removeItem('educore_user')
          setToken(null)
          setUser(null)
        }
      }

      setLoading(false)
    }

    restoreSession()
  }, [])

  // Login function
  const login = async (userData, token, refreshToken = null) => {
    // Save to localStorage
    localStorage.setItem('educore_token', token)
    if (refreshToken) localStorage.setItem('educore_refreshToken', refreshToken)
    localStorage.setItem('educore_user', JSON.stringify(userData))

    setToken(token)
    setUser(userData)

    return userData
  }

  // Register school + admin function
  const registerSchool = async (formData) => {
    const res = await registerSchoolApi(formData)

    const { token, refreshToken, user: userData } = res.data;

    // Save to localStorage
    localStorage.setItem('educore_token', token)
    localStorage.setItem('educore_refreshToken', refreshToken)
    localStorage.setItem('educore_user', JSON.stringify(userData))

    setToken(token)
    setUser(userData)

    return userData
  }

  // Logout function
  const logout = async () => {
    try {
      // Clear refreshToken from DB (fire and forget - don't block UI)
      await axiosInstance.post('/auth/logout').catch(() => {})
    } finally {
      localStorage.removeItem('educore_token')
      localStorage.removeItem('educore_refreshToken')
      localStorage.removeItem('educore_user')
      setToken(null)
      setUser(null)
    }
  }

  const value = {
    user,
    token,
    loading,
    login,
    registerSchool,
    logout,
    isAuthenticated: !!user,
  }

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  )
}

// Custom hook
export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used inside AuthProvider')
  return context
}
