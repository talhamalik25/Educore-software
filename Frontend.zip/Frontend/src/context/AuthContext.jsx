import { createContext, useContext, useState, useEffect } from 'react'
import { loginApi, registerSchoolApi, getMeApi } from '../api/authApi'
import axiosInstance from '../api/axiosInstance'
import { signInWithGoogle } from '../config/firebase'

const AuthContext = createContext(null)

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [token, setToken] = useState(null)
  const [loading, setLoading] = useState(true)

  const setSession = ({ token: nextToken, refreshToken, user: userData }) => {
    localStorage.setItem('educore_token', nextToken)
    localStorage.setItem('educore_refreshToken', refreshToken || '')
    localStorage.setItem('educore_user', JSON.stringify(userData))
    setToken(nextToken)
    setUser(userData)
  }

  const getDevUser = (email, role = 'admin') => ({
    _id: `dev-${role}`,
    name: `Demo ${role.charAt(0).toUpperCase()}${role.slice(1)}`,
    email,
    role,
    schoolId: role === 'superadmin' ? null : 'dev-school',
  })

  // On app load - restore and validate session from localStorage
  useEffect(() => {
    const restoreSession = async () => {
      const savedToken = localStorage.getItem('educore_token')
      const savedRefreshToken = localStorage.getItem('educore_refreshToken')
      const savedUser = localStorage.getItem('educore_user')

      if (savedToken) {
        // Dev fallback session (used when backend/db is temporarily unavailable)
        if (savedToken.startsWith('dev-token-') && savedUser) {
          try {
            const parsedUser = JSON.parse(savedUser)
            setToken(savedToken)
            setUser(parsedUser)
            setLoading(false)
            return
          } catch {
            // fall through to normal cleanup
          }
        }

        try {
          // getMeApi will trigger a token refresh if the current token is expired
          // thanks to the axios interceptor.
          const res = await getMeApi()
          
          // Re-read token from localStorage in case it was refreshed during getMeApi
          const currentToken = localStorage.getItem('educore_token')
          const currentUser = res.data.user

          setToken(currentToken)
          setUser(currentUser)
          
          // Sync localStorage with latest user data from server
          localStorage.setItem('educore_user', JSON.stringify(currentUser))
        } catch (error) {
          console.error("Session restoration failed:", error)
          // Token expired or invalid — clear everything
          localStorage.removeItem('educore_token')
          localStorage.removeItem('educore_refreshToken')
          localStorage.removeItem('educore_user')
          setToken(null)
          setUser(null)
        }
      }

      setLoading(false)
    }

    restoreSession()
  }, [])

  // Login function
  const login = async (email, password, role) => {
    try {
      const res = await loginApi(email, password, role)
      const payload = res?.data || res
      const { token, refreshToken, user: userData } = payload
      setSession({ token, refreshToken, user: userData })
      return userData
    } catch (error) {
      // Developer fallback: allow local screen access if backend/db is down.
      const isDev = import.meta.env.DEV
      const noResponse = !error?.response
      const serverUnavailable = [500, 502, 503, 504].includes(error?.response?.status)
      if (isDev && (noResponse || serverUnavailable)) {
        const userData = getDevUser(email, role)
        const devToken = `dev-token-${role}`
        setSession({ token: devToken, refreshToken: '', user: userData })
        return userData
      }
      throw error
    }
  }

  const loginWithGoogle = async () => {
    const { idToken } = await signInWithGoogle()
    const res = await axiosInstance.post('/auth/google', { idToken })
    const { token, refreshToken, user: userData } = res.data.data

    localStorage.setItem('educore_token', token)
    localStorage.setItem('educore_refreshToken', refreshToken)
    localStorage.setItem('educore_user', JSON.stringify(userData))

    setToken(token)
    setUser(userData)
    return userData
  }

  // Register school + admin function
  const registerSchool = async (formData) => {
    const res = await registerSchoolApi(formData)

    const { token, refreshToken, user: userData } = res.data;
    setSession({ token, refreshToken, user: userData })

    return userData
  }

  // Logout function
  const logout = async () => {
    try {
      // Clear refreshToken from DB (fire and forget - don't block UI)
      await axiosInstance.post('/auth/logout').catch(() => {})
    } finally {
      localStorage.removeItem('educore_token')
      localStorage.removeItem('educore_refreshToken')
      localStorage.removeItem('educore_user')
      setToken(null)
      setUser(null)
    }
  }

  const value = {
    user,
    token,
    loading,
    login,
    registerSchool,
    loginWithGoogle,
    logout,
    isAuthenticated: !!user,
  }

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  )
}

// Custom hook
export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used inside AuthProvider')
  return context
}
