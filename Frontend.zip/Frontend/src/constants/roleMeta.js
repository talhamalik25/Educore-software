export const ROLE_META = {
  admin: {
    title: 'Admin',
    description: 'Manage your school',
    icon: '🏫',
    accent: '#0a3d1f',
    borderColor: 'border-[#0a3d1f]',
    bgColor: 'bg-[#0a3d1f]/10',
    textColor: 'text-[#0a3d1f]',
    id: 'admin'
  },
  teacher: {
    title: 'Teacher',
    description: 'Track your students',
    icon: '📚',
    accent: '#1d4ed8',
    borderColor: 'border-[#1d4ed8]',
    bgColor: 'bg-[#1d4ed8]/10',
    textColor: 'text-[#1d4ed8]',
    id: 'teacher'
  },
  parent: {
    title: 'Parent',
    description: 'Stay close to your child',
    icon: '👨👩👧',
    accent: '#7c3aed',
    borderColor: 'border-[#7c3aed]',
    bgColor: 'bg-[#7c3aed]/10',
    textColor: 'text-[#7c3aed]',
    id: 'parent'
  },
  superadmin: {
    title: 'Super Admin',
    description: 'Platform Administration Portal',
    icon: '🛡️',
    accent: '#dc2626',
    borderColor: 'border-[#dc2626]',
    bgColor: 'bg-[#dc2626]/10',
    textColor: 'text-[#dc2626]',
    id: 'superadmin'
  }
};

export const ROLE_CONFIG = {
  admin: {
    accent: "#0a3d1f",
    accentHover: "#062b16",
    accentLight: "rgba(10,61,31,0.06)",
    accentRing: "rgba(10,61,31,0.2)",
    placeholder: "admin@educore.pk",
    label: "School Administrator",
  },
  teacher: {
    accent: "#1d4ed8",
    accentHover: "#1e40af",
    accentLight: "rgba(29,78,216,0.06)",
    accentRing: "rgba(29,78,216,0.2)",
    placeholder: "teacher@educore.pk",
    label: "Faculty Portal",
  },
  parent: {
    accent: "#7c3aed",
    accentHover: "#6d28d9",
    accentLight: "rgba(124,58,237,0.06)",
    accentRing: "rgba(124,58,237,0.2)",
    placeholder: "parent@educore.pk",
    label: "Parent Portal",
  },
  superadmin: {
    accent: "#dc2626",
    accentHover: "#b91c1c",
    accentLight: "rgba(220,38,38,0.06)",
    accentRing: "rgba(220,38,38,0.2)",
    placeholder: "superadmin@educore.pk",
    label: "Super Admin Portal",
  }
};
