import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getClassRiskReportApi, analyzeStudentApi } from '../../api/aiApi'
import { getStudentsApi } from '../../api/studentApi'
import { 
  Brain, 
  Sparkles, 
  Search, 
  Filter, 
  ChevronRight, 
  X, 
  TrendingUp, 
  TrendingDown, 
  Lightbulb, 
  Loader2,
  FileText,
  AlertCircle
} from 'lucide-react'

const TeacherAIAnalyzer = () => {
  const [students, setStudents] = useState([])
  const [loading, setLoading] = useState(false)
  const [analyzing, setAnalyzing] = useState(false)
  const [progress, setProgress] = useState({ current: 0, total: 0 })
  const [filters, setFilters] = useState({ class: '', section: '', risk: 'all' })
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [showModal, setShowModal] = useState(false)

  const fetchClassData = async () => {
    if (!filters.class || !filters.section) return
    setLoading(true)
    try {
      const res = await getClassRiskReportApi(filters.class, filters.section)
      setStudents(res.data?.data ?? [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (filters.class && filters.section) {
      fetchClassData()
    }
  }, [filters.class, filters.section])

  const handleAnalyzeClass = async () => {
    if (students.length === 0) return
    setAnalyzing(true)
    setProgress({ current: 0, total: students.length })

    for (let i = 0; i < students.length; i++) {
      try {
        await analyzeStudentApi(students[i]._id)
        setProgress(prev => ({ ...prev, current: i + 1 }))
      } catch (err) {
        console.error(`Failed to analyze student ${students[i].name}:`, err)
      }
    }

    setAnalyzing(false)
    fetchClassData()
    alert('Class analysis synchronized successfully.')
  }

  const filteredStudents = students.filter(s => {
    if (filters.risk === 'all') return true
    return s.aiReport?.riskLevel === filters.risk
  })

  const getRiskBadge = (level) => {
    switch (level) {
      case 'high': return 'bg-red-500/10 text-red-400 border-red-500/20'
      case 'medium': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
      case 'low': return 'bg-green-500/10 text-green-400 border-green-500/20'
      default: return 'bg-muted-700 text-muted-400 border-muted-600'
    }
  }

  const inputClass = "w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-3 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all text-sm"

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        {/* Header */}
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8 mb-12 animate-fade-in">
          <div>
            <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter flex items-center gap-4">
              <Brain className="text-primary-400" size={40} />
              Class Intelligence
            </h1>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
               <span className="w-1.5 h-1.5 bg-primary-500 rounded-full animate-pulse" />
               Predictive Performance Node
            </p>
          </div>
          <button
            onClick={handleAnalyzeClass}
            disabled={analyzing || students.length === 0}
            className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all duration-300 active:scale-95 cursor-pointer shadow-xl bg-primary-500 text-white hover:bg-primary-600 shadow-primary-900/20 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {analyzing ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
            Analyze Whole Class
          </button>
        </div>

        {/* Progress Bar */}
        {analyzing && (
          <div className="mb-10 bg-muted-800 border border-muted-700 p-8 rounded-[2rem] animate-fade-up">
            <div className="flex justify-between items-center mb-4">
              <p className="text-xs font-black uppercase tracking-widest text-muted-400">Neural Sync in Progress...</p>
              <p className="text-xs font-black text-primary-400">{progress.current} / {progress.total} Nodes</p>
            </div>
            <div className="w-full h-3 bg-muted-900 rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary-500 transition-all duration-500 shadow-[0_0_20px_rgba(0,168,150,0.5)]"
                style={{ width: `${(progress.current / progress.total) * 100}%` }}
              />
            </div>
          </div>
        )}

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10 bg-muted-800/50 p-6 rounded-[2rem] border border-muted-700/50">
          <div>
            <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Academic Class</label>
            <input 
              type="text" 
              placeholder="e.g. 10" 
              className={inputClass}
              value={filters.class}
              onChange={e => setFilters({...filters, class: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Section Node</label>
            <input 
              type="text" 
              placeholder="e.g. A" 
              className={inputClass}
              value={filters.section}
              onChange={e => setFilters({...filters, section: e.target.value})}
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Risk Vector Filter</label>
            <div className="flex gap-2">
              {['all', 'high', 'medium', 'low'].map(r => (
                <button
                  key={r}
                  onClick={() => setFilters({...filters, risk: r})}
                  className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${
                    filters.risk === r 
                    ? 'bg-primary-500/10 border-primary-500 text-primary-400 shadow-lg shadow-primary-500/10' 
                    : 'bg-muted-900 border-muted-700 text-muted-500 hover:border-muted-600'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="bg-muted-800 border border-muted-700 rounded-[2.5rem] overflow-hidden shadow-2xl">
          {!filters.class || !filters.section ? (
            <div className="p-20 text-center">
               <div className="w-20 h-20 bg-muted-900 rounded-3xl flex items-center justify-center mx-auto mb-6 text-muted-500">
                  <Search size={32} />
               </div>
               <h3 className="font-syne text-xl font-bold text-white mb-2">Select Class Node</h3>
               <p className="text-muted-500 text-sm">Synchronize with a class to view predictive performance analytics.</p>
            </div>
          ) : loading ? (
            <div className="p-20 text-center animate-pulse">
               <p className="text-muted-500 font-black uppercase tracking-[0.2em]">Retrieving Intelligence Data...</p>
            </div>
          ) : filteredStudents.length === 0 ? (
            <div className="p-20 text-center">
               <h3 className="font-syne text-xl font-bold text-white mb-2">No Records Found</h3>
               <p className="text-muted-500 text-sm">No students match the current filtering parameters.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-muted-900/50">
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest">Student</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-center">Risk Level</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-center">Avg Score</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest">Weak Subjects</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-muted-700/50">
                  {filteredStudents.map(s => (
                    <tr 
                      key={s._id} 
                      className={`hover:bg-muted-700/30 transition-colors group ${s.aiReport?.riskLevel === 'high' ? 'bg-red-500/5' : ''}`}
                    >
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl bg-muted-900 flex items-center justify-center text-primary-400 font-bold uppercase">
                            {s.name.charAt(0)}
                          </div>
                          <div>
                            <p className="text-sm font-bold text-white">{s.name}</p>
                            <p className="text-[10px] text-muted-500 font-medium">Roll: {s.rollNumber}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6 text-center">
                        <span className={`px-4 py-1.5 rounded-lg text-[10px] font-black border uppercase ${getRiskBadge(s.aiReport?.riskLevel)}`}>
                          {s.aiReport?.riskLevel ?? 'untested'}
                        </span>
                      </td>
                      <td className="px-8 py-6 text-center">
                        <span className="text-sm font-bold text-white">{s.aiReport?.averageGrade ?? '0'}%</span>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex flex-wrap gap-2 max-w-xs">
                          {s.aiReport?.weakSubjects?.slice(0, 2).map((sub, i) => (
                            <span key={i} className="px-3 py-1 bg-red-500/5 text-red-400 text-[10px] font-bold rounded-lg border border-red-500/10 capitalize">
                              {sub}
                            </span>
                          ))}
                          {s.aiReport?.weakSubjects?.length > 2 && (
                            <span className="text-[10px] text-muted-500 font-black">+ {s.aiReport.weakSubjects.length - 2} more</span>
                          )}
                        </div>
                      </td>
                      <td className="px-8 py-6 text-right">
                        <button 
                          onClick={() => { setSelectedStudent(s); setShowModal(true); }}
                          className="inline-flex items-center gap-2 px-5 py-2.5 bg-muted-900 text-muted-400 hover:text-white hover:bg-muted-700 rounded-xl transition-all text-[10px] font-black uppercase tracking-widest border border-muted-700"
                        >
                          <FileText size={14} />
                          View Report
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Modal: AI Report */}
        {showModal && selectedStudent && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={() => setShowModal(false)} />
            <div className="relative w-full max-w-2xl bg-muted-800 border border-muted-700 rounded-[3rem] shadow-2xl overflow-hidden animate-fade-up">
              <div className="p-10 border-b border-muted-700/50 flex justify-between items-center bg-muted-800/50">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-primary-500/10 flex items-center justify-center text-primary-400">
                    <Brain size={24} />
                  </div>
                  <div>
                    <h2 className="font-syne text-2xl font-bold text-white">{selectedStudent.name}</h2>
                    <p className="text-[10px] font-black text-muted-500 uppercase tracking-widest">Neural Performance Audit</p>
                  </div>
                </div>
                <button onClick={() => setShowModal(false)} className="p-3 bg-muted-900 rounded-2xl hover:bg-muted-700 text-muted-400">
                  <X size={20} />
                </button>
              </div>

              {!selectedStudent.aiReport ? (
                <div className="p-20 text-center">
                   <AlertCircle size={48} className="mx-auto mb-6 text-muted-500" />
                   <p className="text-muted-400 font-medium">No intelligence data available. Please run analysis first.</p>
                </div>
              ) : (
                <div className="p-10 space-y-10 max-h-[70vh] overflow-y-auto custom-scrollbar">
                  {/* Performance Bars */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-muted-500">
                        <span>Attendance Sync</span>
                        <span className="text-white">{selectedStudent.aiReport.attendanceScore}%</span>
                      </div>
                      <div className="h-2 bg-muted-900 rounded-full overflow-hidden">
                        <div className="h-full bg-primary-500 transition-all duration-1000" style={{ width: `${selectedStudent.aiReport.attendanceScore}%` }} />
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-muted-500">
                        <span>Aggregate Grade</span>
                        <span className="text-white">{selectedStudent.aiReport.averageGrade}%</span>
                      </div>
                      <div className="h-2 bg-muted-900 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500 transition-all duration-1000" style={{ width: `${selectedStudent.aiReport.averageGrade}%` }} />
                      </div>
                    </div>
                  </div>

                  {/* Subject Matrix */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="p-6 bg-red-500/5 border border-red-500/10 rounded-3xl">
                      <p className="text-[10px] font-black text-red-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <TrendingDown size={14} /> Weak Vectors
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {selectedStudent.aiReport.weakSubjects?.map((sub, i) => (
                          <span key={i} className="px-3 py-1 bg-red-500/10 text-red-400 text-[10px] font-bold rounded-lg border border-red-500/10 capitalize">
                            {sub}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="p-6 bg-green-500/5 border border-green-500/10 rounded-3xl">
                      <p className="text-[10px] font-black text-green-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <TrendingUp size={14} /> Power Vectors
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {selectedStudent.aiReport.strongSubjects?.map((sub, i) => (
                          <span key={i} className="px-3 py-1 bg-green-500/10 text-green-400 text-[10px] font-bold rounded-lg border border-green-500/10 capitalize">
                            {sub}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* AI Summary */}
                  <div className="p-8 bg-muted-900 border border-muted-700 rounded-[2.5rem] relative">
                    <div className="absolute top-0 right-0 p-6 text-primary-500/10"><Sparkles size={40} /></div>
                    <h3 className="text-[10px] font-black uppercase tracking-widest text-primary-400 mb-4">Intelligence Narrative</h3>
                    <p className="text-sm text-muted-300 italic leading-relaxed">"{selectedStudent.aiReport.summary}"</p>
                  </div>

                  {/* Recommendations */}
                  <div className="space-y-4">
                    <h3 className="text-[10px] font-black uppercase tracking-widest text-muted-500 flex items-center gap-2 px-2">
                      <Lightbulb size={14} className="text-yellow-400" /> Improvement Protocol
                    </h3>
                    <div className="space-y-2">
                      {selectedStudent.aiReport.recommendations?.map((rec, i) => (
                        <div key={i} className="flex items-start gap-4 p-5 bg-muted-900/50 border border-muted-700/50 rounded-2xl">
                          <span className="w-6 h-6 rounded-lg bg-muted-800 flex items-center justify-center text-[10px] font-black text-primary-400 shrink-0">0{i+1}</span>
                          <p className="text-sm text-muted-400">{rec}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

      </main>
    </div>
  )
}

export default TeacherAIAnalyzer
