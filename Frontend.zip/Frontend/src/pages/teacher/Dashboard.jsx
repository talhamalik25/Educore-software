import { useState, useEffect } from 'react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import StatCard from '../../components/ui/StatCard'
import { Card, CardHeader, CardContent } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import { getStudentsApi } from '../../api/studentApi'
import { getAttendanceApi } from '../../api/attendanceApi'
import { getTimetableByTeacher } from '../../api/timetableApi'
import { useAuth } from '../../context/AuthContext'
import { 
  Users, 
  CheckCircle2, 
  UserPlus, 
  Calendar,
  BookOpen,
  ArrowRight,
  Clock,
  Sparkles
} from 'lucide-react'

const TeacherDashboard = () => {
  const { user } = useAuth()
  const [students, setStudents] = useState([])
  const [todayAttendance, setTodayAttendance] = useState([])
  const [todaySchedule, setTodaySchedule] = useState([])
  const [loading, setLoading] = useState(true)

  const today = new Date().toISOString().split('T')[0]
  const todayDay = new Date().toLocaleDateString('en-US', { weekday: 'long' })

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [studentsRes, attendanceRes, timetableRes] = await Promise.all([
          getStudentsApi(),
          getAttendanceApi({ date: today }),
          getTimetableByTeacher(user._id)
        ])
        setStudents(studentsRes.data?.data?.students ?? [])
        setTodayAttendance(attendanceRes.data?.data?.records ?? [])
        
        // Extract today's schedule
        const fullSchedule = timetableRes?.data?.schedule ?? []
        const todayEntry = fullSchedule.find(entry => entry.day === todayDay)
        setTodaySchedule(todayEntry?.periods ?? [])
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  const markedToday = todayAttendance.length
  const presentToday = todayAttendance.filter(a => a.status === 'present').length
  const attendanceRate = students.length > 0 ? Math.round((presentToday / students.length) * 100) : 0

  const riskCounts = students.reduce((acc, student) => {
    const risk = student.aiReport?.riskLevel || 'none';
    if (acc[risk] !== undefined) acc[risk]++;
    return acc;
  }, { high: 0, medium: 0, low: 0 });

  const totalAnalyzed = riskCounts.high + riskCounts.medium + riskCounts.low;

  return (
    <DashboardLayout>
       {/* Header */}
       <div className="mb-10">
        <h1 className="font-syne text-4xl font-bold text-white tracking-tight mb-2">
          Assalam o Alaikum, {user?.name?.split(' ')[0]}
        </h1>
        <p className="text-muted-500 font-medium flex items-center gap-2 uppercase tracking-widest text-[10px]">
          <Calendar size={14} className="text-primary-500" />
          {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })} — Faculty Portal
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
        <StatCard
          label="Assigned Students"
          value={students.length}
          icon={Users}
          color="blue"
          loading={loading}
        />
        <StatCard
          label="Present Today"
          value={presentToday}
          icon={CheckCircle2}
          color="primary"
          loading={loading}
        />
        <StatCard
          label="Attendance Rate"
          value={`${attendanceRate}%`}
          icon={BookOpen}
          color="purple"
          loading={loading}
        />
      </div>

      {/* Class Health Card */}
      <Card className="mb-10 overflow-hidden relative group">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <h2 className="font-syne text-xl font-bold text-white">Class Health Analytics</h2>
            <p className="text-xs text-muted-500 mt-1">Real-time risk distribution across your students</p>
          </div>
          <div className="w-10 h-10 bg-primary-500/10 rounded-xl flex items-center justify-center text-primary-400 group-hover:scale-110 transition-transform">
            <Sparkles size={20} />
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.5)]" />
                  <span className="text-sm font-medium text-muted-300">High Risk</span>
                </div>
                <span className="text-lg font-bold text-white">{riskCounts.high}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.5)]" />
                  <span className="text-sm font-medium text-muted-300">Medium Risk</span>
                </div>
                <span className="text-lg font-bold text-white">{riskCounts.medium}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]" />
                  <span className="text-sm font-medium text-muted-300">Low Risk</span>
                </div>
                <span className="text-lg font-bold text-white">{riskCounts.low}</span>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full mt-4 border-primary-500/30 text-primary-400 hover:bg-primary-500/10 hover:border-primary-500 transition-all"
                onClick={() => window.location.href = '/teacher/ai-analyzer'}
              >
                Run Performance Analysis
              </Button>
            </div>

            {/* Simple Bar Chart */}
            <div className="flex items-end justify-around h-40 gap-4 px-4 bg-surface-base/50 rounded-3xl border border-white/5 py-6">
              <div className="flex flex-col items-center gap-2 flex-1 h-full justify-end">
                <div 
                  className="w-full bg-red-500 rounded-t-xl transition-all duration-1000 shadow-[0_0_20px_rgba(239,68,68,0.2)]" 
                  style={{ height: `${totalAnalyzed ? (riskCounts.high / totalAnalyzed) * 100 : 0}%`, minHeight: '4px' }}
                />
                <span className="text-[10px] font-black uppercase tracking-tighter text-muted-500">High</span>
              </div>
              <div className="flex flex-col items-center gap-2 flex-1 h-full justify-end">
                <div 
                  className="w-full bg-yellow-500 rounded-t-xl transition-all duration-1000 shadow-[0_0_20px_rgba(234,179,8,0.2)]" 
                  style={{ height: `${totalAnalyzed ? (riskCounts.medium / totalAnalyzed) * 100 : 0}%`, minHeight: '4px' }}
                />
                <span className="text-[10px] font-black uppercase tracking-tighter text-muted-500">Med</span>
              </div>
              <div className="flex flex-col items-center gap-2 flex-1 h-full justify-end">
                <div 
                  className="w-full bg-green-500 rounded-t-xl transition-all duration-1000 shadow-[0_0_20px_rgba(34,197,94,0.2)]" 
                  style={{ height: `${totalAnalyzed ? (riskCounts.low / totalAnalyzed) * 100 : 0}%`, minHeight: '4px' }}
                />
                <span className="text-[10px] font-black uppercase tracking-tighter text-muted-500">Low</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        {/* Attendance Action Card */}
        <Card className="flex flex-col justify-between overflow-hidden group">
          <div className="relative z-10">
             <CardHeader>
               <h2 className="font-syne text-2xl font-bold text-white mb-2">Daily Attendance</h2>
               <p className="text-muted-500 text-sm leading-relaxed max-w-md">
                 {markedToday === 0 
                   ? "Daily synchronization required. Please verify student presence for today's session."
                   : `Cloud Sync Active: ${markedToday} records updated and verified.`}
               </p>
             </CardHeader>
             <CardContent className="mt-4">
                <Button 
                  onClick={() => window.location.href = '/teacher/attendance'}
                  className="gap-2 group/btn"
                >
                  Launch Attendance Center
                  <ArrowRight size={16} className="group-hover/btn:translate-x-1 transition-transform" />
                </Button>
             </CardContent>
          </div>
          <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-primary-600/10 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
        </Card>

        {/* Quick Tools */}
        <Card>
           <CardHeader>
             <h2 className="font-syne text-xl font-bold text-white">Class Management</h2>
           </CardHeader>
           <CardContent className="grid grid-cols-2 gap-4">
              <a href="/teacher/homework" className="p-6 rounded-3xl bg-surface-base border border-surface-border hover:border-primary-500/30 transition-all text-center group">
                <div className="w-12 h-12 rounded-2xl bg-muted-800 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <BookOpen size={20} className="text-muted-400 group-hover:text-primary-400" />
                </div>
                <p className="text-xs font-black uppercase tracking-widest text-muted-500 group-hover:text-white">Assignments</p>
              </a>
              <a href="/teacher/results" className="p-6 rounded-3xl bg-surface-base border border-surface-border hover:border-primary-500/30 transition-all text-center group">
                <div className="w-12 h-12 rounded-2xl bg-muted-800 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <CheckCircle2 size={20} className="text-muted-400 group-hover:text-primary-400" />
                </div>
                <p className="text-xs font-black uppercase tracking-widest text-muted-500 group-hover:text-white">Grading</p>
              </a>
           </CardContent>
        </Card>
      </div>

      {/* Today's Schedule */}
      <div className="mt-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <h2 className="font-syne text-xl font-bold text-white">Today's Schedule</h2>
            <div className="px-3 py-1 bg-primary-500/10 text-primary-400 text-[10px] font-black uppercase tracking-widest rounded-lg border border-primary-500/20">
              {todayDay}
            </div>
          </CardHeader>
          <CardContent>
            {todaySchedule.length === 0 ? (
              <div className="py-10 text-center text-muted-500 italic">No periods scheduled for today.</div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
                {todaySchedule.map((p, idx) => (
                  <div key={idx} className="bg-surface-base border border-surface-border p-6 rounded-[2rem] hover:border-primary-500/30 transition-all group">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-[10px] font-black text-muted-500 uppercase tracking-widest">Period {p.periodNumber}</span>
                      <Clock size={14} className="text-primary-500" />
                    </div>
                    <h4 className="font-syne text-lg font-bold text-white mb-1">{p.subject}</h4>
                    <p className="text-xs text-muted-400 font-medium mb-4">{p.startTime} — {p.endTime}</p>
                    <div className="flex items-center gap-2 pt-4 border-t border-surface-border/50">
                      <div className="w-6 h-6 rounded-lg bg-muted-800 flex items-center justify-center text-[10px] font-bold text-primary-400">
                        {p.room || 'R'}
                      </div>
                      <span className="text-[10px] font-black text-muted-500 uppercase tracking-widest">Room {p.room || 'TBD'}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

    </DashboardLayout>
  )
}

export default TeacherDashboard
