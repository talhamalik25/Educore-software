import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getStudentsApi } from '../../api/studentApi'
import { getAttendanceApi } from '../../api/attendanceApi'
import { useAuth } from '../../context/AuthContext'

const StatCard = ({ label, value, icon, color }) => (
  <div className="bg-muted-800 border border-muted-700 rounded-3xl p-8 shadow-xl hover:shadow-2xl hover:border-muted-600 transition-all duration-300 group">
    <div className="flex items-center justify-between mb-5">
      <div className={`p-4 rounded-2xl ${color} bg-opacity-10 shadow-inner group-hover:scale-110 transition-transform duration-300`}>
        <span className="text-3xl leading-none">{icon}</span>
      </div>
      <span className={`text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-widest ${color} bg-opacity-10 border border-current border-opacity-10`}>Active</span>
    </div>
    <p className="text-4xl font-syne font-bold text-white tracking-tighter mb-2">{value ?? '—'}</p>
    <p className="text-muted-500 text-xs font-bold uppercase tracking-widest">{label}</p>
  </div>
)

const TeacherDashboard = () => {
  const { user } = useAuth()
  const [students, setStudents] = useState([])
  const [todayAttendance, setTodayAttendance] = useState([])
  const [loading, setLoading] = useState(true)

  const today = new Date().toISOString().split('T')[0]

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [studentsRes, attendanceRes] = await Promise.all([
          getStudentsApi(),
          getAttendanceApi({ date: today }),
        ])
        setStudents(studentsRes.data?.students ?? [])
        setTodayAttendance(attendanceRes.data?.records ?? [])
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  const markedToday = todayAttendance.length
  const presentToday = todayAttendance.filter(a => a.status === 'present').length
  const absentToday = todayAttendance.filter(a => a.status === 'absent').length

  const currentDayStr = new Date().toLocaleDateString('en-PK', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />

      <main className="flex-1 p-6 md:p-10 lg:p-14 overflow-y-auto">

        {/* Header (Refined Dark Mode) */}
        <div className="mb-12 animate-fade-in relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary-500/5 blur-[80px] rounded-full pointer-events-none" />
          <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">
            Assalam o Alaikum, {user?.name?.split(' ')[0]} 👋
          </h1>
          <div className="flex items-center gap-3 mt-3">
             <div className="w-1.5 h-1.5 rounded-full bg-primary-500 shadow-[0_0_10px_rgba(16,185,129,0.5)] animate-pulse" />
             <p className="text-muted-500 text-[11px] font-black uppercase tracking-[0.2em]">{currentDayStr}</p>
          </div>
        </div>

        {/* Stats Grid - Responsive Column stack */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {loading ? (
            [...Array(3)].map((_, i) => (
              <div key={i} className="bg-muted-800 border border-muted-700 rounded-3xl p-8 h-40 animate-pulse shadow-xl" />
            ))
          ) : (
            <>
              <StatCard
                label="Registered Students"
                value={students.length}
                icon="👥"
                color="text-blue-400"
              />
              <StatCard
                label="Present Today"
                value={presentToday}
                icon="✅"
                color="text-primary-400"
              />
              <StatCard
                label="Absent Today"
                value={absentToday}
                icon="⚠️"
                color="text-rose-400"
              />
            </>
          )}
        </div>

        {/* Quick Attendance Action */}
        <div className="animate-fade-up">
          <div className="bg-muted-800 border border-muted-700 rounded-[2.5rem] p-8 md:p-12 shadow-2xl relative overflow-hidden group">
            <div className="absolute top-[-50px] right-[-50px] w-48 h-48 bg-primary-500/5 blur-[50px] rounded-full pointer-events-none group-hover:bg-primary-500/10 transition-colors duration-500" />
            
            <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
              <div className="flex-1">
                <h2 className="font-syne text-2xl font-bold text-white mb-3">Attendance Control Center</h2>
                <p className="text-muted-400 text-sm max-w-lg leading-relaxed mb-6">
                  {markedToday === 0 
                    ? "Aaj ki attendance abhi tak mark nahi hui. System requires immediate synchronization." 
                    : `Successful daily sync: ${markedToday} students processed and uploaded to cloud.`}
                </p>
                <div className="flex flex-wrap gap-4">
                  <a
                    href="/teacher/attendance"
                    className="inline-flex items-center gap-2 bg-primary-500 hover:bg-primary-600 active:scale-95 text-white px-8 py-4 rounded-2xl text-xs font-black uppercase tracking-[0.2em] transition-all duration-300 shadow-xl shadow-primary-900/20"
                  >
                    Mark Today's Attendance
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
                  </a>
                </div>
              </div>
              
              <div className="hidden md:block w-32 h-32 bg-muted-900 border border-muted-700 rounded-3xl flex items-center justify-center text-4xl shadow-inner animate-float">
                📋
              </div>
            </div>
          </div>
        </div>

      </main>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        .animate-float {
          animation: float 4s ease-in-out infinite;
        }
      `}} />
    </div>
  )
}

export default TeacherDashboard
