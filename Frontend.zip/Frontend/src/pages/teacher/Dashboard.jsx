import { useState, useEffect } from 'react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import StatCard from '../../components/ui/StatCard'
import { Card, CardHeader, CardContent } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import { getStudentsApi } from '../../api/studentApi'
import { getAttendanceApi } from '../../api/attendanceApi'
import { useAuth } from '../../context/AuthContext'
import { 
  Users, 
  CheckCircle2, 
  UserPlus, 
  Calendar,
  BookOpen,
  ArrowRight
} from 'lucide-react'

const TeacherDashboard = () => {
  const { user } = useAuth()
  const [students, setStudents] = useState([])
  const [todayAttendance, setTodayAttendance] = useState([])
  const [loading, setLoading] = useState(true)

  const today = new Date().toISOString().split('T')[0]

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [studentsRes, attendanceRes] = await Promise.all([
          getStudentsApi(),
          getAttendanceApi({ date: today }),
        ])
        setStudents(studentsRes.data?.data?.students ?? [])
        setTodayAttendance(attendanceRes.data?.data?.records ?? [])
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  const markedToday = todayAttendance.length
  const presentToday = todayAttendance.filter(a => a.status === 'present').length
  const attendanceRate = students.length > 0 ? Math.round((presentToday / students.length) * 100) : 0

  return (
    <DashboardLayout>
       {/* Header */}
       <div className="mb-10">
        <h1 className="font-syne text-4xl font-bold text-white tracking-tight mb-2">
          Assalam o Alaikum, {user?.name?.split(' ')[0]}
        </h1>
        <p className="text-muted-500 font-medium flex items-center gap-2 uppercase tracking-widest text-[10px]">
          <Calendar size={14} className="text-primary-500" />
          {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })} — Faculty Portal
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
        <StatCard
          label="Assigned Students"
          value={students.length}
          icon={Users}
          color="blue"
          loading={loading}
        />
        <StatCard
          label="Present Today"
          value={presentToday}
          icon={CheckCircle2}
          color="primary"
          loading={loading}
        />
        <StatCard
          label="Attendance Rate"
          value={`${attendanceRate}%`}
          icon={BookOpen}
          color="purple"
          loading={loading}
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        {/* Attendance Action Card */}
        <Card className="flex flex-col justify-between overflow-hidden group">
          <div className="relative z-10">
             <CardHeader>
               <h2 className="font-syne text-2xl font-bold text-white mb-2">Daily Attendance</h2>
               <p className="text-muted-500 text-sm leading-relaxed max-w-md">
                 {markedToday === 0 
                   ? "Daily synchronization required. Please verify student presence for today's session."
                   : `Cloud Sync Active: ${markedToday} records updated and verified.`}
               </p>
             </CardHeader>
             <CardContent className="mt-4">
                <Button 
                  onClick={() => window.location.href = '/teacher/attendance'}
                  className="gap-2 group/btn"
                >
                  Launch Attendance Center
                  <ArrowRight size={16} className="group-hover/btn:translate-x-1 transition-transform" />
                </Button>
             </CardContent>
          </div>
          <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-primary-600/10 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
        </Card>

        {/* Quick Tools */}
        <Card>
           <CardHeader>
             <h2 className="font-syne text-xl font-bold text-white">Class Management</h2>
           </CardHeader>
           <CardContent className="grid grid-cols-2 gap-4">
              <a href="/teacher/homework" className="p-6 rounded-3xl bg-surface-base border border-surface-border hover:border-primary-500/30 transition-all text-center group">
                <div className="w-12 h-12 rounded-2xl bg-muted-800 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <BookOpen size={20} className="text-muted-400 group-hover:text-primary-400" />
                </div>
                <p className="text-xs font-black uppercase tracking-widest text-muted-500 group-hover:text-white">Assignments</p>
              </a>
              <a href="/teacher/attendance" className="p-6 rounded-3xl bg-surface-base border border-surface-border hover:border-primary-500/30 transition-all text-center group">
                <div className="w-12 h-12 rounded-2xl bg-muted-800 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <UserPlus size={20} className="text-muted-400 group-hover:text-primary-400" />
                </div>
                <p className="text-xs font-black uppercase tracking-widest text-muted-500 group-hover:text-white">Attendance</p>
              </a>
           </CardContent>
        </Card>
      </div>

    </DashboardLayout>
  )
}

export default TeacherDashboard
