import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { submitComplaintApi, getMyComplaintsApi } from '../../api/complaintApi'
import { MessageSquare, Plus, X, Clock, CheckCircle2, AlertCircle, ChevronRight, User } from 'lucide-react'

const TeacherComplaints = () => {
  const [complaints, setComplaints] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  
  const [form, setForm] = useState({
    title: '',
    category: 'academic',
    priority: 'medium',
    description: '',
    isAnonymous: false
  })

  const fetchComplaints = async () => {
    setLoading(true)
    try {
      const res = await getMyComplaintsApi()
      setComplaints(res.data?.complaints ?? [])
    } catch (err) {
      console.error('Failed to fetch complaints:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchComplaints()
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      await submitComplaintApi(form)
      setShowModal(false)
      setForm({ title: '', category: 'academic', priority: 'medium', description: '', isAnonymous: false })
      fetchComplaints()
    } catch (err) {
      alert('Failed to submit complaint')
    } finally {
      setSubmitting(false)
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'open': return 'bg-red-500/10 text-red-400 border-red-500/20'
      case 'in_progress': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
      case 'resolved': return 'bg-green-500/10 text-green-400 border-green-500/20'
      case 'closed': return 'bg-muted-700 text-muted-400 border-muted-600'
      default: return 'bg-muted-800 text-muted-500'
    }
  }

  const inputClass = "w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-3 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all text-sm"

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8 mb-12 animate-fade-in">
          <div>
            <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">Support & Feedback</h1>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
               <span className="w-1.5 h-1.5 bg-primary-500 rounded-full animate-pulse" />
               Faculty Feedback Management
            </p>
          </div>
          <button
            onClick={() => setShowModal(true)}
            className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all duration-300 active:scale-95 cursor-pointer shadow-xl bg-primary-500 text-white hover:bg-primary-600 shadow-primary-900/20"
          >
            <Plus size={16} />
            Submit New Feedback
          </button>
        </div>

        {/* Complaints List */}
        <div className="space-y-6">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-48 bg-muted-800 rounded-[2rem] animate-pulse" />
              ))}
            </div>
          ) : complaints.length === 0 ? (
            <div className="py-20 text-center bg-muted-800/50 rounded-[3rem] border border-muted-700">
               <div className="w-20 h-20 bg-muted-900 rounded-3xl flex items-center justify-center mx-auto mb-6 text-muted-500">
                  <MessageSquare size={32} />
               </div>
               <h3 className="font-syne text-xl font-bold text-white mb-2">No Active Submissions</h3>
               <p className="text-muted-500 text-sm max-w-md mx-auto">Your feedback loop is currently empty. Submit a complaint or suggestion to institutionalize your voice.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              {complaints.map(c => (
                <div key={c._id} className="bg-muted-800 border border-muted-700 p-8 rounded-[2.5rem] shadow-xl hover:border-primary-500/30 transition-all duration-500 group relative overflow-hidden">
                  <div className="flex justify-between items-start mb-6">
                     <span className="px-3 py-1 bg-primary-500/10 text-primary-400 text-[10px] font-black uppercase tracking-widest rounded-lg border border-primary-500/20">{c.category}</span>
                     <span className={`px-4 py-1 rounded-lg text-[10px] font-black border ${getStatusBadge(c.status)}`}>
                        {c.status.replace('_', ' ')}
                     </span>
                  </div>
                  <h3 className="font-syne text-xl font-bold mb-2 group-hover:text-primary-400 transition-colors">{c.title}</h3>
                  <p className="text-muted-400 text-sm mb-6 leading-relaxed">{c.description}</p>
                  
                  <div className="flex items-center gap-4 text-muted-500 text-[10px] font-black uppercase tracking-widest mb-6">
                     <Clock size={14} />
                     {new Date(c.createdAt).toLocaleDateString()}
                     {c.isAnonymous && <span className="text-muted-600 ml-auto italic">Anonymous Submission</span>}
                  </div>

                  {c.adminReply && (
                    <div className="bg-primary-500/5 border border-primary-500/20 p-6 rounded-3xl animate-fade-in">
                       <p className="text-primary-400 text-[10px] font-black uppercase tracking-widest mb-2 flex items-center gap-2">
                          <CheckCircle2 size={12} />
                          Administrative Response
                       </p>
                       <p className="text-sm text-muted-300 italic">"{c.adminReply}"</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Modal */}
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={() => setShowModal(false)} />
            <div className="relative w-full max-w-2xl bg-muted-800 border border-muted-700 rounded-[3rem] shadow-2xl overflow-hidden animate-fade-up">
              <div className="p-10 border-b border-muted-700/50 flex justify-between items-center">
                <h2 className="font-syne text-2xl font-bold text-white">New Submission</h2>
                <button onClick={() => setShowModal(false)} className="p-3 bg-muted-900 rounded-2xl hover:bg-muted-700">
                  <X size={20} />
                </button>
              </div>
              <form onSubmit={handleSubmit} className="p-10 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Subject Title</label>
                  <input type="text" className={inputClass} value={form.title} onChange={e => setForm({...form, title: e.target.value})} required placeholder="Brief summary of your feedback" />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Category</label>
                  <select className={inputClass} value={form.category} onChange={e => setForm({...form, category: e.target.value})} required>
                    <option value="academic">Academic</option>
                    <option value="fee">Fee</option>
                    <option value="behavior">Behavior</option>
                    <option value="facility">Facility</option>
                    <option value="teacher">Teacher</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Priority</label>
                  <select className={inputClass} value={form.priority} onChange={e => setForm({...form, priority: e.target.value})} required>
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Detailed Description</label>
                  <textarea className={`${inputClass} h-32`} value={form.description} onChange={e => setForm({...form, description: e.target.value})} required placeholder="Please provide complete details..." />
                </div>
                <div className="md:col-span-2 flex items-center gap-3 p-4 bg-muted-900/50 border border-muted-700 rounded-2xl">
                  <input 
                    type="checkbox" 
                    id="anonymous" 
                    className="w-4 h-4 accent-primary-500" 
                    checked={form.isAnonymous} 
                    onChange={e => setForm({...form, isAnonymous: e.target.checked})} 
                  />
                  <label htmlFor="anonymous" className="text-xs font-bold text-muted-400 cursor-pointer">Protect Identity (Submit Anonymously)</label>
                </div>

                <div className="md:col-span-2 flex gap-4 mt-4">
                  <button type="button" onClick={() => setShowModal(false)} className="flex-1 bg-muted-900 py-4 rounded-2xl font-bold uppercase tracking-widest text-[10px]">Abort</button>
                  <button type="submit" disabled={submitting} className="flex-1 bg-primary-500 py-4 rounded-2xl font-bold uppercase tracking-widest text-[10px] hover:bg-primary-600 transition-all shadow-xl shadow-primary-900/20">
                    {submitting ? 'Transmitting...' : 'Initialize Transmission'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </main>
    </div>
  )
}

export default TeacherComplaints
