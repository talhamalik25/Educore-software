import { useState } from 'react';
import Sidebar from '../../components/ui/Sidebar';
import { getStudentsApi } from '../../api/studentApi';
import { getReportCardData, downloadReportCardPDF } from '../../api/reportCardApi';
import ReportCard from '../../components/ReportCard';
import { 
  Users, 
  Search, 
  Filter, 
  ChevronRight, 
  X, 
  Printer, 
  Download, 
  Loader2,
  FileText,
  AlertCircle
} from 'lucide-react';
import { cn } from '../../lib/utils';
import Button from '../../components/ui/Button';

const TeacherReportCards = () => {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({ class: '', section: '', examType: 'final' });
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [reportData, setReportData] = useState(null);
  const [fetchingReport, setFetchingReport] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [error, setError] = useState(null);

  const fetchStudents = async () => {
    if (!filters.class || !filters.section) {
      alert('Please select both class and section.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await getStudentsApi({ class: filters.class, section: filters.section });
      setStudents(res.data?.data?.students ?? []);
    } catch (err) {
      setError('Failed to load students. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleViewReport = async (student) => {
    setSelectedStudent(student);
    setFetchingReport(true);
    setShowModal(true);
    setReportData(null);
    try {
      const data = await getReportCardData(student._id, filters.examType);
      setReportData(data.data);
    } catch (err) {
      console.error(err);
    } finally {
      setFetchingReport(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!reportData) return;
    try {
      await downloadReportCardPDF(selectedStudent._id, filters.examType, selectedStudent.name);
    } catch (err) {
      console.error('Download failed:', err);
    }
  };

  const inputClass = "w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-3 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all text-sm appearance-none cursor-pointer";

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        {/* Header */}
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8 mb-12 animate-fade-in">
          <div>
            <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter flex items-center gap-4">
              <FileText className="text-primary-400" size={40} />
              Academic Credentials
            </h1>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
               <span className="w-1.5 h-1.5 bg-primary-500 rounded-full animate-pulse" />
               Faculty Grading Node
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12 p-8 bg-surface-elevated/50 backdrop-blur-xl border border-white/5 rounded-[2.5rem] no-print">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-muted-500 ml-1">Class</label>
            <select 
              className={inputClass}
              value={filters.class}
              onChange={(e) => setFilters(prev => ({ ...prev, class: e.target.value }))}
            >
              <option value="">Select Class</option>
              {[1,2,3,4,5,6,7,8,9,10].map(c => <option key={c} value={c}>Class {c}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-muted-500 ml-1">Section</label>
            <select 
              className={inputClass}
              value={filters.section}
              onChange={(e) => setFilters(prev => ({ ...prev, section: e.target.value }))}
            >
              <option value="">Select Section</option>
              {['A', 'B', 'C', 'D'].map(s => <option key={s} value={s}>Section {s}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-muted-500 ml-1">Exam Type</label>
            <select 
              className={inputClass}
              value={filters.examType}
              onChange={(e) => setFilters(prev => ({ ...prev, examType: e.target.value }))}
            >
              <option value="monthly">Monthly Test</option>
              <option value="midterm">Midterm Exam</option>
              <option value="final">Final Exam</option>
              <option value="quiz">Class Quiz</option>
            </select>
          </div>
          <div className="flex items-end">
            <Button 
              onClick={fetchStudents} 
              disabled={loading}
              className="w-full h-[52px] rounded-2xl gap-2 font-bold uppercase tracking-widest text-xs"
            >
              {loading ? <Loader2 className="animate-spin" size={18} /> : <Users size={18} />}
              Load Students
            </Button>
          </div>
        </div>

        {/* Students List */}
        {error ? (
          <div className="flex flex-col items-center justify-center py-20 bg-red-500/5 border border-red-500/10 rounded-[3rem] text-red-400">
            <AlertCircle size={48} className="mb-4 opacity-50" />
            <p className="font-syne text-xl font-bold uppercase tracking-widest">{error}</p>
          </div>
        ) : students.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 animate-fade-in">
            {students.map(student => (
              <div 
                key={student._id}
                className="group bg-surface-elevated border border-white/5 p-6 rounded-[2.5rem] hover:border-primary-500/30 transition-all duration-500"
              >
                <div className="flex items-center gap-5 mb-6">
                  <div className="w-14 h-14 bg-muted-800 rounded-2xl flex items-center justify-center text-xl font-black text-primary-400 group-hover:scale-110 transition-transform shadow-inner">
                    {student.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-syne text-lg font-bold text-white group-hover:text-primary-400 transition-colors">{student.name}</h3>
                    <p className="text-[10px] font-black uppercase tracking-widest text-muted-500">Roll: {student.rollNumber}</p>
                  </div>
                </div>
                <button 
                  onClick={() => handleViewReport(student)}
                  className="w-full py-4 rounded-2xl bg-white/5 border border-white/5 text-[10px] font-black uppercase tracking-widest hover:bg-primary-600 hover:text-white transition-all flex items-center justify-center gap-2 group/btn"
                >
                  View Report Card
                  <ChevronRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            ))}
          </div>
        ) : !loading && (
          <div className="flex flex-col items-center justify-center py-32 opacity-20">
            <Search size={64} className="mb-6" />
            <p className="font-syne text-2xl font-bold uppercase tracking-[0.3em]">No students loaded</p>
            <p className="text-sm mt-2">Select class and section to begin</p>
          </div>
        )}

        {/* Report Card Modal */}
        {showModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-10 no-print">
            <div 
              className="absolute inset-0 bg-black/90 backdrop-blur-xl animate-fade-in"
              onClick={() => setShowModal(false)}
            />
            <div className="relative w-full max-w-4xl h-full bg-surface-elevated rounded-[3rem] border border-white/10 shadow-2xl flex flex-col overflow-hidden animate-zoom-in">
              
              {/* Modal Header */}
              <div className="flex items-center justify-between p-8 border-b border-white/5">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary-600 rounded-2xl flex items-center justify-center text-white shadow-glow">
                    <FileText size={20} />
                  </div>
                  <div>
                    <h2 className="font-syne text-xl font-bold text-white">{selectedStudent?.name}</h2>
                    <p className="text-[10px] font-black uppercase tracking-widest text-muted-500">
                      {filters.examType.toUpperCase()} — CLASS {filters.class}{filters.section}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => window.print()}
                    className="p-3 bg-white/5 hover:bg-white/10 rounded-xl transition-all text-muted-400 hover:text-white"
                    title="Print"
                  >
                    <Printer size={20} />
                  </button>
                  <button 
                    onClick={handleDownloadPDF}
                    className="p-3 bg-white/5 hover:bg-white/10 rounded-xl transition-all text-muted-400 hover:text-white"
                    title="Download PDF"
                  >
                    <Download size={20} />
                  </button>
                  <button 
                    onClick={() => setShowModal(false)}
                    className="p-3 bg-white/5 hover:bg-red-500/20 rounded-xl transition-all text-muted-400 hover:text-red-400"
                  >
                    <X size={20} />
                  </button>
                </div>
              </div>

              {/* Modal Body */}
              <div className="flex-1 overflow-y-auto p-8 bg-muted-950">
                {fetchingReport ? (
                  <div className="h-full flex flex-col items-center justify-center text-muted-500">
                    <Loader2 className="animate-spin mb-4" size={48} />
                    <p className="font-syne font-bold uppercase tracking-widest">Generating Digital Credential...</p>
                  </div>
                ) : reportData ? (
                  <ReportCard 
                    student={reportData.student}
                    school={reportData.school}
                    results={reportData.results}
                    summary={reportData.summary}
                    examType={filters.examType}
                  />
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-muted-500 opacity-30">
                    <AlertCircle size={64} className="mb-4" />
                    <p className="font-syne text-2xl font-bold uppercase tracking-widest">Report Not Found</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

      </main>
    </div>
  );
};

export default TeacherReportCards;
