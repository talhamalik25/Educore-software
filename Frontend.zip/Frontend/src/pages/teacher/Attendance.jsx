import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getStudentsApi } from '../../api/studentApi'
import { markBulkAttendanceApi, getAttendanceApi } from '../../api/attendanceApi'

const TeacherAttendance = () => {
  const [students, setStudents] = useState([])
  const [attendance, setAttendance] = useState({}) // { studentId: 'present' | 'absent' | 'late' }
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [alreadyMarked, setAlreadyMarked] = useState(false)

  const today = new Date().toISOString().split('T')[0]

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [studentsRes, attendanceRes] = await Promise.all([
          getStudentsApi(),
          getAttendanceApi({ date: today }),
        ])

        const studentList = studentsRes.data?.students ?? []
        setStudents(studentList)

        const records = attendanceRes.data?.records ?? []
        if (records.length > 0) {
          setAlreadyMarked(true)
          const existing = {}
          records.forEach(r => {
            existing[r.studentId?._id || r.studentId] = r.status
          })
          setAttendance(existing)
        } else {
          const defaultAttendance = {}
          studentList.forEach(s => { defaultAttendance[s._id] = 'present' })
          setAttendance(defaultAttendance)
        }
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  const handleStatusChange = (studentId, status) => {
    setAttendance(prev => ({ ...prev, [studentId]: status }))
  }

  const markAllPresent = () => {
    if (alreadyMarked) return
    const all = {}
    students.forEach(s => { all[s._id] = 'present' })
    setAttendance(all)
  }

  const handleSubmit = async () => {
    setSubmitting(true)
    try {
      const records = students.map(s => ({
        studentId: s._id,
        status: attendance[s._id] || 'absent',
      }))
      await markBulkAttendanceApi(records, today)
      setSubmitted(true)
      setAlreadyMarked(true)
      window.scrollTo({ top: 0, behavior: 'smooth' })
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to mark attendance.')
    } finally {
      setSubmitting(false)
    }
  }

  const presentCount = Object.values(attendance).filter(s => s === 'present').length
  const absentCount = Object.values(attendance).filter(s => s === 'absent').length
  const lateCount = Object.values(attendance).filter(s => s === 'late').length

  const statusConfig = {
    present: { label: 'P', color: 'bg-green-500/10 text-green-400 border-green-500/20', activeColor: 'bg-green-500 text-white shadow-lg shadow-green-900/40' },
    late:    { label: 'L', color: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20', activeColor: 'bg-yellow-500 text-black shadow-lg shadow-yellow-900/40' },
    absent:  { label: 'A', color: 'bg-red-500/10 text-red-400 border-red-500/20', activeColor: 'bg-red-500 text-white shadow-lg shadow-red-900/40' },
  }

  const currentMonthStr = new Date().toLocaleDateString('en-PK', { weekday: 'long', day: 'numeric', month: 'long' })

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">

        {/* Header & Mark All Present */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 mb-10 animate-fade-in">
          <div>
            <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">Daily Ledger</h1>
            <p className="text-muted-500 text-[11px] font-black uppercase tracking-[0.2em] mt-3 flex items-center gap-2">
               <span className="w-1.5 h-1.5 bg-primary-500 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
               {currentMonthStr} Portal Access
            </p>
          </div>
          {!alreadyMarked && students.length > 0 && (
            <button
              onClick={markAllPresent}
              className="px-6 py-3 rounded-2xl bg-muted-800 border border-muted-700 text-muted-300 hover:text-white hover:bg-muted-700 transition-all duration-300 text-xs font-black uppercase tracking-widest active:scale-95 flex items-center gap-2 shadow-xl"
            >
              <svg className="w-4 h-4 text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
              Mark All Operational (P)
            </button>
          )}
        </div>

        {/* Status Banners */}
        {alreadyMarked && !submitted && (
          <div className="bg-blue-500/5 border border-blue-500/20 rounded-[1.5rem] px-6 py-4 text-blue-400 text-sm mb-10 flex items-center gap-4 animate-fade-in backdrop-blur-sm">
            <span className="text-xl">ℹ️</span>
            <p className="font-medium tracking-tight">Daily attendance finalized. Accessing read-only archival data for {today}.</p>
          </div>
        )}

        {submitted && (
          <div className="bg-green-500/5 border border-green-500/20 rounded-[1.5rem] px-6 py-4 text-green-400 text-sm mb-10 flex items-center gap-4 animate-fade-in backdrop-blur-sm">
            <span className="text-xl">✅</span>
            <p className="font-bold tracking-tight">Encryption Complete. Attendance records synced to central database successfully.</p>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-4 md:gap-8 mb-10">
          {[
            { label: 'Present', value: presentCount, color: 'text-green-400', bg: 'bg-green-500/5', border: 'border-green-500/20' },
            { label: 'Late', value: lateCount, color: 'text-yellow-400', bg: 'bg-yellow-500/5', border: 'border-yellow-500/20' },
            { label: 'Absent', value: absentCount, color: 'text-red-400', bg: 'bg-red-500/5', border: 'border-red-500/20' },
          ].map(stat => (
            <div key={stat.label} className={`${stat.bg} ${stat.border} border rounded-[2rem] p-4 md:p-8 text-center shadow-lg transition-transform hover:scale-[1.02] duration-300`}>
              <p className={`text-3xl md:text-5xl font-syne font-black ${stat.color} tracking-tighter mb-2`}>{stat.value}</p>
              <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Student List (Responsive Layout) */}
        {loading ? (
          <div className="space-y-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-muted-800 border border-muted-700 rounded-3xl p-8 animate-pulse h-24" />
            ))}
          </div>
        ) : students.length === 0 ? (
          <div className="bg-muted-800 border border-muted-700 rounded-[3rem] p-20 text-center">
            <div className="w-20 h-20 bg-muted-900 border border-muted-700 rounded-3xl flex items-center justify-center mx-auto mb-6 text-4xl opacity-50">👤</div>
            <p className="text-muted-400 font-bold uppercase tracking-widest">No Student Records Found</p>
          </div>
        ) : (
          <div className="space-y-4 mb-10 lg:max-w-4xl mx-auto">
            {students.map((student, index) => (
              <div
                key={student._id}
                className="bg-muted-800 border border-muted-700 hover:border-muted-600 rounded-3xl px-6 py-6 md:px-10 flex flex-col sm:flex-row items-center justify-between gap-6 transition-all duration-300 group shadow-xl"
              >
                {/* Student info */}
                <div className="flex items-center gap-5 w-full sm:w-auto">
                  <div className="w-12 h-12 rounded-2xl bg-primary-500/10 border border-primary-500/20 flex items-center justify-center text-primary-400 text-sm font-black shadow-inner group-hover:bg-primary-500 group-hover:text-white transition-all duration-300">
                    {index + 1}
                  </div>
                  <div>
                    <p className="text-white text-base font-bold tracking-tight mb-0.5">{student.name}</p>
                    <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest">
                       Grade {student.class} • Sec {student.section} • {student.rollNumber}
                    </p>
                  </div>
                </div>

                {/* Status Toggle Buttons (High-Visibility Touch Targets) */}
                <div className="flex gap-4 w-full sm:w-auto justify-center sm:justify-end border-t sm:border-t-0 border-muted-700 pt-4 sm:pt-0">
                  {['present', 'late', 'absent'].map(status => (
                    <button
                      key={status}
                      disabled={alreadyMarked}
                      onClick={() => handleStatusChange(student._id, status)}
                      className={`w-14 h-14 md:w-16 md:h-16 rounded-2xl text-[10px] font-black border transition-all duration-300 disabled:cursor-default disabled:opacity-80 active:scale-90 flex flex-col items-center justify-center gap-1 ${
                        attendance[student._id] === status
                          ? statusConfig[status].activeColor
                          : statusConfig[status].color + ' hover:bg-muted-700'
                      }`}
                    >
                      <span className="text-lg leading-none">{statusConfig[status].label}</span>
                      <span className="uppercase tracking-[0.1em] text-[8px] opacity-70">{status.charAt(0)}</span>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Global Submit Action */}
        {!alreadyMarked && students.length > 0 && (
          <div className="sticky bottom-6 lg:max-w-4xl mx-auto z-20">
            <button
              onClick={handleSubmit}
              disabled={submitting}
              className="w-full bg-primary-500 hover:bg-primary-600 active:scale-[0.98] disabled:opacity-50 text-white py-6 rounded-3xl font-black text-xs uppercase tracking-[0.3em] transition-all duration-500 shadow-[0_20px_40px_-10px_rgba(16,185,129,0.3)] cursor-pointer"
            >
              {submitting ? 'Transmitting Data...' : `Commit Daily Registry (${students.length})`}
            </button>
          </div>
        )}

      </main>
    </div>
  )
}

export default TeacherAttendance
