import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { Card, CardHeader, CardContent } from '../../components/ui/Card'
import Badge from '../../components/ui/Badge'
import { getTimetableByTeacher } from '../../api/timetableApi'
import { useAuth } from '../../context/AuthContext'
import { CalendarDays, Clock, MapPin, GraduationCap, AlertCircle, BookOpen } from 'lucide-react'

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

const TeacherTimetable = () => {
  const { user } = useAuth()
  const [schedule, setSchedule] = useState({}) // { Monday: entries ... }
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    const fetchSchedule = async () => {
      if (!user?._id) return
      try {
        const res = await getTimetableByTeacher(user._id)
        const mapped = {}
        res.data.schedule.forEach(entry => {
          if (!mapped[entry.day]) mapped[entry.day] = []
          // Each entry represents a class+section's periods for that day
          entry.periods.forEach(p => {
             mapped[entry.day].push({
               ...p,
               class: entry.class,
               section: entry.section
             })
          })
        })
        
        // Sort each day's periods by period number
        Object.keys(mapped).forEach(day => {
          mapped[day].sort((a, b) => a.periodNumber - b.periodNumber)
        })
        
        setSchedule(mapped)
      } catch (err) {
        setError('Failed to load your teaching schedule.')
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    fetchSchedule()
  }, [user?._id])

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        {/* Header */}
        <div className="mb-12 animate-fade-in">
          <h1 className="font-syne text-4xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">My Schedule</h1>
          <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
             <BookOpen size={14} className="text-primary-500" />
             Faculty Academic Node • 7-Day Cycle
          </p>
        </div>

        {error && (
          <div className="mb-6 bg-red-500/10 border border-red-500/20 rounded-2xl p-4 flex gap-3 items-center text-red-400 text-sm">
            <AlertCircle size={18} />
            {error}
          </div>
        )}

        {loading ? (
          <div className="p-20 text-center text-muted-500 font-black uppercase tracking-[0.3em] animate-pulse">Synchronizing Academic Stream...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 animate-fade-up">
            {DAYS.map((day) => {
              const dayPeriods = schedule[day] || []
              const hasClasses = dayPeriods.length > 0

              return (
                <Card key={day} className={`bg-muted-800 border-muted-700 transition-all duration-500 ${!hasClasses ? 'opacity-40 grayscale' : 'hover:border-primary-500/30'}`}>
                  <CardHeader className="bg-muted-900/50 border-b border-muted-700 p-6">
                    <div className="flex justify-between items-center">
                      <h3 className="font-syne font-bold text-white text-xl tracking-tight">{day}</h3>
                      {hasClasses && (
                        <Badge variant="teal" className="bg-primary-500/10 text-primary-400 uppercase tracking-widest text-[9px] font-black">
                          {dayPeriods.length} Sessions
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    {hasClasses ? (
                      dayPeriods.map((session, idx) => (
                        <div key={idx} className="bg-muted-900/60 border border-white/5 rounded-[1.5rem] p-5 relative overflow-hidden group">
                          {/* Accent Gradient */}
                          <div className="absolute top-0 left-0 w-1 h-full bg-primary-600 group-hover:w-2 transition-all duration-300" />
                          
                          <div className="flex justify-between items-start mb-4">
                            <div className="flex flex-col gap-1">
                               <span className="text-[10px] font-black text-primary-500 uppercase tracking-widest">Period {session.periodNumber}</span>
                               <h4 className="text-lg font-bold text-white tracking-tight">{session.subject}</h4>
                            </div>
                            <div className="bg-muted-950 rounded-xl px-3 py-1.5 flex items-center gap-2 border border-white/5">
                               <Clock size={12} className="text-muted-500" />
                               <span className="text-[11px] font-bold text-muted-300 tracking-tighter">{session.startTime} - {session.endTime}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-4">
                             <div className="flex items-center gap-2">
                                <MapPin size={12} className="text-muted-600" />
                                <span className="text-[10px] font-black text-muted-400 uppercase tracking-widest">Assigned Sector</span>
                             </div>
                             <div className="flex items-center gap-2 px-3 py-1 bg-white/5 rounded-lg border border-white/5">
                                <GraduationCap size={14} className="text-primary-500" />
                                <span className="text-xs font-bold text-white uppercase tracking-tighter">{session.class}{session.section}</span>
                             </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="h-48 flex flex-col items-center justify-center text-center">
                        <CalendarDays size={32} className="text-muted-700 mb-4 opacity-20" />
                        <p className="text-[10px] font-black uppercase tracking-[0.3em] text-muted-600">Zero Node Assignments</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}

      </main>
    </div>
  )
}

export default TeacherTimetable
