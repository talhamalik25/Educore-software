import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getResultsByClassApi, addResultApi, updateResultApi, deleteResultApi } from '../../api/resultApi'
import { getStudentsApi } from '../../api/studentApi'
import { Plus, Edit2, Trash2, X, Search, Filter } from 'lucide-react'

const TeacherResults = () => {
  const [results, setResults] = useState([])
  const [students, setStudents] = useState([])
  const [loading, setLoading] = useState(false)
  const [showModal, setShowModal] = useState(false)
  const [editingResult, setEditingResult] = useState(null)
  
  const [filters, setFilters] = useState({
    class: '',
    section: '',
    examType: ''
  })

  const [form, setForm] = useState({
    studentId: '',
    subject: '',
    examType: 'monthly',
    totalMarks: '',
    obtainedMarks: '',
    examDate: new Date().toISOString().split('T')[0],
    remarks: '',
    class: '',
    section: ''
  })

  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const fetchResults = async () => {
    if (!filters.class || !filters.section) return
    setLoading(true)
    try {
      const res = await getResultsByClassApi(filters.class, filters.section, filters.examType)
      setResults(res.data?.results ?? [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const fetchStudents = async () => {
    if (!filters.class || !filters.section) return
    try {
      const res = await getStudentsApi({ class: filters.class, section: filters.section })
      setStudents(res.data?.students ?? [])
    } catch (err) {
      console.error(err)
    }
  }

  useEffect(() => {
    if (filters.class && filters.section) {
      fetchResults()
      fetchStudents()
    }
  }, [filters])

  const handleOpenAdd = () => {
    setEditingResult(null)
    setForm({
      studentId: '',
      subject: '',
      examType: filters.examType || 'monthly',
      totalMarks: '',
      obtainedMarks: '',
      examDate: new Date().toISOString().split('T')[0],
      remarks: '',
      class: filters.class,
      section: filters.section
    })
    setShowModal(true)
  }

  const handleOpenEdit = (result) => {
    setEditingResult(result)
    setForm({
      studentId: result.studentId._id,
      subject: result.subject,
      examType: result.examType,
      totalMarks: result.totalMarks,
      obtainedMarks: result.obtainedMarks,
      examDate: new Date(result.examDate).toISOString().split('T')[0],
      remarks: result.remarks || '',
      class: result.class,
      section: result.section
    })
    setShowModal(true)
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this result?')) return
    try {
      await deleteResultApi(id)
      fetchResults()
    } catch (err) {
      console.error(err)
      alert('Failed to delete result')
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    setError('')
    try {
      if (editingResult) {
        await updateResultApi(editingResult._id, form)
      } else {
        await addResultApi(form)
      }
      setShowModal(false)
      fetchResults()
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong')
    } finally {
      setSubmitting(false)
    }
  }

  const getGradeColor = (grade) => {
    switch (grade) {
      case 'A+': return 'bg-green-500/10 text-green-400 border-green-500/20'
      case 'A': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
      case 'B': return 'bg-blue-500/10 text-blue-400 border-blue-500/20'
      case 'C': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
      case 'D': return 'bg-orange-500/10 text-orange-400 border-orange-500/20'
      case 'F': return 'bg-red-500/10 text-red-400 border-red-500/20'
      default: return 'bg-muted-700 text-muted-400 border-muted-600'
    }
  }

  const inputClass = "w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-3 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all"

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        {/* Header */}
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8 mb-12">
          <div>
            <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">Academic Records</h1>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
               <span className="w-1.5 h-1.5 bg-primary-500 rounded-full animate-pulse" />
               Performance Tracking & Grading
            </p>
          </div>
          <button
            onClick={handleOpenAdd}
            disabled={!filters.class || !filters.section}
            className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all duration-300 active:scale-95 cursor-pointer shadow-xl bg-primary-500 text-white hover:bg-primary-600 shadow-primary-900/20 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Plus size={16} />
            Record Result
          </button>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10 bg-muted-800/50 p-6 rounded-[2rem] border border-muted-700/50">
          <div>
            <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Class</label>
            <input 
              type="text" 
              placeholder="e.g. 10" 
              className={inputClass}
              value={filters.class}
              onChange={e => setFilters({...filters, class: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Section</label>
            <input 
              type="text" 
              placeholder="e.g. A" 
              className={inputClass}
              value={filters.section}
              onChange={e => setFilters({...filters, section: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Exam Type</label>
            <select 
              className={inputClass}
              value={filters.examType}
              onChange={e => setFilters({...filters, examType: e.target.value})}
            >
              <option value="">All Exams</option>
              <option value="monthly">Monthly</option>
              <option value="midterm">Midterm</option>
              <option value="final">Final</option>
              <option value="quiz">Quiz</option>
            </select>
          </div>
        </div>

        {/* Results Table */}
        <div className="bg-muted-800 border border-muted-700 rounded-[2.5rem] overflow-hidden shadow-2xl">
          {!filters.class || !filters.section ? (
            <div className="p-20 text-center">
              <div className="w-20 h-20 bg-muted-900 rounded-3xl flex items-center justify-center mx-auto mb-6 text-muted-500">
                <Filter size={32} />
              </div>
              <h3 className="font-syne text-xl font-bold text-white mb-2">Select Class & Section</h3>
              <p className="text-muted-500 text-sm">Please provide class and section to view academic performance.</p>
            </div>
          ) : loading ? (
            <div className="p-20 text-center animate-pulse">
              <p className="text-muted-500 font-black uppercase tracking-[0.2em]">Synchronizing Data Nodes...</p>
            </div>
          ) : results.length === 0 ? (
            <div className="p-20 text-center">
              <h3 className="font-syne text-xl font-bold text-white mb-2">No Records Found</h3>
              <p className="text-muted-500 text-sm">No results have been recorded for this criteria yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-muted-900/50">
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest">Student</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest">Subject</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-center">Marks</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-center">Grade</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-muted-700/50">
                  {results.map(res => (
                    <tr key={res._id} className="hover:bg-muted-700/30 transition-colors group">
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl bg-primary-500/10 flex items-center justify-center text-primary-400 font-bold">
                            {res.studentId?.name?.charAt(0)}
                          </div>
                          <div>
                            <p className="text-sm font-bold text-white">{res.studentId?.name}</p>
                            <p className="text-[10px] text-muted-500 font-medium">{res.studentId?.rollNumber}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <span className="text-sm font-medium text-muted-300">{res.subject}</span>
                        <p className="text-[9px] text-muted-500 uppercase tracking-widest font-black mt-1">{res.examType}</p>
                      </td>
                      <td className="px-8 py-6 text-center">
                        <div className="inline-flex flex-col items-center">
                          <span className="text-sm font-bold text-white">{res.obtainedMarks} / {res.totalMarks}</span>
                          <div className="w-24 h-1.5 bg-muted-900 rounded-full mt-2 overflow-hidden">
                            <div 
                              className="h-full bg-primary-500 transition-all duration-1000" 
                              style={{ width: `${(res.obtainedMarks / res.totalMarks) * 100}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6 text-center">
                        <span className={`px-4 py-1 rounded-lg text-[10px] font-black border ${getGradeColor(res.grade)}`}>
                          {res.grade}
                        </span>
                      </td>
                      <td className="px-8 py-6 text-right">
                        <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button 
                            onClick={() => handleOpenEdit(res)}
                            className="p-2.5 bg-muted-900 text-muted-400 hover:text-white hover:bg-muted-700 rounded-xl transition-all"
                          >
                            <Edit2 size={14} />
                          </button>
                          <button 
                            onClick={() => handleDelete(res._id)}
                            className="p-2.5 bg-muted-900 text-red-400/50 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-all"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Modal */}
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={() => setShowModal(false)} />
            <div className="relative w-full max-w-2xl bg-muted-800 border border-muted-700 rounded-[3rem] shadow-2xl overflow-hidden animate-fade-up">
              <div className="p-10 border-b border-muted-700/50 flex justify-between items-center">
                <h2 className="font-syne text-2xl font-bold">{editingResult ? 'Update Performance' : 'Record Achievement'}</h2>
                <button onClick={() => setShowModal(false)} className="p-3 bg-muted-900 rounded-2xl hover:bg-muted-700">
                  <X size={20} />
                </button>
              </div>
              <form onSubmit={handleSubmit} className="p-10 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Student</label>
                  <select 
                    className={inputClass}
                    value={form.studentId}
                    onChange={e => setForm({...form, studentId: e.target.value})}
                    required
                    disabled={!!editingResult}
                  >
                    <option value="">Select Student</option>
                    {students.map(s => (
                      <option key={s._id} value={s._id}>{s.name} ({s.rollNumber})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Subject</label>
                  <input type="text" className={inputClass} value={form.subject} onChange={e => setForm({...form, subject: e.target.value})} required placeholder="e.g. Mathematics" />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Exam Type</label>
                  <select className={inputClass} value={form.examType} onChange={e => setForm({...form, examType: e.target.value})} required>
                    <option value="monthly">Monthly</option>
                    <option value="midterm">Midterm</option>
                    <option value="final">Final</option>
                    <option value="quiz">Quiz</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Total Marks</label>
                  <input type="number" className={inputClass} value={form.totalMarks} onChange={e => setForm({...form, totalMarks: e.target.value})} required />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Obtained Marks</label>
                  <input type="number" className={inputClass} value={form.obtainedMarks} onChange={e => setForm({...form, obtainedMarks: e.target.value})} required />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Exam Date</label>
                  <input type="date" className={inputClass} value={form.examDate} onChange={e => setForm({...form, examDate: e.target.value})} required />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Remarks (Optional)</label>
                  <textarea className={`${inputClass} h-24`} value={form.remarks} onChange={e => setForm({...form, remarks: e.target.value})} />
                </div>

                {error && <p className="md:col-span-2 text-red-400 text-xs font-bold bg-red-500/10 p-4 rounded-2xl border border-red-500/20">{error}</p>}

                <div className="md:col-span-2 flex gap-4 mt-4">
                  <button type="button" onClick={() => setShowModal(false)} className="flex-1 bg-muted-900 py-4 rounded-2xl font-bold uppercase tracking-widest text-[10px]">Cancel</button>
                  <button type="submit" disabled={submitting} className="flex-1 bg-primary-500 py-4 rounded-2xl font-bold uppercase tracking-widest text-[10px] hover:bg-primary-600 shadow-xl shadow-primary-900/20 transition-all active:scale-95">
                    {submitting ? 'Transmitting...' : editingResult ? 'Update Node' : 'Initialize Record'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </main>
    </div>
  )
}

export default TeacherResults
