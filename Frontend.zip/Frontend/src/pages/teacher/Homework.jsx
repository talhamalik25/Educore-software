import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getHomeworkApi, createHomeworkApi, getHomeworkDetailsApi } from '../../api/homeworkApi'
import { getStudentsApi } from '../../api/studentApi'

const TeacherHomework = () => {
  const [homeworkList, setHomeworkList] = useState([])
  const [loading, setLoading] = useState(true)
  const [showCreate, setShowCreate] = useState(false)
  const [creating, setCreating] = useState(false)
  const [createError, setCreateError] = useState('')
  
  const [form, setForm] = useState({
    title: '',
    description: '',
    class: '',
    section: '',
    subject: '',
    dueDate: '',
    attachments: []
  })

  const [selectedHomework, setSelectedHomework] = useState(null)
  const [submissions, setSubmissions] = useState([])
  const [loadingDetails, setLoadingDetails] = useState(false)

  const fetchHomework = async () => {
    try {
      const res = await getHomeworkApi()
      setHomeworkList(res.data?.homework ?? [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchHomework() }, [])

  const handleFileChange = (e) => {
    setForm(prev => ({ ...prev, attachments: Array.from(e.target.files) }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setCreating(true)
    setCreateError('')

    const formData = new FormData()
    Object.keys(form).forEach(key => {
      if (key === 'attachments') {
        form.attachments.forEach(file => formData.append('attachments', file))
      } else {
        formData.append(key, form[key])
      }
    })

    try {
      await createHomeworkApi(formData)
      setShowCreate(false)
      setForm({ title: '', description: '', class: '', section: '', subject: '', dueDate: '', attachments: [] })
      fetchHomework()
    } catch (err) {
      setCreateError(err.response?.data?.message || 'Failed to create homework.')
    } finally {
      setCreating(false)
    }
  }

  const viewDetails = async (hw) => {
    setSelectedHomework(hw)
    setLoadingDetails(true)
    try {
      const res = await getHomeworkDetailsApi(hw._id)
      setSubmissions(res.data?.submissions ?? [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoadingDetails(false)
    }
  }

  const inputClass = "w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-4 text-white placeholder-muted-700 focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all duration-300"

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8 mb-12 animate-fade-in relative">
          <div>
            <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">Academic Vault</h1>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
               <span className="w-1.5 h-1.5 bg-primary-500 rounded-full animate-pulse" />
               Homework Repository Management
            </p>
          </div>
          <button
            onClick={() => setShowCreate(true)}
            className="inline-flex items-center justify-center px-8 py-3.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all duration-300 active:scale-95 cursor-pointer shadow-xl bg-primary-500 text-white hover:bg-primary-600 shadow-primary-900/20"
          >
            Deploy Assignment
          </button>
        </div>

        {showCreate && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowCreate(false)} />
            <div className="relative w-full max-w-2xl bg-muted-800 border border-muted-700 rounded-[2.5rem] shadow-2xl overflow-hidden animate-fade-up">
              <div className="p-10 border-b border-muted-700/50">
                <h2 className="font-syne text-2xl font-bold">New Assignment</h2>
              </div>
              <form onSubmit={handleSubmit} className="p-10 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2">Title</label>
                  <input type="text" className={inputClass} value={form.title} onChange={e => setForm({...form, title: e.target.value})} required />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2">Description</label>
                  <textarea className={`${inputClass} h-32`} value={form.description} onChange={e => setForm({...form, description: e.target.value})} required />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2">Class</label>
                  <input type="text" className={inputClass} value={form.class} onChange={e => setForm({...form, class: e.target.value})} required />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2">Section</label>
                  <input type="text" className={inputClass} value={form.section} onChange={e => setForm({...form, section: e.target.value})} required />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2">Subject</label>
                  <input type="text" className={inputClass} value={form.subject} onChange={e => setForm({...form, subject: e.target.value})} required />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2">Due Date</label>
                  <input type="date" className={inputClass} value={form.dueDate} onChange={e => setForm({...form, dueDate: e.target.value})} required />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2">Attachments</label>
                  <input type="file" multiple className={inputClass} onChange={handleFileChange} />
                </div>
                {createError && <p className="md:col-span-2 text-red-400 text-sm">{createError}</p>}
                <div className="md:col-span-2 flex gap-4">
                  <button type="button" onClick={() => setShowCreate(false)} className="flex-1 bg-muted-900 py-4 rounded-2xl font-bold">Cancel</button>
                  <button type="submit" disabled={creating} className="flex-1 bg-primary-500 py-4 rounded-2xl font-bold">{creating ? 'Deploying...' : 'Confirm Deployment'}</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Homework List */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {loading ? (
             [...Array(6)].map((_, i) => <div key={i} className="h-48 bg-muted-800 rounded-3xl animate-pulse" />)
          ) : homeworkList.length === 0 ? (
            <div className="md:col-span-3 text-center py-20 bg-muted-800/50 rounded-[3rem] border border-muted-700">
               <p className="text-muted-500 font-bold uppercase tracking-widest">No Active Assignments</p>
            </div>
          ) : (
            homeworkList.map(hw => (
              <div key={hw._id} className="bg-muted-800 border border-muted-700 p-8 rounded-[2.5rem] hover:border-primary-500/30 transition-all duration-500 group relative overflow-hidden">
                <div className="flex justify-between items-start mb-6">
                   <span className="px-3 py-1 bg-primary-500/10 text-primary-400 text-[10px] font-black uppercase tracking-widest rounded-lg border border-primary-500/20">{hw.subject}</span>
                   <span className="text-muted-500 text-[10px] font-black uppercase tracking-widest">G: {hw.class} • {hw.section}</span>
                </div>
                <h3 className="font-syne text-xl font-bold mb-3 group-hover:text-primary-400 transition-colors">{hw.title}</h3>
                <p className="text-muted-400 text-xs line-clamp-2 mb-6 leading-relaxed">{hw.description}</p>
                <div className="flex items-center justify-between mt-auto pt-6 border-t border-muted-700/50">
                   <div>
                      <p className="text-muted-500 text-[9px] font-black uppercase tracking-widest">Deadline</p>
                      <p className="text-white text-xs font-bold">{new Date(hw.dueDate).toLocaleDateString()}</p>
                   </div>
                   <button onClick={() => viewDetails(hw)} className="p-3 bg-muted-900 rounded-xl hover:bg-primary-500 transition-all active:scale-95">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                   </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Submissions Modal */}
        {selectedHomework && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
             <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={() => setSelectedHomework(null)} />
             <div className="relative w-full max-w-4xl bg-muted-800 border border-muted-700 rounded-[3rem] shadow-2xl overflow-hidden max-h-[85vh] flex flex-col">
                <div className="p-10 border-b border-muted-700/50 flex justify-between items-center">
                   <div>
                      <h2 className="font-syne text-2xl font-bold">{selectedHomework.title}</h2>
                      <p className="text-primary-400 text-xs font-black uppercase tracking-widest mt-1">Submission Registry</p>
                   </div>
                   <button onClick={() => setSelectedHomework(null)} className="p-3 bg-muted-900 rounded-2xl hover:bg-muted-700">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
                   </button>
                </div>
                <div className="flex-1 overflow-y-auto p-10">
                   {loadingDetails ? <p className="text-center animate-pulse">Scanning Bio-Links...</p> : submissions.length === 0 ? (
                      <p className="text-center text-muted-500 italic">No nodes have transmitted data yet.</p>
                   ) : (
                      <div className="space-y-4">
                         {submissions.map(sub => (
                            <div key={sub._id} className="bg-muted-900/50 border border-muted-700 p-6 rounded-3xl flex items-center justify-between">
                               <div>
                                  <p className="text-white font-bold">{sub.studentId?.name}</p>
                                  <p className="text-muted-500 text-[10px] font-black tracking-widest uppercase">{sub.studentId?.rollNumber} • {new Date(sub.submittedAt).toLocaleString()}</p>
                               </div>
                               <a href={sub.fileUrl} target="_blank" rel="noreferrer" className="px-6 py-2.5 bg-primary-500/10 text-primary-400 border border-primary-500/20 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-primary-500 hover:text-white transition-all">Download Artifact</a>
                            </div>
                         ))}
                      </div>
                   )}
                </div>
             </div>
          </div>
        )}

      </main>
    </div>
  )
}

export default TeacherHomework
