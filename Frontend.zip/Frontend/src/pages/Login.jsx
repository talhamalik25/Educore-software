import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import RoleSelector from '../components/auth/RoleSelector'
import LoginForm from '../components/auth/LoginForm'
import { ROLE_META } from '../constants/roleMeta'

const Login = () => {
  const { login, logout } = useAuth()
  const navigate = useNavigate()

  const [step, setStep] = useState(1)
  const [selectedRole, setSelectedRole] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleRoleSelect = (roleId) => {
    setSelectedRole(roleId)
    setError('')
  }

  const handleContinue = () => {
    setStep(2)
  }

  const handleBack = () => {
    setStep(1)
    setError('')
  }

  const handleLogin = async (email, password) => {
    setLoading(true)
    setError('')

    try {
      const user = await login(email, password)

      // ROLE MISMATCH CHECK
      if (user.role !== selectedRole) {
        // If mismatch, we must logout because AuthContext already saved the wrong session
        await logout()
        const expectedRoleTitle = ROLE_META[selectedRole]?.title || selectedRole
        setError(`This account is not registered as ${expectedRoleTitle}. Please select the correct role.`)
        return
      }

      // Successful login and role matches
      if (user.role === 'superadmin') {
        navigate('/superadmin/dashboard')
      } else if (user.role === 'admin') {
        navigate('/admin/dashboard')
      } else if (user.role === 'teacher') {
        navigate('/teacher/dashboard')
      } else if (user.role === 'parent') {
        navigate('/parent/dashboard')
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-muted-900 flex items-center justify-center px-4 py-8 md:py-12 relative overflow-hidden text-white">
      {/* Glow Effects */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary-900/20 blur-[120px] rounded-full -mr-48 -mt-48" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-primary-900/10 blur-[100px] rounded-full -ml-40 -mb-40" />

      <div className="w-full max-w-md relative z-10 animate-fade-in">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-muted-800 border border-muted-700 shadow-xl mb-4 group hover:border-primary-500/50 transition-all duration-300">
            <svg className="w-8 h-8 text-primary-400 group-hover:scale-110 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
            </svg>
          </div>
          <h1 className="font-syne text-4xl font-bold bg-gradient-to-r from-white to-muted-400 bg-clip-text text-transparent tracking-tight">
            EduCore
          </h1>
          <p className="text-muted-500 mt-2 text-sm font-medium tracking-wide">
            AI‑Powered School Operating System
          </p>
        </div>

        {/* Content Card */}
        <div className="bg-muted-800 border border-muted-700 rounded-3xl p-6 md:p-10 shadow-2xl animate-fade-up">
          {step === 1 ? (
            <RoleSelector 
              selectedRole={selectedRole} 
              onSelect={handleRoleSelect} 
              onContinue={handleContinue} 
            />
          ) : (
            <LoginForm 
              role={selectedRole} 
              onLogin={handleLogin} 
              onBack={handleBack}
              loading={loading}
              externalError={error}
            />
          )}
        </div>

        {/* Footer Message */}
        <p className="text-center text-muted-600 text-xs mt-8 font-medium tracking-wide">
          To register your school, contact{' '}
          <span className="text-primary-400">support@educore.pk</span>
        </p>
      </div>
    </div>
  )
}

export default Login
