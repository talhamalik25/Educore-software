import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const Login = () => {
  const { login } = useAuth()
  const navigate = useNavigate()

  const [form, setForm] = useState({ email: '', password: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
    setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const user = await login(form.email, form.password)

      if (user.role === 'superadmin') {
        navigate('/superadmin/dashboard')
      } else if (user.role === 'admin') {
        navigate('/admin/dashboard')
      } else if (user.role === 'teacher') {
        navigate('/teacher/dashboard')
      } else if (user.role === 'parent') {
        navigate('/parent/dashboard')
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-muted-900 flex items-center justify-center px-4 py-8 md:py-12 relative overflow-hidden text-white">
      {/* Glow Effects */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary-900/20 blur-[120px] rounded-full -mr-48 -mt-48" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-primary-900/10 blur-[100px] rounded-full -ml-40 -mb-40" />

      <div className="w-full max-w-md relative z-10 animate-fade-in">

        {/* Logo */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-muted-800 border border-muted-700 shadow-xl mb-4 group hover:border-primary-500/50 transition-all duration-300">
            <svg className="w-8 h-8 text-primary-400 group-hover:scale-110 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
            </svg>
          </div>
          <h1 className="font-syne text-4xl font-bold bg-gradient-to-r from-white to-muted-400 bg-clip-text text-transparent tracking-tight">
            EduCore
          </h1>
          <p className="text-muted-500 mt-2 text-sm font-medium tracking-wide">
            AI‑Powered School Operating System
          </p>
        </div>

        {/* glass-card Reverted to Dark */}
        <div className="bg-muted-800 border border-muted-700 rounded-3xl p-6 md:p-10 shadow-2xl animate-fade-up">
          <h2 className="font-syne text-2xl font-bold text-white mb-2">
            Sign In
          </h2>
          <p className="text-muted-400 text-sm mb-8">
            Access your dashboard and manage operations
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">

            {/* Email */}
            <div>
              <label htmlFor="login-email" className="block text-xs font-bold text-muted-400 uppercase tracking-widest mb-2 ml-1">
                Email Address
              </label>
              <input
                id="login-email"
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                placeholder="admin@educore.com"
                required
                className="w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-4 text-white placeholder-muted-600 focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all duration-300"
              />
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label htmlFor="login-password" className="block text-xs font-bold text-muted-400 uppercase tracking-widest ml-1">
                  Password
                </label>
                <a href="#" className="text-xs text-primary-400 hover:text-primary-300 font-medium">Reset Password?</a>
              </div>
              <input
                id="login-password"
                type="password"
                name="password"
                value={form.password}
                onChange={handleChange}
                placeholder="••••••••"
                required
                className="w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-4 text-white placeholder-muted-600 focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all duration-300"
              />
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-center gap-3 bg-red-500/10 border border-red-500/20 rounded-2xl px-5 py-4 text-red-400 text-sm animate-shake">
                <svg className="w-5 h-5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                <span className="font-medium">{error}</span>
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-primary-500 hover:bg-primary-600 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-2xl transition-all duration-300 shadow-lg shadow-primary-900/20 cursor-pointer"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Authenticating...
                </span>
              ) : 'Sign In'}
            </button>

          </form>
        </div>

        {/* Footer Message */}
        <p className="text-center text-muted-600 text-xs mt-8 font-medium tracking-wide">
          To register your school, contact{' '}
          <span className="text-primary-400">support@educore.pk</span>
        </p>

      </div>
    </div>
  )
}

export default Login
