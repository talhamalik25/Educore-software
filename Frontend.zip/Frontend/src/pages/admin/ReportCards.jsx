import { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import { Card, CardHeader, CardContent } from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { getStudentsApi } from '../../api/studentApi';
import { getReportCardData, downloadReportCardPDF } from '../../api/reportCardApi';
import ReportCard from '../../components/ReportCard';
import { 
  Search, 
  Filter, 
  Printer, 
  Download, 
  Share2, 
  Loader2, 
  AlertCircle,
  FileText
} from 'lucide-react';

const AdminReportCards = () => {
  const [students, setStudents] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStudentId, setSelectedStudentId] = useState('');
  const [examType, setExamType] = useState('final');
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [fetchingStudents, setFetchingStudents] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchStudents = async () => {
      setFetchingStudents(true);
      try {
        const res = await getStudentsApi();
        setStudents(res.data?.data?.students ?? []);
      } catch (err) {
        console.error('Failed to fetch students:', err);
      } finally {
        setFetchingStudents(false);
      }
    };
    fetchStudents();
  }, []);

  const handleGenerateReport = async () => {
    if (!selectedStudentId) return;
    setLoading(true);
    setError(null);
    setReportData(null);
    try {
      const data = await getReportCardData(selectedStudentId, examType);
      setReportData(data.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to generate report card');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!reportData) return;
    try {
      await downloadReportCardPDF(selectedStudentId, examType, reportData.student.name);
    } catch (err) {
      console.error('Download failed:', err);
    }
  };

  const handleWhatsAppShare = () => {
    if (!reportData) return;
    const { student, summary } = reportData;
    const message = `Report Card for ${student.name} - ${examType.toUpperCase()}: ${summary.overallPercentage}% - Grade: ${summary.overallGrade}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
  };

  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    s.rollNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <DashboardLayout>
      <div className="no-print">
        <div className="mb-10">
          <h1 className="font-syne text-4xl font-bold text-white tracking-tight mb-2">Academic Report Hub</h1>
          <p className="text-muted-500 font-medium uppercase tracking-widest text-[10px] flex items-center gap-2">
            <FileText size={14} className="text-primary-500" />
            Generate, Print and Export Official Student Credentials
          </p>
        </div>

        {/* Search & Filters */}
        <Card className="mb-10 border-primary-500/20 bg-surface-elevated/50 backdrop-blur-xl">
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-muted-500 ml-1">Select Student</label>
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-500" size={18} />
                  <select
                    className="w-full bg-surface-base border border-surface-border rounded-2xl pl-12 pr-4 py-3.5 text-sm text-white focus:outline-none focus:border-primary-500 transition-all appearance-none cursor-pointer"
                    value={selectedStudentId}
                    onChange={(e) => setSelectedStudentId(e.target.value)}
                  >
                    <option value="">Choose a student...</option>
                    {students.map(s => (
                      <option key={s._id} value={s._id}>
                        {s.name} ({s.rollNumber}) — Class {s.class}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-muted-500 ml-1">Assessment Node</label>
                <div className="relative">
                  <Filter className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-500" size={18} />
                  <select
                    className="w-full bg-surface-base border border-surface-border rounded-2xl pl-12 pr-4 py-3.5 text-sm text-white focus:outline-none focus:border-primary-500 transition-all appearance-none cursor-pointer"
                    value={examType}
                    onChange={(e) => setExamType(e.target.value)}
                  >
                    <option value="monthly">Monthly Test</option>
                    <option value="midterm">Midterm Examination</option>
                    <option value="final">Final Examination</option>
                    <option value="quiz">Class Quiz</option>
                  </select>
                </div>
              </div>

              <Button 
                onClick={handleGenerateReport} 
                disabled={!selectedStudentId || loading}
                className="h-[52px] rounded-2xl gap-2 font-bold uppercase tracking-widest text-xs"
              >
                {loading ? <Loader2 className="animate-spin" size={18} /> : <FileText size={18} />}
                Generate Report
              </Button>
            </div>
          </CardContent>
        </Card>

        {error && (
          <div className="mb-10 p-6 bg-red-500/10 border border-red-500/20 rounded-[2rem] flex items-center gap-4 text-red-400">
            <AlertCircle size={24} />
            <p className="font-bold">{error}</p>
          </div>
        )}
      </div>

      {/* Report Display Section */}
      {reportData ? (
        <div className="animate-fade-in">
          <div className="no-print flex flex-wrap justify-center gap-4 mb-10">
            <Button variant="secondary" onClick={() => window.print()} className="gap-2 rounded-2xl bg-white/5 border-white/10 hover:bg-white/10">
              <Printer size={18} />
              Print Report
            </Button>
            <Button variant="secondary" onClick={handleDownloadPDF} className="gap-2 rounded-2xl bg-white/5 border-white/10 hover:bg-white/10">
              <Download size={18} />
              Download PDF
            </Button>
            <Button variant="secondary" onClick={handleWhatsAppShare} className="gap-2 rounded-2xl bg-[#25D366]/10 text-[#25D366] border-[#25D366]/20 hover:bg-[#25D366]/20">
              <Share2 size={18} />
              WhatsApp Parent
            </Button>
          </div>

          <ReportCard 
            student={reportData.student}
            school={reportData.school}
            results={reportData.results}
            summary={reportData.summary}
            examType={examType}
          />
        </div>
      ) : !loading && !error && (
        <div className="no-print flex flex-col items-center justify-center py-20 text-muted-600">
          <div className="w-24 h-24 rounded-full bg-surface-elevated flex items-center justify-center mb-6">
            <FileText size={40} className="opacity-20" />
          </div>
          <p className="font-syne text-xl font-bold uppercase tracking-widest opacity-30">No Report Selected</p>
          <p className="text-sm mt-2">Select a student and exam type above to generate a report card.</p>
        </div>
      )}
    </DashboardLayout>
  );
};

export default AdminReportCards;
