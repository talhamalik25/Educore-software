import { useEffect, useMemo, useState } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getNotificationsApi } from '../../api/notificationApi'

const AdminNotifications = () => {
  const [notifications, setNotifications] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const typeBadgeClass = useMemo(
    () => ({
      attendance_absent: 'bg-red-500/10 text-red-400 border-red-500/20',
      attendance_late: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
      fee_reminder: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
      fee_received: 'bg-green-500/10 text-green-400 border-green-500/20',
      homework_assigned: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    }),
    [],
  )

  const statusBadgeClass = useMemo(
    () => ({
      sent: 'bg-green-500/10 text-green-400 border-green-500/20',
      failed: 'bg-red-500/10 text-red-400 border-red-500/20',
      pending: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
      skipped_limit: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
    }),
    [],
  )

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const res = await getNotificationsApi()
        setNotifications(res?.data?.notifications ?? res?.notifications ?? [])
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to load notifications.')
      } finally {
        setLoading(false)
      }
    }
    fetchNotifications()
  }, [])

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        <div className="mb-12 animate-fade-in relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary-500/5 blur-[80px] rounded-full pointer-events-none" />
          <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">
            Notifications
          </h1>
          <p className="text-muted-500 text-[11px] font-black uppercase tracking-[0.2em] mt-3 flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-primary-500 rounded-full shadow-[0_0_10px_rgba(16,185,129,0.5)] animate-pulse" />
            {notifications.length} Notifications Logged
          </p>
        </div>

        <div className="bg-muted-800 border border-muted-700 rounded-[2.5rem] shadow-2xl overflow-hidden animate-fade-up">
          {loading ? (
            <div className="p-20 text-center text-muted-500 font-black uppercase tracking-[0.3em] animate-pulse">Fetching Notification Stream...</div>
          ) : error ? (
            <div className="p-16 md:p-20 text-center bg-muted-900/20">
              <div className="w-20 h-20 bg-red-500/10 rounded-3xl flex items-center justify-center mx-auto mb-6 text-4xl border border-red-500/20 shadow-inner">⚠️</div>
              <p className="font-syne text-xl font-bold text-white mb-2">Unable to Load</p>
              <p className="text-red-400 text-sm">{error}</p>
              <p className="text-muted-500 text-[11px] font-bold uppercase tracking-widest mt-6 max-w-[520px] mx-auto leading-relaxed">
                If your plan is Starter, SMS alerts are gated. Upgrade to Growth/Pro to enable notifications.
              </p>
            </div>
          ) : notifications.length === 0 ? (
            <div className="p-16 md:p-20 text-center bg-muted-900/20">
              <div className="w-24 h-24 bg-muted-700/40 rounded-[2rem] flex items-center justify-center mx-auto mb-8 text-5xl opacity-80 backdrop-blur-sm border border-muted-700 shadow-inner">
                🔔
              </div>
              <p className="font-syne text-2xl font-bold text-white mb-3">No Notifications Yet</p>
              <p className="text-muted-500 text-[11px] font-bold uppercase tracking-widest max-w-[520px] mx-auto leading-relaxed">
                Mark attendance (absent/late) or record fee payments to generate SMS notification logs.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[900px]">
                <thead>
                  <tr className="bg-muted-900/50 border-b border-muted-700">
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-10 py-6">Date</th>
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-10 py-6">Student</th>
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-10 py-6">Parent Phone</th>
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-10 py-6">Type</th>
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-10 py-6">Message</th>
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-10 py-6">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-muted-700/50">
                  {notifications.map((n) => (
                    <tr key={n._id} className="hover:bg-muted-700/30 transition-all duration-300">
                      <td className="px-10 py-7 text-muted-400 text-xs font-black tracking-widest uppercase">
                        {n.createdAt ? new Date(n.createdAt).toLocaleString('en-PK') : '—'}
                      </td>
                      <td className="px-10 py-7">
                        <p className="text-white text-sm font-bold tracking-tight mb-1">{n.studentId?.name || '—'}</p>
                        {n.studentId?.rollNumber && (
                          <div className="flex items-center gap-2">
                            <span className="text-[9px] font-black text-muted-500 uppercase tracking-widest bg-muted-900/50 px-2 py-0.5 rounded-lg border border-muted-700/50">
                              ID: {n.studentId.rollNumber}
                            </span>
                            <span className="text-[9px] font-black text-muted-500 uppercase tracking-widest bg-muted-900/50 px-2 py-0.5 rounded-lg border border-muted-700/50">
                              C: {n.studentId.class}
                            </span>
                          </div>
                        )}
                      </td>
                      <td className="px-10 py-7 text-muted-400 text-xs font-black tracking-widest uppercase">{n.parentPhone || '—'}</td>
                      <td className="px-10 py-7">
                        <span className={`inline-flex items-center px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-[0.2em] border ${typeBadgeClass[n.type] || 'bg-muted-900/50 text-muted-500 border-muted-700/50'}`}>
                          {n.type}
                        </span>
                      </td>
                      <td className="px-10 py-7 text-white/90 text-sm font-medium max-w-[520px]">
                        {n.message}
                      </td>
                      <td className="px-10 py-7">
                        <span className={`inline-flex items-center px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-[0.2em] border ${statusBadgeClass[n.status] || 'bg-muted-900/50 text-muted-500 border-muted-700/50'}`}>
                          {n.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

export default AdminNotifications

