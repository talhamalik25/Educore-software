import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { Card, CardHeader, CardContent } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Badge from '../../components/ui/Badge'
import { getUsersApi } from '../../api/userApi'
import { getTimetableByClass, createOrUpdateTimetable, deleteTimetableDay } from '../../api/timetableApi'
import { CalendarDays, Clock, User, Plus, Trash2, Edit, ChevronRight, AlertCircle, CheckCircle2 } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
const CLASSES = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']
const SECTIONS = ['A', 'B', 'C', 'D']

const AdminTimetable = () => {
  const [selectedClass, setSelectedClass] = useState('10')
  const [selectedSection, setSelectedSection] = useState('A')
  const [timetable, setTimetable] = useState({}) // { Monday: entries, Tuesday: entries ... }
  const [teachers, setTeachers] = useState([])
  const [loading, setLoading] = useState(false)
  const [editingDay, setEditingDay] = useState(null)
  const [modalData, setModalData] = useState([])
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  // Fetch data
  const fetchData = async () => {
    setLoading(true)
    setError('')
    try {
      const [timetableRes, usersRes] = await Promise.all([
        getTimetableByClass(selectedClass, selectedSection),
        getUsersApi()
      ])

      // Sort timetable by day
      const mapped = {}
      timetableRes.data.timetable.forEach(entry => {
        mapped[entry.day] = entry
      })
      setTimetable(mapped)

      // Filter teachers
      setTeachers(usersRes.data?.users?.filter(u => u.role === 'teacher') || [])
    } catch (err) {
      setError('Failed to load timetable data.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [selectedClass, selectedSection])

  // Open modal for a specific day
  const handleEditDay = (day) => {
    setEditingDay(day)
    const existing = timetable[day]
    
    // Initialize with 8 periods
    const periods = []
    for (let i = 1; i <= 8; i++) {
      const found = existing?.periods?.find(p => p.periodNumber === i)
      if (found) {
        periods.push({ ...found })
      } else {
        // Default 45-min slots starting at 8:00 AM
        const startHour = 8 + Math.floor((i - 1) * 1)
        const startTime = `${String(startHour).padStart(2, '0')}:00`
        const endTime = `${String(startHour).padStart(2, '0')}:45`
        periods.push({
          periodNumber: i,
          subject: '',
          teacherId: '',
          startTime,
          endTime
        })
      }
    }
    setModalData(periods)
  }

  const handlePeriodChange = (index, field, value) => {
    const updated = [...modalData]
    updated[index][field] = value
    setModalData(updated)
  }

  const handleSaveDay = async () => {
    setLoading(true)
    setError('')
    setSuccess('')
    try {
      // Filter out empty periods
      const cleanedPeriods = modalData.filter(p => p.subject && p.teacherId)
      
      await createOrUpdateTimetable({
        class: selectedClass,
        section: selectedSection,
        day: editingDay,
        periods: cleanedPeriods
      })
      
      setSuccess(`${editingDay} timetable updated successfully.`)
      setEditingDay(null)
      fetchData()
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save timetable.')
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteDay = async (day) => {
    if (!window.confirm(`Clear all periods for ${day}?`)) return
    const id = timetable[day]?._id
    if (!id) return

    setLoading(true)
    try {
      await deleteTimetableDay(id)
      fetchData()
    } catch (err) {
      setError('Failed to clear day.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 animate-fade-in text-white">
          <div>
            <h1 className="font-syne text-4xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">Timetable Master</h1>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
               <CalendarDays size={14} className="text-primary-500" />
               Academic Scheduling System
            </p>
          </div>

          <div className="flex gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-muted-500 uppercase tracking-widest ml-1">Class</label>
              <select 
                value={selectedClass} 
                onChange={(e) => setSelectedClass(e.target.value)}
                className="bg-muted-800 border border-muted-700 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-primary-500 outline-none"
              >
                {CLASSES.map(c => <option key={c} value={c}>Class {c}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-muted-500 uppercase tracking-widest ml-1">Section</label>
              <select 
                value={selectedSection} 
                onChange={(e) => setSelectedSection(e.target.value)}
                className="bg-muted-800 border border-muted-700 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-primary-500 outline-none"
              >
                {SECTIONS.map(s => <option key={s} value={s}>Section {s}</option>)}
              </select>
            </div>
          </div>
        </div>

        {error && (
          <div className="mb-6 bg-red-500/10 border border-red-500/20 rounded-2xl p-4 flex gap-3 items-center text-red-400 text-sm animate-shake">
            <AlertCircle size={18} />
            {error}
          </div>
        )}

        {success && (
          <div className="mb-6 bg-green-500/10 border border-green-500/20 rounded-2xl p-4 flex gap-3 items-center text-green-400 text-sm animate-fade-in">
            <CheckCircle2 size={18} />
            {success}
          </div>
        )}

        {/* Weekly Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-3 2xl:grid-cols-6 gap-6 animate-fade-up">
          {DAYS.map((day) => {
            const dayEntry = timetable[day]
            const sortedPeriods = [...(dayEntry?.periods || [])].sort((a, b) => a.periodNumber - b.periodNumber)

            return (
              <Card key={day} className="flex flex-col h-full bg-muted-800 border-muted-700 overflow-hidden group">
                <CardHeader className="bg-muted-900/50 border-b border-muted-700 p-4 flex flex-row items-center justify-between">
                  <div>
                    <h3 className="font-syne font-bold text-white text-lg tracking-tight">{day}</h3>
                    <p className="text-[10px] text-muted-500 font-black uppercase tracking-widest">{sortedPeriods.length} Periods Scheduled</p>
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={() => handleEditDay(day)}
                      className="p-2 rounded-lg bg-primary-500/10 text-primary-400 hover:bg-primary-500 hover:text-white transition-all"
                    >
                      <Edit size={14} />
                    </button>
                    {dayEntry && (
                      <button 
                        onClick={() => handleDeleteDay(day)}
                        className="p-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white transition-all"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="p-4 flex-1 space-y-3">
                  {sortedPeriods.length > 0 ? (
                    sortedPeriods.map((p) => (
                      <div key={p.periodNumber} className="bg-muted-900/40 border border-white/5 rounded-xl p-3 relative overflow-hidden group/period">
                        <div className="flex justify-between items-start mb-2">
                           <span className="text-[10px] font-black text-primary-500 bg-primary-500/10 px-2 py-0.5 rounded-md uppercase tracking-tighter">P{p.periodNumber}</span>
                           <span className="text-[10px] font-medium text-muted-500">{p.startTime} - {p.endTime}</span>
                        </div>
                        <h4 className="text-sm font-bold text-white mb-1 tracking-tight">{p.subject}</h4>
                        <div className="flex items-center gap-2 text-muted-400">
                           <User size={10} className="text-primary-500" />
                           <span className="text-[10px] font-black uppercase tracking-widest truncate">{p.teacherId?.name || 'Unknown'}</span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="h-40 flex flex-col items-center justify-center text-center opacity-40 grayscale">
                      <Clock size={32} className="text-muted-600 mb-2" />
                      <p className="text-[10px] font-black uppercase tracking-widest text-muted-500">No Node Sync</p>
                    </div>
                  )}
                  
                  {sortedPeriods.length === 0 && (
                    <Button 
                      variant="ghost" 
                      className="w-full border-dashed border-muted-700 py-6 text-muted-500 hover:text-white hover:bg-muted-700/50"
                      onClick={() => handleEditDay(day)}
                    >
                      <Plus size={16} className="mr-2" />
                      Initialize Day
                    </Button>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Edit Modal (Portal) */}
        <AnimatePresence>
          {editingDay && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/80 backdrop-blur-md"
                onClick={() => setEditingDay(null)}
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="bg-muted-800 border border-muted-700 rounded-[2.5rem] w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col relative z-10 shadow-2xl"
              >
                <div className="p-8 border-b border-muted-700 flex items-center justify-between">
                  <div>
                    <h2 className="font-syne text-2xl font-bold text-white tracking-tight">Syncing Node: {editingDay}</h2>
                    <p className="text-muted-500 text-xs font-black uppercase tracking-widest mt-1">Class {selectedClass} • Section {selectedSection}</p>
                  </div>
                  <button onClick={() => setEditingDay(null)} className="p-3 bg-muted-900 rounded-2xl hover:bg-muted-700 transition-colors">
                    <Edit size={18} className="rotate-45" />
                  </button>
                </div>

                <div className="p-8 overflow-y-auto flex-1">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {modalData.map((p, idx) => (
                      <div key={idx} className="bg-muted-900/50 border border-muted-700 rounded-3xl p-6 space-y-4">
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant="info">Period {p.periodNumber}</Badge>
                          <div className="flex gap-2">
                             <input 
                              type="time" 
                              value={p.startTime} 
                              onChange={(e) => handlePeriodChange(idx, 'startTime', e.target.value)}
                              className="bg-muted-800 border border-muted-700 text-[10px] rounded-lg px-2 py-1 outline-none focus:border-primary-500"
                             />
                             <span className="text-muted-600 self-center">-</span>
                             <input 
                              type="time" 
                              value={p.endTime} 
                              onChange={(e) => handlePeriodChange(idx, 'endTime', e.target.value)}
                              className="bg-muted-800 border border-muted-700 text-[10px] rounded-lg px-2 py-1 outline-none focus:border-primary-500"
                             />
                          </div>
                        </div>

                        <div className="space-y-4">
                          <div className="flex flex-col gap-1">
                            <label className="text-[10px] font-black text-muted-500 uppercase tracking-widest ml-1">Subject Node</label>
                            <input 
                              type="text"
                              value={p.subject}
                              onChange={(e) => handlePeriodChange(idx, 'subject', e.target.value)}
                              placeholder="e.g. Mathematics"
                              className="bg-muted-800 border border-muted-700 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary-500 transition-all font-bold"
                            />
                          </div>
                          
                          <div className="flex flex-col gap-1">
                            <label className="text-[10px] font-black text-muted-500 uppercase tracking-widest ml-1">Assigned Scholar</label>
                            <select 
                              value={p.teacherId?._id || p.teacherId}
                              onChange={(e) => handlePeriodChange(idx, 'teacherId', e.target.value)}
                              className="bg-muted-800 border border-muted-700 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary-500 transition-all appearance-none"
                            >
                              <option value="">Unassigned</option>
                              {teachers.map(t => <option key={t._id} value={t._id}>{t.name}</option>)}
                            </select>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-8 border-t border-muted-700 flex justify-end gap-4 bg-muted-900/30">
                  <button 
                    onClick={() => setEditingDay(null)}
                    className="px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-muted-700 transition-all"
                  >
                    Abort
                  </button>
                  <Button 
                    onClick={handleSaveDay}
                    isLoading={loading}
                    className="px-10 rounded-xl shadow-glow"
                  >
                    COMMIT SYNC
                  </Button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </main>
    </div>
  )
}

export default AdminTimetable
