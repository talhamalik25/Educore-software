import React, { useState, useEffect } from 'react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import { Card, CardHeader, CardContent } from '../../components/ui/Card'
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '../../components/ui/Table'
import Button from '../../components/ui/Button'
import Badge from '../../components/ui/Badge'
import { 
  Plus, 
  Receipt, 
  Search, 
  Filter, 
  Trash2, 
  CheckCircle2, 
  X, 
  Loader2, 
  Wallet,
  Calendar,
  AlertCircle,
  FileText
} from 'lucide-react'
import { 
  getInvoices, 
  generateInvoice, 
  markInvoicePaid, 
  deleteInvoice 
} from '../../api/invoiceApi'
import { getStudentsApi } from '../../api/studentApi'
import { getFeesApi } from '../../api/feeApi'
import { cn } from '../../lib/utils'

const AdminInvoices = () => {
    const [invoices, setInvoices] = useState([])
    const [loading, setLoading] = useState(true)
    const [stats, setStats] = useState({ total: 0, paid: 0, unpaid: 0, partial: 0 })
    
    // Modals
    const [showGenModal, setShowGenModal] = useState(false)
    const [showPayModal, setShowPayModal] = useState(false)
    const [selectedInvoice, setSelectedInvoice] = useState(null)

    // Generation State
    const [genStep, setGenStep] = useState(1)
    const [students, setStudents] = useState([])
    const [selectedStudent, setSelectedStudent] = useState(null)
    const [unpaidFees, setUnpaidFees] = useState([])
    const [selectedFeeIds, setSelectedFeeIds] = useState([])
    const [genForm, setGenForm] = useState({
        issuedTo: '',
        dueDate: '',
        discount: 0,
        discountReason: '',
        lateFine: 0,
        notes: ''
    })

    // Payment State
    const [payForm, setPayForm] = useState({
        amountPaid: 0,
        paymentMethod: 'cash',
        paidAt: new Date().toISOString().slice(0, 10)
    })

    const fetchInvoices = async () => {
        setLoading(true)
        try {
            const res = await getInvoices()
            const data = res?.data?.data?.invoices ?? res?.data?.invoices ?? []
            setInvoices(data)
            
            // Calc stats
            const s = { total: data.length, paid: 0, unpaid: 0, partial: 0 }
            data.forEach(inv => {
                if (inv.paymentStatus === 'paid') s.paid++
                else if (inv.paymentStatus === 'unpaid') s.unpaid++
                else if (inv.paymentStatus === 'partial') s.partial++
            })
            setStats(s)
        } catch (err) {
            console.error(err)
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchInvoices()
        loadStudents()
    }, [])

    const loadStudents = async () => {
        try {
            const res = await getStudentsApi()
            setStudents(res.data?.students || [])
        } catch (err) {
            console.error(err)
        }
    }

    const handleStudentSelect = async (student) => {
        setSelectedStudent(student)
        setGenForm({ ...genForm, issuedTo: student.name })
        try {
            const res = await getFeesApi({ studentId: student._id, status: 'unpaid' })
            setUnpaidFees(res.data?.fees || [])
            setGenStep(2)
        } catch (err) {
            console.error(err)
        }
    }

    const handleGenSubmit = async () => {
        try {
            const subtotal = unpaidFees
                .filter(f => selectedFeeIds.includes(f._id))
                .reduce((sum, f) => sum + (f.amount || 0), 0)

            const data = {
                ...genForm,
                studentId: selectedStudent._id,
                feeIds: selectedFeeIds,
                subtotal
            }
            await generateInvoice(data)
            setShowGenModal(false)
            setGenStep(1)
            setSelectedFeeIds([])
            fetchInvoices()
        } catch (err) {
            alert(err.response?.data?.message || 'Generation failed')
        }
    }

    const handlePaySubmit = async () => {
        try {
            await markInvoicePaid(selectedInvoice._id, payForm)
            setShowPayModal(false)
            fetchInvoices()
        } catch (err) {
            alert(err.response?.data?.message || 'Payment update failed')
        }
    }

    const handleDeleteInv = async (id) => {
        if (!confirm('Delete this unpaid invoice?')) return
        try {
            await deleteInvoice(id)
            fetchInvoices()
        } catch (err) {
            alert(err.response?.data?.message || 'Deletion failed')
        }
    }

    return (
        <DashboardLayout title="Invoices & Receipts">
            <div className="space-y-8">
                {/* Header */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h1 className="text-3xl font-syne font-bold text-white tracking-tight">System Billing</h1>
                        <p className="text-muted-500 font-medium tracking-widest text-[10px] uppercase mt-1">Invoice Generation & Management Audit</p>
                    </div>
                    <Button onClick={() => setShowGenModal(true)} className="gap-2 shadow-glow">
                        <Plus size={18} />
                        Generate Invoice
                    </Button>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <StatCard label="Total Generated" value={stats.total} icon={FileText} color="bg-blue-600" />
                    <StatCard label="Fully Paid" value={stats.paid} icon={CheckCircle2} color="bg-emerald-600" />
                    <StatCard label="Pending Payment" value={stats.unpaid} icon={AlertCircle} color="bg-rose-600" />
                    <StatCard label="Partially Settled" value={stats.partial} icon={Wallet} color="bg-amber-600" />
                </div>

                {/* Table */}
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between">
                        <h2 className="font-syne text-xl font-bold text-white">Invoice History</h2>
                        <div className="flex items-center gap-2">
                             <div className="relative group">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-500 group-focus-within:text-primary-400" size={14} />
                                <input placeholder="Filter by invoice..." className="bg-surface-base border border-surface-border rounded-xl py-1.5 pl-9 pr-3 text-xs text-white focus:outline-none focus:ring-2 focus:ring-primary-500/10" />
                             </div>
                        </div>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Invoice No</TableHead>
                                    <TableHead>Student</TableHead>
                                    <TableHead>Issued To</TableHead>
                                    <TableHead>Amount (PKR)</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Date</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {invoices.map((inv) => (
                                    <TableRow key={inv._id}>
                                        <TableCell className="font-mono text-primary-400 font-black text-xs">{inv.invoiceNumber}</TableCell>
                                        <TableCell>
                                            <div className="flex flex-col">
                                                <span className="font-bold text-white">{inv.studentId?.name}</span>
                                                <span className="text-[10px] text-muted-500 uppercase tracking-widest">{inv.studentId?.rollNumber}</span>
                                            </div>
                                        </TableCell>
                                        <TableCell className="text-sm text-muted-300">{inv.issuedTo}</TableCell>
                                        <TableCell className="font-black text-white">PKR {inv.totalAmount?.toLocaleString()}</TableCell>
                                        <TableCell>
                                            <Badge variant={inv.paymentStatus === 'paid' ? 'success' : inv.paymentStatus === 'unpaid' ? 'danger' : 'warning'}>
                                                {inv.paymentStatus}
                                            </Badge>
                                        </TableCell>
                                        <TableCell className="text-xs text-muted-500">{new Date(inv.issuedDate).toLocaleDateString()}</TableCell>
                                        <TableCell className="text-right">
                                            <div className="flex items-center justify-end gap-2">
                                                {inv.paymentStatus !== 'paid' && (
                                                    <Button variant="ghost" size="sm" className="h-8 text-primary-400" onClick={() => { setSelectedInvoice(inv); setPayForm({ ...payForm, amountPaid: inv.totalAmount }); setShowPayModal(true); }}>
                                                        Mark Paid
                                                    </Button>
                                                )}
                                                {inv.paymentStatus === 'unpaid' && (
                                                    <Button variant="ghost" size="sm" className="h-8 text-rose-500 hover:bg-rose-500/10" onClick={() => handleDeleteInv(inv._id)}>
                                                        <Trash2 size={16} />
                                                    </Button>
                                                )}
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                ))}
                                {loading && (
                                    <TableRow>
                                        <TableCell colSpan={7} className="py-20 text-center">
                                            <Loader2 size={32} className="mx-auto text-primary-500 animate-spin" />
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>

            {/* Generate Modal */}
            {showGenModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
                    <Card className="w-full max-w-xl animate-in zoom-in-95 duration-200">
                        <CardHeader className="flex flex-row items-center justify-between border-b border-surface-border">
                            <div>
                                <h3 className="text-xl font-bold text-white font-syne">Generate New Invoice</h3>
                                <p className="text-xs text-muted-500">Step {genStep} of 3</p>
                            </div>
                            <button onClick={() => setShowGenModal(false)} className="text-muted-500 hover:text-white"><X size={20} /></button>
                        </CardHeader>
                        <CardContent className="p-8">
                            {genStep === 1 && (
                                <div className="space-y-6">
                                    <label className="text-[10px] uppercase font-black tracking-widest text-muted-500">Select Student Node</label>
                                    <div className="max-h-[300px] overflow-y-auto space-y-2 pr-2">
                                        {students.map(s => (
                                            <button key={s._id} onClick={() => handleStudentSelect(s)} className="w-full flex items-center justify-between p-4 rounded-2xl bg-surface-base border border-surface-border hover:border-primary-500 group transition-all text-left">
                                                <div>
                                                    <p className="font-bold text-white">{s.name}</p>
                                                    <p className="text-[10px] text-muted-500 font-mono">{s.rollNumber}</p>
                                                </div>
                                                <Badge variant="default" className="group-hover:bg-primary-600 transition-colors">Grade {s.class}</Badge>
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {genStep === 2 && (
                                <div className="space-y-6">
                                    <div className="flex items-center justify-between">
                                        <label className="text-[10px] uppercase font-black tracking-widest text-muted-500">Select Unpaid Fees</label>
                                        <button 
                                            onClick={() => setSelectedFeeIds(selectedFeeIds.length === unpaidFees.length ? [] : unpaidFees.map(f => f._id))}
                                            className="text-[10px] text-primary-500 font-black uppercase hover:underline"
                                        >
                                            {selectedFeeIds.length === unpaidFees.length ? 'Deselect All' : 'Select All'}
                                        </button>
                                    </div>
                                    <div className="space-y-2">
                                        {unpaidFees.map(f => (
                                            <label key={f._id} className="flex items-center gap-4 p-4 rounded-xl bg-surface-base border border-surface-border cursor-pointer hover:border-primary-500/50">
                                                <input 
                                                    type="checkbox" 
                                                    checked={selectedFeeIds.includes(f._id)}
                                                    onChange={() => setSelectedFeeIds(prev => prev.includes(f._id) ? prev.filter(id => id !== f._id) : [...prev, f._id])}
                                                    className="w-4 h-4 rounded border-surface-border bg-surface-elevated text-primary-600 focus:ring-primary-500"
                                                />
                                                <div className="flex-1">
                                                    <p className="text-sm font-bold text-white">Fee for {f.month}</p>
                                                    <p className="text-[10px] text-muted-500">Due: {new Date(f.dueDate).toLocaleDateString()}</p>
                                                </div>
                                                <p className="font-black text-white">PKR {f.amount}</p>
                                            </label>
                                        ))}
                                        {unpaidFees.length === 0 && <p className="text-center py-10 text-muted-500">No unpaid fees found for this student</p>}
                                    </div>
                                    <div className="flex gap-4 pt-4">
                                        <Button variant="ghost" onClick={() => setGenStep(1)} className="flex-1">Back</Button>
                                        <Button disabled={selectedFeeIds.length === 0} onClick={() => setGenStep(3)} className="flex-1">Configure Details</Button>
                                    </div>
                                </div>
                            )}

                            {genStep === 3 && (
                                <div className="space-y-6">
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-1">
                                            <label className="text-[10px] uppercase font-black text-muted-500 tracking-wider">Issued To</label>
                                            <input value={genForm.issuedTo} onChange={e => setGenForm({...genForm, issuedTo: e.target.value})} className="w-full bg-surface-base border border-surface-border rounded-xl p-3 text-sm text-white" />
                                        </div>
                                        <div className="space-y-1">
                                            <label className="text-[10px] uppercase font-black text-muted-500 tracking-wider">Due Date</label>
                                            <input type="date" value={genForm.dueDate} onChange={e => setGenForm({...genForm, dueDate: e.target.value})} className="w-full bg-surface-base border border-surface-border rounded-xl p-3 text-sm text-white" />
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-1">
                                            <label className="text-[10px] uppercase font-black text-muted-500 tracking-wider">Discount (PKR)</label>
                                            <input type="number" value={genForm.discount} onChange={e => setGenForm({...genForm, discount: Number(e.target.value)})} className="w-full bg-surface-base border border-surface-border rounded-xl p-3 text-sm text-white" />
                                        </div>
                                        <div className="space-y-1">
                                            <label className="text-[10px] uppercase font-black text-muted-500 tracking-wider">Late Fine (PKR)</label>
                                            <input type="number" value={genForm.lateFine} onChange={e => setGenForm({...genForm, lateFine: Number(e.target.value)})} className="w-full bg-surface-base border border-surface-border rounded-xl p-3 text-sm text-white" />
                                        </div>
                                    </div>
                                    <div className="space-y-1">
                                        <label className="text-[10px] uppercase font-black text-muted-500 tracking-wider">Internal Notes</label>
                                        <textarea rows={2} value={genForm.notes} onChange={e => setGenForm({...genForm, notes: e.target.value})} className="w-full bg-surface-base border border-surface-border rounded-xl p-3 text-sm text-white resize-none" />
                                    </div>
                                    <div className="p-4 bg-primary-600/10 border border-primary-500/20 rounded-2xl">
                                        <div className="flex items-center justify-between mb-1">
                                            <span className="text-xs text-muted-400 uppercase tracking-widest font-bold">Calculated Total</span>
                                            <span className="text-xl font-bold text-white font-syne">PKR {(
                                                unpaidFees.filter(f => selectedFeeIds.includes(f._id)).reduce((s, f) => s + f.amount, 0) 
                                                - genForm.discount + genForm.lateFine
                                            ).toLocaleString()}</span>
                                        </div>
                                    </div>
                                    <div className="flex gap-4">
                                        <Button variant="ghost" onClick={() => setGenStep(2)} className="flex-1">Back</Button>
                                        <Button onClick={handleGenSubmit} className="flex-1 shadow-glow" disabled={!genForm.dueDate}>Finalize Invoice</Button>
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            )}

            {/* Mark Paid Modal */}
            {showPayModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
                    <Card className="w-full max-w-md animate-in zoom-in-95 duration-200">
                        <CardHeader className="flex flex-row items-center justify-between">
                            <h3 className="text-xl font-bold text-white font-syne">Update Payment</h3>
                            <button onClick={() => setShowPayModal(false)} className="text-muted-500 hover:text-white"><X size={20} /></button>
                        </CardHeader>
                        <CardContent className="p-6 space-y-6">
                            <div className="space-y-1">
                                <label className="text-[10px] uppercase font-black text-muted-500">Amount Paid (PKR)</label>
                                <input type="number" value={payForm.amountPaid} onChange={e => setPayForm({...payForm, amountPaid: Number(e.target.value)})} className="w-full bg-surface-base border border-surface-border rounded-xl p-3 text-sm text-white" />
                            </div>
                            <div className="space-y-1">
                                <label className="text-[10px] uppercase font-black text-muted-500">Method</label>
                                <select value={payForm.paymentMethod} onChange={e => setPayForm({...payForm, paymentMethod: e.target.value})} className="w-full bg-surface-base border border-surface-border rounded-xl p-3 text-sm text-white appearance-none">
                                    <option value="cash">Cash</option>
                                    <option value="jazzcash">JazzCash</option>
                                    <option value="easypaisa">EasyPaisa</option>
                                    <option value="bank">Bank Transfer</option>
                                </select>
                            </div>
                            <div className="space-y-1">
                                <label className="text-[10px] uppercase font-black text-muted-500">Payment Date</label>
                                <input type="date" value={payForm.paidAt} onChange={e => setPayForm({...payForm, paidAt: e.target.value})} className="w-full bg-surface-base border border-surface-border rounded-xl p-3 text-sm text-white" />
                            </div>
                            <Button onClick={handlePaySubmit} className="w-full shadow-glow">Confirm Record</Button>
                        </CardContent>
                    </Card>
                </div>
            )}
        </DashboardLayout>
    )
}

const StatCard = ({ label, value, icon: Icon, color }) => (
    <div className="bg-surface-elevated border border-surface-border p-6 rounded-3xl group hover:border-primary-500/30 transition-all shadow-saas">
        <div className="flex items-center justify-between mb-4">
            <div className={cn("p-3 rounded-2xl flex items-center justify-center text-white", color)}>
                <Icon size={20} />
            </div>
            <div className="text-right">
                <p className="text-2xl font-syne font-bold text-white">{value}</p>
                <p className="text-[10px] font-black uppercase tracking-widest text-muted-500 mt-0.5">{label}</p>
            </div>
        </div>
        <div className="h-1 bg-surface-base rounded-full overflow-hidden">
            <div className={cn("h-full w-1/3 rounded-full opacity-50", color.replace('bg-', 'bg-'))}></div>
        </div>
    </div>
)

export default AdminInvoices
