import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getStudentsApi, createStudentApi, deleteStudentApi } from '../../api/studentApi'

const AdminStudents = () => {
  const [students, setStudents] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ name: '', rollNumber: '', class: '', section: '', parentPhone: '' })
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')

  const fetchStudents = async () => {
    try {
      const res = await getStudentsApi()
      setStudents(res.data?.students ?? [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchStudents() }, [])

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
    setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      await createStudentApi(form)
      setForm({ name: '', rollNumber: '', class: '', section: '', parentPhone: '' })
      setShowForm(false)
      fetchStudents()
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to add student.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (id) => {
    if (!confirm('Deactivate this student?')) return
    try {
      await deleteStudentApi(id)
      fetchStudents()
    } catch (err) {
      console.error(err)
    }
  }

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">

        {/* Header (Dark) */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 mb-12">
          <div className="animate-fade-in">
            <h1 className="font-syne text-3xl md:text-4xl font-bold bg-gradient-to-r from-white to-muted-400 bg-clip-text text-transparent">Students</h1>
            <p className="text-muted-500 text-xs font-bold uppercase tracking-[0.2em] mt-2 block">
               <span className="text-primary-500 mr-2">{students.length}</span> Active Enrolled
            </p>
          </div>
          <button
            onClick={() => setShowForm(!showForm)}
            className={`inline-flex items-center justify-center px-8 py-3.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all duration-300 active:scale-95 cursor-pointer shadow-xl ${
              showForm 
                ? 'bg-muted-800 text-white border border-muted-700 hover:bg-muted-700' 
                : 'bg-primary-500 text-white hover:bg-primary-600 shadow-primary-900/20'
            }`}
          >
            {showForm ? (
              <span className="flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
                Cancel
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" /></svg>
                New Student
              </span>
            )}
          </button>
        </div>

        {/* Add Form (Dark) */}
        {showForm && (
          <div className="bg-muted-800 border border-muted-700 rounded-[2.5rem] p-8 md:p-10 mb-10 shadow-2xl animate-fade-up relative overflow-hidden">
             <div className="absolute top-0 right-0 w-32 h-32 bg-primary-500/5 blur-[40px] rounded-full pointer-events-none" />
            <div className="mb-8">
               <h2 className="font-syne text-xl font-bold text-white mb-1">Enrollment Form</h2>
               <p className="text-muted-500 text-xs font-medium uppercase tracking-widest">Provide academic credentials</p>
            </div>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-8">
              {[
                { name: 'name', placeholder: 'Legal Full Name', label: 'Student Name' },
                { name: 'rollNumber', placeholder: 'ST-000', label: 'Roll Number' },
                { name: 'class', placeholder: 'Grade Level', label: 'Class' },
                { name: 'section', placeholder: 'Alpha Section', label: 'Section' },
                { name: 'parentPhone', placeholder: '+92 3XX XXXXXXX', label: 'Emergency Contact' },
              ].map((field) => (
                <div key={field.name}>
                   <label className="block text-[10px] font-black text-muted-500 uppercase tracking-[0.2em] mb-3 ml-1">{field.label}</label>
                   <input
                     type="text"
                     name={field.name}
                     value={form[field.name]}
                     onChange={handleChange}
                     placeholder={field.placeholder}
                     className="w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-4 text-white placeholder-muted-700 focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all duration-300"
                   />
                </div>
              ))}
              {error && (
                <div className="md:col-span-full flex items-center gap-3 text-red-400 text-sm bg-red-500/5 border border-red-500/20 rounded-2xl px-5 py-4">
                   <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                   {error}
                </div>
              )}
              <div className="md:col-span-full pt-4">
                <button
                  type="submit"
                  disabled={submitting}
                  className="bg-primary-500 hover:bg-primary-600 disabled:opacity-50 text-white px-10 py-4 rounded-2xl text-xs font-black uppercase tracking-[0.2em] transition-all duration-300 shadow-xl shadow-primary-900/20 active:scale-95 cursor-pointer"
                >
                  {submitting ? 'Processing Enrollment...' : 'Register Student'}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Table Content (Reverted to Dark) */}
        <div className="bg-muted-800 border border-muted-700 rounded-[2.5rem] shadow-2xl overflow-hidden animate-fade-in">
          {loading ? (
            <div className="p-16 text-center text-muted-500 font-bold uppercase tracking-widest animate-pulse">Scanning records...</div>
          ) : students.length === 0 ? (
            <div className="p-20 text-center bg-muted-900/30">
              <div className="w-20 h-20 bg-muted-700/50 rounded-3xl flex items-center justify-center mx-auto mb-6 text-4xl">🎓</div>
              <p className="font-syne text-xl font-bold text-white mb-2">No Students Found</p>
              <p className="text-muted-500 text-sm max-w-xs mx-auto">Start by adding your first student using the control button above.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[600px]">
                <thead>
                  <tr className="bg-muted-900/50 border-b border-muted-700">
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-8 py-5">Profile</th>
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-8 py-5">Ident No.</th>
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-8 py-5">Academic Grade</th>
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-8 py-5">Billing</th>
                    <th className="text-right text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-8 py-5">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-muted-700/50">
                  {students.map((student) => (
                    <tr key={student._id} className="hover:bg-muted-700/30 transition-all duration-300 group">
                      <td className="px-8 py-6">
                         <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-2xl bg-primary-500/10 text-primary-400 flex items-center justify-center font-black text-sm border border-primary-500/20 group-hover:bg-primary-500 group-hover:text-white transition-all duration-300">
                               {student.name.charAt(0)}
                            </div>
                            <span className="text-white text-sm font-bold tracking-tight">{student.name}</span>
                         </div>
                      </td>
                      <td className="px-8 py-6 text-muted-400 text-sm font-medium tracking-widest uppercase">{student.rollNumber}</td>
                      <td className="px-8 py-6">
                         <span className="text-white text-sm font-black">{student.class}</span>
                         <span className="ml-2 text-[10px] text-muted-500 font-bold px-2 py-0.5 bg-muted-900 rounded-md uppercase tracking-wider">Sec {student.section}</span>
                      </td>
                      <td className="px-8 py-6">
                        <span className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-[0.2em] border ${
                          student.feeStatus === 'paid'
                            ? 'bg-green-500/10 text-green-400 border-green-500/20'
                            : 'bg-red-500/10 text-red-400 border-red-500/20'
                        }`}>
                          <div className={`w-1.5 h-1.5 rounded-full ${student.feeStatus === 'paid' ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]' : 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]'}`} />
                          {student.feeStatus}
                        </span>
                      </td>
                      <td className="px-8 py-6 text-right">
                        <button
                          onClick={() => handleDelete(student._id)}
                          className="bg-muted-900/50 text-muted-500 hover:text-red-400 p-2.5 rounded-2xl hover:bg-red-500/10 transition-all duration-300 active:scale-95 border border-muted-700/50 hover:border-red-500/20 cursor-pointer"
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </main>
    </div>
  )
}

export default AdminStudents
