import { useState, useEffect } from 'react'
import { useSearchParams } from 'react-router-dom'
import DashboardLayout from '../../components/layout/DashboardLayout'
import { Card, CardHeader, CardContent } from '../../components/ui/Card'
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '../../components/ui/Table'
import Badge from '../../components/ui/Badge'
import Button from '../../components/ui/Button'
import { 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  X, 
  CheckCircle2, 
  GraduationCap,
  Users
} from 'lucide-react'
import { getStudentsApi, createStudentApi, deleteStudentApi, updateStudentApi } from '../../api/studentApi'
import { cn } from '../../lib/utils'

const AdminStudents = () => {
  const [searchParams] = useSearchParams()
  const [students, setStudents] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ name: '', rollNumber: '', class: '', section: '', parentPhone: '' })
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')
  const [editingStudent, setEditingStudent] = useState(null)
  const [editForm, setEditForm] = useState({})
  const [editSubmitting, setEditSubmitting] = useState(false)
  
  const [searchQuery, setSearchQuery] = useState('')

  const fetchStudents = async () => {
    try {
      const res = await getStudentsApi()
      setStudents(res?.data?.students ?? res?.students ?? [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchStudents() }, [])

  useEffect(() => {
    if (searchParams.get('action') === 'add') {
      setShowForm(true)
    }
  }, [searchParams])

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
    setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      await createStudentApi(form)
      setForm({ name: '', rollNumber: '', class: '', section: '', parentPhone: '' })
      setShowForm(false)
      fetchStudents()
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to add student.')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (id) => {
    if (!confirm('Proceed with student deactivation?')) return
    try {
      await deleteStudentApi(id)
      fetchStudents()
    } catch (err) {
      console.error(err)
    }
  }

  const openEdit = (student) => {
    setEditingStudent(student)
    setEditForm({
      name: student.name,
      rollNumber: student.rollNumber,
      class: student.class,
      section: student.section,
      parentPhone: student.parentPhone,
    })
  }

  const handleEditSubmit = async (e) => {
    e.preventDefault()
    setEditSubmitting(true)
    try {
      await updateStudentApi(editingStudent._id, editForm)
      setEditingStudent(null)
      fetchStudents()
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to update.')
    } finally {
      setEditSubmitting(false)
    }
  }

  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    s.rollNumber.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <DashboardLayout>
      {/* Header Section */}
      <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="font-syne text-4xl font-bold text-white tracking-tight mb-2">
            Student Management
          </h1>
          <p className="text-muted-500 font-medium flex items-center gap-2 uppercase tracking-widest text-[10px]">
            <Users size={14} className="text-primary-500" />
            Control Center — {students.length} Total Enrolled
          </p>
        </div>
        <Button 
          onClick={() => setShowForm(!showForm)}
          className="gap-2"
        >
          {showForm ? <X size={18} /> : <Plus size={18} />}
          {showForm ? 'Close Enrollment' : 'New Admission'}
        </Button>
      </div>

      {/* Enrollment Form Modalish View */}
      {showForm && (
        <Card className="mb-10 animate-fade-up relative overflow-hidden border-primary-500/20 bg-primary-900/5">
           <div className="absolute top-0 right-0 w-64 h-64 bg-primary-500/5 blur-[80px] rounded-full pointer-events-none" />
           <CardHeader>
             <h2 className="font-syne text-xl font-bold text-white">New Enrollment</h2>
             <p className="text-muted-500 text-xs font-bold uppercase tracking-widest">Register a new student node</p>
           </CardHeader>
           <CardContent>
             <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  { name: 'name', label: 'Full Name', placeholder: 'Legal documentation name' },
                  { name: 'rollNumber', label: 'Identity Code', placeholder: 'ST-00000X' },
                  { name: 'class', label: 'Academic Grade', placeholder: 'Grade level' },
                  { name: 'section', label: 'System Section', placeholder: 'A, B, or C' },
                  { name: 'parentPhone', label: 'Guardian Sync', placeholder: '+92 3XX XXXXXXX' },
                ].map(field => (
                  <div key={field.name} className="space-y-2">
                    <label className="text-[10px] font-black text-muted-500 uppercase tracking-widest ml-1">{field.label}</label>
                    <input
                      name={field.name}
                      value={form[field.name]}
                      onChange={handleChange}
                      placeholder={field.placeholder}
                      className="w-full bg-surface-base border border-surface-border rounded-2xl px-5 py-4 text-white focus:outline-none focus:ring-4 focus:ring-primary-500/10 focus:border-primary-500 transition-all"
                    />
                  </div>
                ))}
                <div className="lg:col-span-full flex items-end justify-between pt-4">
                  {error && <p className="text-accent-rose text-xs font-bold uppercase tracking-widest">{error}</p>}
                  <Button type="submit" isLoading={submitting} className="ml-auto">Initialize Registration</Button>
                </div>
             </form>
           </CardContent>
        </Card>
      )}

      {/* Main Registry */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-6 pb-2">
           <div className="relative flex-1 max-w-sm group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-600 group-focus-within:text-primary-500 transition-colors" size={16} />
              <input 
                type="text" 
                placeholder="Filter results..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-surface-base border border-surface-border rounded-xl py-2.5 pl-12 pr-4 text-sm text-white focus:outline-none focus:ring-2 focus:ring-primary-500/10"
              />
           </div>
           <Badge variant="info" className="hidden sm:block">Live Sync Active</Badge>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>System Identity</TableHead>
                <TableHead>ID Code</TableHead>
                <TableHead>Current Grade</TableHead>
                <TableHead>Billing Status</TableHead>
                <TableHead className="text-right">Administration</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStudents.map((student) => (
                <TableRow key={student._id}>
                  <TableCell>
                     <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-2xl bg-primary-600/10 text-primary-400 flex items-center justify-center font-black text-xs border border-primary-500/20 group-hover:bg-primary-600 group-hover:text-white transition-all">
                           {student.name.charAt(0)}
                        </div>
                        <span className="font-bold text-white whitespace-nowrap">{student.name}</span>
                     </div>
                  </TableCell>
                  <TableCell className="font-mono text-[11px] tracking-widest">{student.rollNumber}</TableCell>
                  <TableCell>
                     <div className="flex items-center gap-2">
                        <span className="font-black text-white">Grade {student.class}</span>
                        <Badge variant="default" className="bg-surface-base border-surface-border">Sec {student.section}</Badge>
                     </div>
                  </TableCell>
                  <TableCell>
                     <Badge variant={student.feeStatus === 'paid' ? 'success' : 'danger'}>
                       {student.feeStatus}
                     </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                       <Button 
                         variant="ghost" 
                         size="sm" 
                         className="h-9 w-9 p-0 rounded-xl"
                         onClick={() => openEdit(student)}
                       >
                         <Edit3 size={16} />
                       </Button>
                       <Button 
                         variant="ghost" 
                         size="sm" 
                         className="h-9 w-9 p-0 rounded-xl text-accent-rose hover:bg-accent-rose/10"
                         onClick={() => handleDelete(student._id)}
                       >
                         <Trash2 size={16} />
                       </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {filteredStudents.length === 0 && (
                <TableRow>
                   <TableCell colSpan={5} className="py-20 text-center text-muted-600">
                      <GraduationCap size={48} className="mx-auto mb-4 opacity-10" />
                      <p className="text-xs font-black uppercase tracking-[0.3em]">No student records found in this segment</p>
                   </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit Modal (Standardized UI) */}
      {editingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-muted-950/80 backdrop-blur-md">
           <Card className="w-full max-w-2xl animate-fade-up shadow-saas-heavy relative">
              <button 
                onClick={() => setEditingStudent(null)}
                className="absolute top-6 right-6 text-muted-500 hover:text-white transition-colors"
              >
                <X size={24} />
              </button>
              <CardHeader>
                <h2 className="text-2xl font-syne font-bold text-white mb-1">Update Student</h2>
                <Badge variant="info">Modifying Profile: {editingStudent.rollNumber}</Badge>
              </CardHeader>
              <CardContent>
                 <form onSubmit={handleEditSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {[
                      { key: 'name', label: 'Full Documentation Name' },
                      { key: 'rollNumber', label: 'System Roll Identifier' },
                      { key: 'class', label: 'Assigned Grade Level' },
                      { key: 'section', label: 'Assigned Section' },
                      { key: 'parentPhone', label: 'Emergency Contact Hash' },
                    ].map(field => (
                      <div key={field.key} className="space-y-2">
                         <label className="text-[10px] font-black text-muted-500 uppercase tracking-widest ml-1">{field.label}</label>
                         <input
                           value={editForm[field.key] || ''}
                           onChange={e => setEditForm({ ...editForm, [field.key]: e.target.value })}
                           className="w-full bg-surface-base border border-surface-border rounded-2xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                         />
                      </div>
                    ))}
                    <div className="md:col-span-full flex gap-4 pt-6">
                       <Button variant="ghost" onClick={() => setEditingStudent(null)} className="flex-1">Exit Sync</Button>
                       <Button type="submit" isLoading={editSubmitting} className="flex-1">Authorize Changes</Button>
                    </div>
                 </form>
              </CardContent>
           </Card>
        </div>
      )}
    </DashboardLayout>
  )
}

export default AdminStudents
