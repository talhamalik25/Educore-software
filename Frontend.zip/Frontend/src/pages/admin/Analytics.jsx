import React, { useState, useEffect } from 'react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  LineChart,
  Line
} from 'recharts'
import { 
  TrendingUp, 
  Users, 
  UserCheck, 
  Wallet, 
  AlertCircle, 
  Award,
  Loader2,
  ChevronRight,
  Filter
} from 'lucide-react'
import { 
  getOverviewAnalytics, 
  getAttendanceAnalytics, 
  getFeeAnalytics, 
  getResultsAnalytics 
} from '../../api/analyticsApi'
import { cn } from '../../lib/utils'

const PIE_COLORS = ['#00A896', '#ef4444', '#f59e0b', '#3b82f6', '#8b5cf6', '#6b7280'];
const GRADE_COLORS = {
    'A+': '#064e3b',
    'A': '#059669',
    'B': '#00A896',
    'C': '#ca8a04',
    'D': '#d97706',
    'F': '#dc2626'
};

const StatCard = ({ title, value, icon: Icon, color, subtext }) => (
  <div className="bg-surface-elevated border border-surface-border rounded-2xl p-6 shadow-saas hover:border-primary-500/30 transition-all group">
    <div className="flex items-center justify-between mb-4">
      <div className={cn("p-3 rounded-xl", color)}>
        <Icon size={24} className="text-white" />
      </div>
      <div className="text-right">
        <p className="text-3xl font-syne font-bold text-white tracking-tight">{value}</p>
        <p className="text-xs text-muted-400 font-medium uppercase tracking-wider mt-1">{title}</p>
      </div>
    </div>
    {subtext && <p className="text-[10px] text-muted-500 italic mt-2">{subtext}</p>}
  </div>
);

const Analytics = () => {
    const [activeTab, setActiveTab] = useState('overview');
    const [loading, setLoading] = useState(true);
    const [data, setData] = useState(null);

    // Filter states for Results
    const [filters, setFilters] = useState({ class: '', section: '', examType: 'final' });

    useEffect(() => {
        loadTabData(activeTab);
    }, [activeTab]);

    const loadTabData = async (tab) => {
        setLoading(true);
        try {
            let res;
            if (tab === 'overview') res = await getOverviewAnalytics();
            else if (tab === 'attendance') res = await getAttendanceAnalytics();
            else if (tab === 'fees') res = await getFeeAnalytics();
            else if (tab === 'results') res = await getResultsAnalytics(filters);
            
            setData(res?.data?.data ?? null);
        } catch (error) {
            console.error(`Error loading ${tab} data:`, error);
        } finally {
            setLoading(false);
        }
    };

    const handleApplyFilters = () => {
        loadTabData('results');
    };

    return (
        <DashboardLayout title="School Analytics">
            <div className="space-y-8">
                {/* Tab Navigation */}
                <div className="flex items-center gap-2 bg-surface-elevated p-1.5 rounded-2xl border border-surface-border w-fit">
                    {['overview', 'attendance', 'fees', 'results'].map((tab) => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={cn(
                                "px-6 py-2.5 rounded-xl text-sm font-bold capitalize transition-all",
                                activeTab === tab 
                                    ? "bg-primary-600 text-white shadow-glow" 
                                    : "text-muted-400 hover:text-white hover:bg-white/5"
                            )}
                        >
                            {tab}
                        </button>
                    ))}
                </div>

                {loading ? (
                    <div className="h-[60vh] flex flex-col items-center justify-center gap-4">
                        <Loader2 className="text-primary-500 animate-spin" size={48} />
                        <p className="text-muted-400 font-medium animate-pulse">Analyzing school data...</p>
                    </div>
                ) : (
                    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                        {!loading && !data && (
                          <div className="h-[40vh] flex flex-col items-center justify-center gap-4">
                            <AlertCircle className="text-rose-500" size={48} />
                            <p className="text-muted-400 font-medium">Failed to load analytics data. Check your connection.</p>
                          </div>
                        )}

                        {activeTab === 'overview' && data && (
                            <div className="space-y-8">
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                    <StatCard title="Students" value={data.totalStudents} icon={Users} color="bg-blue-600" subtext="Active enrollment" />
                                    <StatCard title="Teachers" value={data.totalTeachers} icon={UserCheck} color="bg-purple-600" subtext="Staff body" />
                                    <StatCard title="Parents" value={data.totalParents} icon={Users} color="bg-teal-600" subtext="Registered accounts" />
                                    <StatCard 
                                        title="Attendance Today" 
                                        value={`${data.attendanceToday}%`} 
                                        icon={Calendar} 
                                        color={data.attendanceToday > 80 ? "bg-emerald-600" : "bg-rose-600"} 
                                        subtext="Present percentage"
                                    />
                                    <StatCard title="Fees Collected" value={`Rs. ${(data.feesCollectedThisMonth ?? 0).toLocaleString()}`} icon={Wallet} color="bg-emerald-600" subtext={`Pending: ${data.pendingFeesCount ?? 0}`} />
                                    <StatCard title="Open Complaints" value={data.complaintsOpen} icon={AlertCircle} color="bg-orange-600" subtext="Pending resolution" />
                                </div>
                            </div>
                        )}

                        {activeTab === 'attendance' && data && (
                            <div className="space-y-8">
                                <div className="bg-surface-elevated border border-surface-border rounded-3xl p-8 shadow-saas">
                                    <h3 className="font-syne text-xl font-bold text-white mb-8 flex items-center gap-3">
                                        <TrendingUp className="text-primary-500" />
                                        Daily Attendance Trend
                                    </h3>
                                    <div className="h-[350px]">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <BarChart data={data.dailyAttendance ?? []}>
                                                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                                                <XAxis dataKey="date" stroke="#737373" fontSize={10} axisLine={false} tickLine={false} />
                                                <YAxis stroke="#737373" fontSize={10} axisLine={false} tickLine={false} />
                                                <Tooltip 
                                                    contentStyle={{ backgroundColor: '#171717', border: '1px solid #262626', borderRadius: '12px' }}
                                                    itemStyle={{ fontSize: '12px' }}
                                                />
                                                <Legend iconType="circle" wrapperStyle={{ paddingTop: '20px' }} />
                                                <Bar dataKey="presentCount" name="Present" fill="#00A896" radius={[4, 4, 0, 0]} />
                                                <Bar dataKey="absentCount" name="Absent" fill="#ef4444" radius={[4, 4, 0, 0]} />
                                            </BarChart>
                                        </ResponsiveContainer>
                                    </div>
                                </div>

                                <div className="bg-surface-elevated border border-surface-border rounded-3xl overflow-hidden shadow-saas">
                                    <div className="p-8 border-b border-surface-border flex items-center justify-between">
                                        <h3 className="font-syne text-xl font-bold text-white">Worst Attendance (last 30 days)</h3>
                                        <Badge variant="error" className="uppercase tracking-widest text-[10px]">Action Required</Badge>
                                    </div>
                                    <div className="overflow-x-auto">
                                        <table className="w-full text-left">
                                            <thead>
                                                <tr className="bg-white/5 text-muted-400 text-[10px] uppercase tracking-widest">
                                                    <th className="px-8 py-4">Student</th>
                                                    <th className="px-8 py-4">Class</th>
                                                    <th className="px-8 py-4">Section</th>
                                                    <th className="px-8 py-4">Attendance %</th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-surface-border">
                                                {(data.worstStudents ?? []).map((s, idx) => (
                                                    <tr key={idx} className={cn("hover:bg-white/[0.02] transition-colors", s.percentage < 70 ? "bg-rose-500/5" : "")}>
                                                        <td className="px-8 py-5 text-sm font-bold text-white">{s.name}</td>
                                                        <td className="px-8 py-5 text-sm text-muted-300">{s.class}</td>
                                                        <td className="px-8 py-5 text-sm text-muted-300">{s.section}</td>
                                                        <td className="px-8 py-5">
                                                            <span className={cn(
                                                                "px-3 py-1 rounded-full text-xs font-black",
                                                                s.percentage < 70 ? "bg-rose-500/20 text-rose-500" : "bg-emerald-500/20 text-emerald-500"
                                                            )}>
                                                                {s.percentage}%
                                                            </span>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        )}

                        {activeTab === 'fees' && data && (
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                                <div className="bg-surface-elevated border border-surface-border rounded-3xl p-8 shadow-saas lg:col-span-2">
                                    <h3 className="font-syne text-xl font-bold text-white mb-8">Monthly Collection (PKR)</h3>
                                    <div className="h-[300px]">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <BarChart data={data.monthlyCollection}>
                                                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                                                <XAxis dataKey="month" stroke="#737373" fontSize={10} axisLine={false} tickLine={false} />
                                                <YAxis stroke="#737373" fontSize={10} axisLine={false} tickLine={false} />
                                                <Tooltip contentStyle={{ backgroundColor: '#171717', border: '1px solid #262626', borderRadius: '12px' }} />
                                                <Bar dataKey="collected" name="Collected" fill="#00A896" radius={[4, 4, 0, 0]} />
                                                <Bar dataKey="pending" name="Pending" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                                            </BarChart>
                                        </ResponsiveContainer>
                                    </div>
                                </div>

                                <div className="bg-surface-elevated border border-surface-border rounded-3xl p-8 shadow-saas flex flex-col">
                                    <h3 className="font-syne text-xl font-bold text-white mb-8">Payment Methods</h3>
                                    <div className="flex-1 min-h-[300px] flex items-center justify-center">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <PieChart>
                                                <Pie
                                                    data={data.paymentMethodBreakdown ?? []}
                                                    cx="50%"
                                                    cy="50%"
                                                    innerRadius={60}
                                                    outerRadius={80}
                                                    paddingAngle={5}
                                                    dataKey="count"
                                                    nameKey="method"
                                                >
                                                    {(data.paymentMethodBreakdown ?? []).map((entry, index) => (
                                                        <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                                                    ))}
                                                </Pie>
                                                <Tooltip contentStyle={{ backgroundColor: '#171717', border: '1px solid #262626', borderRadius: '12px' }} />
                                                <Legend verticalAlign="bottom" height={36}/>
                                            </PieChart>
                                        </ResponsiveContainer>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 gap-6">
                                    <StatCard title="Collection Rate" value={`${data.collectionRate ?? 0}%`} icon={TrendingUp} color="bg-primary-600" />
                                    <StatCard title="Fee Defaulters" value={data.defaulterCount ?? 0} icon={AlertCircle} color="bg-rose-600" />
                                </div>
                            </div>
                        )}

                        {activeTab === 'results' && data && (
                            <div className="space-y-8">
                                <div className="bg-surface-elevated border border-surface-border rounded-3xl p-6 shadow-saas flex flex-wrap items-end gap-4">
                                    <div className="flex-1 min-w-[150px]">
                                        <label className="text-[10px] uppercase font-black text-muted-500 tracking-[0.2em] mb-2 block">Class</label>
                                        <input 
                                            type="text" 
                                            value={filters.class} 
                                            onChange={(e) => setFilters({...filters, class: e.target.value})}
                                            placeholder="e.g. 10"
                                            className="w-full bg-surface-base border border-surface-border rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                                        />
                                    </div>
                                    <div className="flex-1 min-w-[150px]">
                                        <label className="text-[10px] uppercase font-black text-muted-500 tracking-[0.2em] mb-2 block">Section</label>
                                        <input 
                                            type="text" 
                                            value={filters.section} 
                                            onChange={(e) => setFilters({...filters, section: e.target.value})}
                                            placeholder="e.g. A"
                                            className="w-full bg-surface-base border border-surface-border rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                                        />
                                    </div>
                                    <div className="flex-1 min-w-[150px]">
                                        <label className="text-[10px] uppercase font-black text-muted-500 tracking-[0.2em] mb-2 block">Exam Type</label>
                                        <select 
                                            value={filters.examType} 
                                            onChange={(e) => setFilters({...filters, examType: e.target.value})}
                                            className="w-full bg-surface-base border border-surface-border rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                                        >
                                            <option value="monthly">Monthly Test</option>
                                            <option value="midterm">Mid Term</option>
                                            <option value="final">Final Exam</option>
                                            <option value="quiz">Quiz</option>
                                        </select>
                                    </div>
                                    <button 
                                        onClick={handleApplyFilters}
                                        className="bg-primary-600 hover:bg-primary-500 text-white font-bold text-sm px-8 py-3.5 rounded-xl transition-all shadow-glow flex items-center gap-2"
                                    >
                                        <Filter size={18} />
                                        Apply Filters
                                    </button>
                                </div>

                                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                                    <div className="bg-surface-elevated border border-surface-border rounded-3xl p-8 shadow-saas lg:col-span-2">
                                        <h3 className="font-syne text-xl font-bold text-white mb-8">Subject Average %</h3>
                                        <div className="h-[300px]">
                                            <ResponsiveContainer width="100%" height="100%">
                                                <BarChart data={data.subjectWiseAverage ?? []}>
                                                    <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                                                    <XAxis dataKey="subject" stroke="#737373" fontSize={10} />
                                                    <YAxis stroke="#737373" fontSize={10} domain={[0, 100]} />
                                                    <Tooltip contentStyle={{ backgroundColor: '#171717', border: '1px solid #262626', borderRadius: '12px' }} />
                                                    <Bar dataKey="avgPercentage" name="Avg %" fill="#00A896" radius={[4, 4, 0, 0]} />
                                                </BarChart>
                                            </ResponsiveContainer>
                                        </div>
                                    </div>

                                    <div className="bg-surface-elevated border border-surface-border rounded-3xl p-8 shadow-saas">
                                        <h3 className="font-syne text-xl font-bold text-white mb-8">Grade Distribution</h3>
                                        <div className="h-[300px]">
                                            <ResponsiveContainer width="100%" height="100%">
                                                <PieChart>
                                                    <Pie
                                                        data={data.gradeDistribution ?? []}
                                                        cx="50%"
                                                        cy="50%"
                                                        innerRadius={60}
                                                        outerRadius={80}
                                                        paddingAngle={5}
                                                        dataKey="count"
                                                        nameKey="grade"
                                                    >
                                                        {(data.gradeDistribution ?? []).map((entry, index) => (
                                                            <Cell key={`cell-${index}`} fill={GRADE_COLORS[entry.grade] || '#6b7280'} />
                                                        ))}
                                                    </Pie>
                                                    <Tooltip contentStyle={{ backgroundColor: '#171717', border: '1px solid #262626', borderRadius: '12px' }} />
                                                    <Legend />
                                                </PieChart>
                                            </ResponsiveContainer>
                                        </div>
                                    </div>

                                    <div className="bg-surface-elevated border border-surface-border rounded-3xl overflow-hidden shadow-saas lg:col-span-3">
                                        <div className="p-8 border-b border-surface-border flex items-center justify-between">
                                            <h3 className="font-syne text-xl font-bold text-white">Top Performing Students</h3>
                                            <Award className="text-primary-500" size={24} />
                                        </div>
                                        <div className="overflow-x-auto">
                                            <table className="w-full text-left">
                                                <thead>
                                                    <tr className="bg-white/5 text-muted-400 text-[10px] uppercase tracking-widest">
                                                        <th className="px-8 py-4">Position</th>
                                                        <th className="px-8 py-4">Student Name</th>
                                                        <th className="px-8 py-4">Class</th>
                                                        <th className="px-8 py-4 text-right">Aggregate %</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="divide-y divide-surface-border">
                                                    {(data.topStudents ?? []).map((s, idx) => (
                                                        <tr key={idx} className="hover:bg-white/[0.02] transition-colors">
                                                            <td className="px-8 py-5">
                                                                <div className={cn(
                                                                    "w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs",
                                                                    idx === 0 ? "bg-primary-600 text-white" : "bg-surface-base text-muted-400"
                                                                )}>
                                                                    #{idx + 1}
                                                                </div>
                                                            </td>
                                                            <td className="px-8 py-5 text-sm font-bold text-white">{s.name}</td>
                                                            <td className="px-8 py-5 text-sm text-muted-300">Class {s.class}</td>
                                                            <td className="px-8 py-5 text-sm font-black text-primary-400 text-right">{s.avgPercentage}%</td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </DashboardLayout>
    );
};

export default Analytics;

// Helper Badge implementation if needed
const Badge = ({ children, variant = 'info', className }) => {
    const variants = {
        info: 'bg-blue-500/10 text-blue-500',
        success: 'bg-emerald-500/10 text-emerald-500',
        error: 'bg-rose-500/10 text-rose-500',
        warning: 'bg-amber-500/10 text-amber-500',
    };
    return (
        <span className={cn("px-3 py-1 rounded-full text-[10px] font-black", variants[variant], className)}>
            {children}
        </span>
    );
};

const Calendar = ({ className, size }) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        width={size} height={size} 
        viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" 
        className={className}
    >
        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
        <line x1="16" y1="2" x2="16" y2="6"/>
        <line x1="8" y1="2" x2="8" y2="6"/>
        <line x1="3" y1="10" x2="21" y2="10"/>
    </svg>
);
