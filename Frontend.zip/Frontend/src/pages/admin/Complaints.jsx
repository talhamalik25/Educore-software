import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getAllComplaintsApi, replyToComplaintApi, updateComplaintStatusApi, deleteComplaintApi, getComplaintStatsApi } from '../../api/complaintApi'
import { MessageSquare, Filter, Trash2, Reply, CheckCircle2, Clock, AlertCircle, X, ChevronRight } from 'lucide-react'

const AdminComplaints = () => {
  const [complaints, setComplaints] = useState([])
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({ status: '', category: '', priority: '' })
  
  const [showReplyModal, setShowModal] = useState(false)
  const [selectedComplaint, setSelectedComplaint] = useState(null)
  const [replyText, setReplyText] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const fetchData = async () => {
    setLoading(true)
    try {
      const [complaintsRes, statsRes] = await Promise.all([
        getAllComplaintsApi(filters),
        getComplaintStatsApi()
      ])
      setComplaints(complaintsRes.data?.complaints ?? [])
      setStats(statsRes.data?.data ?? null)
    } catch (err) {
      console.error('Failed to fetch complaints:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [filters])

  const handleOpenReply = (complaint) => {
    setSelectedComplaint(complaint)
    setReplyText(complaint.adminReply || '')
    setShowModal(true)
  }

  const handleReplySubmit = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      await replyToComplaintApi(selectedComplaint._id, replyText)
      setShowModal(false)
      fetchData()
    } catch (err) {
      alert('Failed to send reply')
    } finally {
      setSubmitting(false)
    }
  }

  const handleStatusChange = async (id, newStatus) => {
    if (!window.confirm(`Change status to ${newStatus}?`)) return
    try {
      await updateComplaintStatusApi(id, newStatus)
      fetchData()
    } catch (err) {
      alert('Failed to update status')
    }
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this complaint?')) return
    try {
      await deleteComplaintApi(id)
      fetchData()
    } catch (err) {
      alert('Failed to delete complaint')
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'open': return 'bg-red-500/10 text-red-400 border-red-500/20'
      case 'in_progress': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
      case 'resolved': return 'bg-green-500/10 text-green-400 border-green-500/20'
      case 'closed': return 'bg-muted-700 text-muted-400 border-muted-600'
      default: return 'bg-muted-800 text-muted-500'
    }
  }

  const getPriorityBadge = (priority) => {
    switch (priority) {
      case 'high': return 'bg-red-500/10 text-red-400'
      case 'medium': return 'bg-yellow-500/10 text-yellow-400'
      case 'low': return 'bg-green-500/10 text-green-400'
      default: return 'text-muted-500'
    }
  }

  const inputClass = "w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-3 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all text-sm"

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        <div className="mb-12">
          <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">Feedback Hub</h1>
          <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
             <span className="w-1.5 h-1.5 bg-primary-500 rounded-full animate-pulse" />
             Institutional Complaint Management
          </p>
        </div>

        {/* Analytics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6 mb-12">
          <div className="bg-muted-800 border border-muted-700 p-8 rounded-[2.5rem] shadow-xl">
             <div className="w-12 h-12 bg-primary-500/10 rounded-2xl flex items-center justify-center text-primary-400 mb-6"><MessageSquare size={24} /></div>
             <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest mb-1">Total Submissions</p>
             <h3 className="text-4xl font-bold font-syne">{complaints.length}</h3>
          </div>
          <div className="bg-muted-800 border border-muted-700 p-8 rounded-[2.5rem] shadow-xl">
             <div className="w-12 h-12 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-400 mb-6"><AlertCircle size={24} /></div>
             <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest mb-1">Open Issues</p>
             <h3 className="text-4xl font-bold font-syne">{complaints.filter(c => c.status === 'open').length}</h3>
          </div>
          <div className="bg-muted-800 border border-muted-700 p-8 rounded-[2.5rem] shadow-xl">
             <div className="w-12 h-12 bg-yellow-500/10 rounded-2xl flex items-center justify-center text-yellow-400 mb-6"><Clock size={24} /></div>
             <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest mb-1">In Progress</p>
             <h3 className="text-4xl font-bold font-syne">{complaints.filter(c => c.status === 'in_progress').length}</h3>
          </div>
          <div className="bg-muted-800 border border-muted-700 p-8 rounded-[2.5rem] shadow-xl">
             <div className="w-12 h-12 bg-green-500/10 rounded-2xl flex items-center justify-center text-green-400 mb-6"><CheckCircle2 size={24} /></div>
             <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest mb-1">Resolved</p>
             <h3 className="text-4xl font-bold font-syne">{complaints.filter(c => c.status === 'resolved').length}</h3>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10 bg-muted-800/50 p-6 rounded-[2rem] border border-muted-700/50">
          <div>
            <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Status</label>
            <select className={inputClass} value={filters.status} onChange={e => setFilters({...filters, status: e.target.value})}>
              <option value="">All Statuses</option>
              <option value="open">Open</option>
              <option value="in_progress">In Progress</option>
              <option value="resolved">Resolved</option>
              <option value="closed">Closed</option>
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Category</label>
            <select className={inputClass} value={filters.category} onChange={e => setFilters({...filters, category: e.target.value})}>
              <option value="">All Categories</option>
              <option value="academic">Academic</option>
              <option value="fee">Fee</option>
              <option value="behavior">Behavior</option>
              <option value="facility">Facility</option>
              <option value="teacher">Teacher</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Priority</label>
            <select className={inputClass} value={filters.priority} onChange={e => setFilters({...filters, priority: e.target.value})}>
              <option value="">All Priorities</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>
        </div>

        {/* Complaints Table */}
        <div className="bg-muted-800 border border-muted-700 rounded-[2.5rem] overflow-hidden shadow-2xl">
          {loading ? (
            <div className="p-20 text-center animate-pulse">
              <p className="text-muted-500 font-black uppercase tracking-[0.2em]">Synchronizing Data Nodes...</p>
            </div>
          ) : complaints.length === 0 ? (
            <div className="p-20 text-center">
              <h3 className="font-syne text-xl font-bold text-white mb-2">No Feedback Detected</h3>
              <p className="text-muted-500 text-sm">No complaints match your current filter parameters.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-muted-900/50">
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest">Submission</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest">User</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-center">Priority</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-center">Status</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-right">Control</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-muted-700/50">
                  {complaints.map(c => (
                    <tr key={c._id} className="hover:bg-muted-700/30 transition-colors group">
                      <td className="px-8 py-6 max-w-md">
                        <div className="flex flex-col gap-1">
                          <span className="text-xs font-black uppercase tracking-widest text-primary-400">{c.category}</span>
                          <p className="text-sm font-bold text-white">{c.title}</p>
                          <p className="text-xs text-muted-500 line-clamp-1">{c.description}</p>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        {c.isAnonymous ? (
                          <div className="flex items-center gap-2 text-muted-500 italic text-xs font-bold uppercase tracking-widest">
                            <X size={12} />
                            Anonymous
                          </div>
                        ) : (
                          <div className="flex flex-col">
                            <span className="text-sm font-bold text-white">{c.submittedBy?.name}</span>
                            <span className="text-[10px] text-muted-500 font-medium capitalize">{c.role}</span>
                          </div>
                        )}
                      </td>
                      <td className="px-8 py-6 text-center">
                        <span className={`text-[10px] font-black uppercase tracking-widest ${getPriorityBadge(c.priority)}`}>
                          {c.priority}
                        </span>
                      </td>
                      <td className="px-8 py-6 text-center">
                        <span className={`px-4 py-1 rounded-lg text-[10px] font-black border ${getStatusBadge(c.status)}`}>
                          {c.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="px-8 py-6 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button onClick={() => handleOpenReply(c)} className="p-2.5 bg-muted-900 text-muted-400 hover:text-white hover:bg-muted-700 rounded-xl transition-all"><Reply size={14} /></button>
                          <select 
                            className="bg-muted-900 text-[10px] font-bold text-muted-400 border border-muted-700 rounded-xl px-2 py-2 focus:outline-none"
                            value={c.status}
                            onChange={(e) => handleStatusChange(c._id, e.target.value)}
                          >
                            <option value="open">Open</option>
                            <option value="in_progress">Progress</option>
                            <option value="resolved">Resolved</option>
                            <option value="closed">Closed</option>
                          </select>
                          <button onClick={() => handleDelete(c._id)} className="p-2.5 bg-muted-900 text-red-400/50 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-all"><Trash2 size={14} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Reply Modal */}
        {showReplyModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={() => setShowModal(false)} />
            <div className="relative w-full max-w-2xl bg-muted-800 border border-muted-700 rounded-[3rem] shadow-2xl overflow-hidden animate-fade-up">
              <div className="p-10 border-b border-muted-700/50 flex justify-between items-center">
                <h2 className="font-syne text-2xl font-bold text-white">Transmit Official Reply</h2>
                <button onClick={() => setShowModal(false)} className="p-3 bg-muted-900 rounded-2xl hover:bg-muted-700"><X size={20} /></button>
              </div>
              <form onSubmit={handleReplySubmit} className="p-10">
                <div className="mb-8 p-6 bg-muted-900/50 border border-muted-700 rounded-3xl">
                   <p className="text-xs font-black uppercase tracking-widest text-muted-500 mb-2">Subject: {selectedComplaint?.title}</p>
                   <p className="text-sm text-muted-300 italic">"{selectedComplaint?.description}"</p>
                </div>
                <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Official Response</label>
                <textarea 
                  className={`${inputClass} h-40 mb-8`} 
                  placeholder="Draft your administrative response here..."
                  value={replyText}
                  onChange={e => setReplyText(e.target.value)}
                  required
                />
                <div className="flex gap-4">
                  <button type="button" onClick={() => setShowModal(false)} className="flex-1 bg-muted-900 py-4 rounded-2xl font-bold uppercase tracking-widest text-[10px]">Abort</button>
                  <button type="submit" disabled={submitting} className="flex-1 bg-primary-500 py-4 rounded-2xl font-bold uppercase tracking-widest text-[10px] hover:bg-primary-600 transition-all shadow-xl shadow-primary-900/20">
                    {submitting ? 'Transmitting...' : 'Confirm Response'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </main>
    </div>
  )
}

export default AdminComplaints
