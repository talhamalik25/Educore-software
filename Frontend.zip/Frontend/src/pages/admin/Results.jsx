import { useState, useEffect, useMemo } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getResultsByClassApi, deleteResultApi } from '../../api/resultApi'
import { Plus, Edit2, Trash2, Filter, BarChart, TrendingUp, Users, Award } from 'lucide-react'
import { BarChart as ReBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts'

const AdminResults = () => {
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  
  const [filters, setFilters] = useState({
    class: '',
    section: '',
    examType: ''
  })

  const fetchResults = async () => {
    if (!filters.class || !filters.section) return
    setLoading(true)
    try {
      const res = await getResultsByClassApi(filters.class, filters.section, filters.examType)
      setResults(res.data?.results ?? [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (filters.class && filters.section) {
      fetchResults()
    }
  }, [filters])

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this result?')) return
    try {
      await deleteResultApi(id)
      fetchResults()
    } catch (err) {
      console.error(err)
      alert('Failed to delete result')
    }
  }

  // Analytics Calculations
  const analytics = useMemo(() => {
    if (results.length === 0) return null

    const totalStudents = results.length
    const avgScore = results.reduce((acc, curr) => acc + (curr.obtainedMarks / curr.totalMarks) * 100, 0) / totalStudents
    const passCount = results.filter(r => r.grade !== 'F').length
    const passPercentage = (passCount / totalStudents) * 100

    // Subject-wise average
    const subjects = {}
    results.forEach(r => {
      if (!subjects[r.subject]) {
        subjects[r.subject] = { total: 0, count: 0 }
      }
      subjects[r.subject].total += (r.obtainedMarks / r.totalMarks) * 100
      subjects[r.subject].count += 1
    })

    const subjectData = Object.keys(subjects).map(sub => ({
      name: sub,
      average: Math.round(subjects[sub].total / subjects[sub].count)
    }))

    return {
      avgScore: Math.round(avgScore),
      passPercentage: Math.round(passPercentage),
      totalStudents,
      subjectData
    }
  }, [results])

  const getGradeColor = (grade) => {
    switch (grade) {
      case 'A+': return 'bg-green-500/10 text-green-400 border-green-500/20'
      case 'A': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
      case 'B': return 'bg-blue-500/10 text-blue-400 border-blue-500/20'
      case 'C': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
      case 'D': return 'bg-orange-500/10 text-orange-400 border-orange-500/20'
      case 'F': return 'bg-red-500/10 text-red-400 border-red-500/20'
      default: return 'bg-muted-700 text-muted-400 border-muted-600'
    }
  }

  const inputClass = "w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-3 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all"

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        {/* Header */}
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8 mb-12">
          <div>
            <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">Academic Oversight</h1>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
               <span className="w-1.5 h-1.5 bg-primary-500 rounded-full animate-pulse" />
               Institutional Performance Analytics
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10 bg-muted-800/50 p-6 rounded-[2rem] border border-muted-700/50 shadow-saas">
          <div>
            <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Class</label>
            <input 
              type="text" 
              placeholder="e.g. 10" 
              className={inputClass}
              value={filters.class}
              onChange={e => setFilters({...filters, class: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Section</label>
            <input 
              type="text" 
              placeholder="e.g. A" 
              className={inputClass}
              value={filters.section}
              onChange={e => setFilters({...filters, section: e.target.value})}
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Exam Type</label>
            <select 
              className={inputClass}
              value={filters.examType}
              onChange={e => setFilters({...filters, examType: e.target.value})}
            >
              <option value="">All Exams</option>
              <option value="monthly">Monthly</option>
              <option value="midterm">Midterm</option>
              <option value="final">Final</option>
              <option value="quiz">Quiz</option>
            </select>
          </div>
        </div>

        {analytics && (
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-12 animate-fade-in">
            {/* Stats */}
            <div className="xl:col-span-1 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-muted-800 border border-muted-700 p-8 rounded-[2.5rem] shadow-xl">
                <div className="w-12 h-12 bg-primary-500/10 rounded-2xl flex items-center justify-center text-primary-400 mb-6">
                  <TrendingUp size={24} />
                </div>
                <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest mb-1">Class Average</p>
                <h3 className="text-4xl font-bold font-syne text-white">{analytics.avgScore}%</h3>
              </div>
              <div className="bg-muted-800 border border-muted-700 p-8 rounded-[2.5rem] shadow-xl">
                <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-400 mb-6">
                  <Award size={24} />
                </div>
                <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest mb-1">Pass Rate</p>
                <h3 className="text-4xl font-bold font-syne text-white">{analytics.passPercentage}%</h3>
              </div>
              <div className="bg-muted-800 border border-muted-700 p-8 rounded-[2.5rem] shadow-xl sm:col-span-2">
                <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-400 mb-6">
                  <Users size={24} />
                </div>
                <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest mb-1">Total Records</p>
                <h3 className="text-4xl font-bold font-syne text-white">{analytics.totalStudents}</h3>
              </div>
            </div>

            {/* Chart */}
            <div className="xl:col-span-2 bg-muted-800 border border-muted-700 p-10 rounded-[2.5rem] shadow-xl h-[400px]">
              <div className="flex items-center justify-between mb-8">
                <h3 className="font-syne text-xl font-bold">Subject performance</h3>
                <span className="text-[10px] font-black text-muted-500 uppercase tracking-widest">Averages (%)</span>
              </div>
              <div className="w-full h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <ReBarChart data={analytics.subjectData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#2a2a2a" />
                    <XAxis 
                      dataKey="name" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#666', fontSize: 10, fontWeight: 700 }} 
                      dy={10}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#666', fontSize: 10, fontWeight: 700 }} 
                      domain={[0, 100]}
                    />
                    <Tooltip 
                      cursor={{ fill: '#1a1a1a' }}
                      contentStyle={{ backgroundColor: '#0f0f0f', border: '1px solid #2a2a2a', borderRadius: '12px' }}
                      itemStyle={{ color: '#00A896', fontWeight: 700 }}
                    />
                    <Bar dataKey="average" radius={[6, 6, 0, 0]} barSize={40}>
                      {analytics.subjectData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.average >= 50 ? '#00A896' : '#ef4444'} />
                      ))}
                    </Bar>
                  </ReBarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* Results Table */}
        <div className="bg-muted-800 border border-muted-700 rounded-[2.5rem] overflow-hidden shadow-2xl">
          {!filters.class || !filters.section ? (
            <div className="p-20 text-center">
              <div className="w-20 h-20 bg-muted-900 rounded-3xl flex items-center justify-center mx-auto mb-6 text-muted-500">
                <Filter size={32} />
              </div>
              <h3 className="font-syne text-xl font-bold text-white mb-2">Initialize Data Feed</h3>
              <p className="text-muted-500 text-sm">Define class and section to begin monitoring academic output.</p>
            </div>
          ) : loading ? (
            <div className="p-20 text-center animate-pulse">
              <p className="text-muted-500 font-black uppercase tracking-[0.2em]">Aggregating Intelligence...</p>
            </div>
          ) : results.length === 0 ? (
            <div className="p-20 text-center">
              <h3 className="font-syne text-xl font-bold text-white mb-2">Void State Detected</h3>
              <p className="text-muted-500 text-sm">No performance data exists for the selected parameters.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-muted-900/50">
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest">Student</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest">Subject</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-center">Marks</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-center">Grade</th>
                    <th className="px-8 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-right">Control</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-muted-700/50">
                  {results.map(res => (
                    <tr key={res._id} className="hover:bg-muted-700/30 transition-colors group">
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl bg-primary-500/10 flex items-center justify-center text-primary-400 font-bold uppercase">
                            {res.studentId?.name?.charAt(0)}
                          </div>
                          <div>
                            <p className="text-sm font-bold text-white">{res.studentId?.name}</p>
                            <p className="text-[10px] text-muted-500 font-medium">{res.studentId?.rollNumber}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <span className="text-sm font-medium text-muted-300">{res.subject}</span>
                        <p className="text-[9px] text-muted-500 uppercase tracking-widest font-black mt-1">{res.examType}</p>
                      </td>
                      <td className="px-8 py-6 text-center">
                        <div className="inline-flex flex-col items-center">
                          <span className="text-sm font-bold text-white">{res.obtainedMarks} / {res.totalMarks}</span>
                          <div className="w-24 h-1.5 bg-muted-900 rounded-full mt-2 overflow-hidden">
                            <div 
                              className="h-full bg-primary-500 transition-all duration-1000" 
                              style={{ width: `${(res.obtainedMarks / res.totalMarks) * 100}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6 text-center">
                        <span className={`px-4 py-1 rounded-lg text-[10px] font-black border ${getGradeColor(res.grade)}`}>
                          {res.grade}
                        </span>
                      </td>
                      <td className="px-8 py-6 text-right">
                        <button 
                          onClick={() => handleDelete(res._id)}
                          className="p-2.5 bg-muted-900 text-red-400/50 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 size={14} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </main>
    </div>
  )
}

export default AdminResults
