import { useState, useEffect } from 'react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import StatCard from '../../components/ui/StatCard'
import { Card, CardHeader, CardContent } from '../../components/ui/Card'
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '../../components/ui/Table'
import Badge from '../../components/ui/Badge'
import Button from '../../components/ui/Button'
import { getStudentsApi } from '../../api/studentApi'
import { getFeeSummaryApi, getFeesApi } from '../../api/feeApi'
import { getAttendanceApi } from '../../api/attendanceApi'
import { useAuth } from '../../context/AuthContext'
import {
  Users,
  Wallet,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Calendar,
  ChevronRight,
  GraduationCap,
  Bell,
} from 'lucide-react'

const AdminDashboard = () => {
  const { user } = useAuth()
  const [stats, setStats] = useState({
    totalStudents: null,
    feeSummary: null,
    attendance: { records: [] },
    recentFees: [],
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const today = new Date().toISOString().slice(0, 10)
        const [studentsRes, feeSummaryRes, attendanceRes, recentFeesRes] = await Promise.all([
          getStudentsApi(),
          getFeeSummaryApi(),
          getAttendanceApi({ date: today }),
          getFeesApi({ status: 'paid' }),
        ])

        setStats({
          totalStudents: studentsRes?.data?.data?.students?.length ?? 0,
          feeSummary: feeSummaryRes?.data?.data ?? null,
          attendance: { records: attendanceRes?.data?.data?.records ?? [] },
          recentFees: (recentFeesRes?.data?.data?.fees ?? []).slice(0, 5),
        })
      } catch (err) {
        console.error('Dashboard fetch error:', err)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  // Attendance Calculations
  const attendanceRecords = stats.attendance?.records || []
  const present = attendanceRecords.filter(r => r.status === 'present').length
  const attendanceRate = attendanceRecords.length > 0 ? Math.round((present / attendanceRecords.length) * 100) : 0

  return (
    <DashboardLayout>
      {/* Welcome Header */}
      <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="font-syne text-4xl font-bold text-white tracking-tight mb-2">
            Welcome, {user?.name?.split(' ')[0]}!
          </h1>
          <p className="text-muted-500 font-medium flex items-center gap-2 uppercase tracking-widest text-[10px]">
            <Calendar size={14} className="text-primary-500" />
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })} — System Overview
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="secondary" size="sm">Export Report</Button>
          <Button size="sm">New Admission</Button>
        </div>
      </div>

      {/* Hero Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6 mb-10">
        <StatCard
          label="Total Students"
          value={stats.totalStudents}
          icon={GraduationCap}
          trend="up"
          trendValue={12}
          color="blue"
          loading={loading}
        />
        <StatCard
          label="Revenue (PKR)"
          value={(stats.feeSummary?.totalCollected || 0).toLocaleString()}
          icon={Wallet}
          trend="up"
          trendValue={8}
          color="primary"
          loading={loading}
        />
        <StatCard
          label="Attendance Today"
          value={`${attendanceRate}%`}
          icon={CheckCircle2}
          trend="down"
          trendValue={2}
          color="purple"
          loading={loading}
        />
        <StatCard
          label="Pending Invoices"
          value={stats.feeSummary?.unpaid ?? 0}
          icon={AlertCircle}
          color="amber"
          loading={loading}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Transactions */}
        <div className="lg:col-span-2 space-y-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <h2 className="font-syne text-xl font-bold text-white">Recent Transactions</h2>
              <Button variant="ghost" size="sm" className="text-primary-500">View All</Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Month</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stats.recentFees.map((fee) => (
                    <TableRow key={fee._id}>
                      <TableCell className="font-bold">{fee.studentId?.name}</TableCell>
                      <TableCell className="uppercase">{fee.month}</TableCell>
                      <TableCell className="text-primary-400 font-black">PKR {fee.amount?.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge variant="success">Paid</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                  {stats.recentFees.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-10 text-muted-500">No recent payments found</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        {/* Quick Tools & Insights */}
        <div className="space-y-8">
          <Card className="bg-gradient-to-br from-primary-600 to-primary-900 border-none">
            <h3 className="text-white font-syne text-xl font-bold mb-2">Pro Insights</h3>
            <p className="text-primary-100 text-sm mb-6 leading-relaxed">
              Your school's attendance rate is up 4% compared to last month. Great job keeping students engaged!
            </p>
            <Button variant="secondary" className="w-full bg-white text-primary-900 border-none hover:bg-white/90">
              Generate Analysis
            </Button>
          </Card>

          <Card>
            <CardHeader>
              <h2 className="font-syne text-lg font-bold text-white">Quick Actions</h2>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { label: 'Register New Staff', icon: Users, href: '/admin/users' },
                { label: 'Push Notifications', icon: Bell, href: '/admin/notifications' },
                { label: 'Financial Reports', icon: TrendingUp, href: '/admin/fees' },
              ].map((tool) => (
                <a
                  key={tool.label}
                  href={tool.href}
                  className="flex items-center justify-between p-4 rounded-2xl bg-surface-base border border-surface-border hover:border-primary-500/50 hover:bg-primary-500/5 transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <tool.icon size={18} className="text-muted-400 group-hover:text-primary-400" />
                    <span className="text-sm font-bold text-muted-300 group-hover:text-white">{tool.label}</span>
                  </div>
                  <ChevronRight size={16} className="text-muted-500 group-hover:translate-x-1 transition-transform" />
                </a>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}

export default AdminDashboard
