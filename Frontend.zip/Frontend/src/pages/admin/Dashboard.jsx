import { useState, useEffect } from 'react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import StatCard from '../../components/ui/StatCard'
import { Card, CardHeader, CardContent } from '../../components/ui/Card'
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '../../components/ui/Table'
import Badge from '../../components/ui/Badge'
import Button from '../../components/ui/Button'
import { getFeesApi, getFeeSummaryApi } from '../../api/feeApi'
import { getAttendanceApi } from '../../api/attendanceApi'
import { getResultStatsApi } from '../../api/resultApi'
import { getComplaintStatsApi, getAllComplaintsApi } from '../../api/complaintApi'
import { getStudentsApi } from '../../api/studentApi'
import { getSchoolRiskSummaryApi } from '../../api/aiApi'
import { useAuth } from '../../context/AuthContext'
import {
  Users,
  Wallet,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Calendar,
  ChevronRight,
  GraduationCap,
  Bell,
  ArrowRight,
  Sparkles,
} from 'lucide-react'

const AdminDashboard = () => {
  const { user } = useAuth()
  const [stats, setStats] = useState({
    totalStudents: null,
    feeSummary: null,
    attendance: { records: [] },
    recentFees: [],
    resultStats: { resultsThisMonth: 0, upcomingExams: 0 },
    complaintStats: null,
    highPriorityCount: 0,
    aiStats: { highRiskCount: 0, mediumRiskCount: 0, lowRiskCount: 0 }
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const today = new Date().toISOString().slice(0, 10)
        const [
          studentsRes, 
          feeSummaryRes, 
          attendanceRes, 
          recentFeesRes, 
          resultStatsRes, 
          complaintStatsRes, 
          highPriorityRes,
          aiSummaryRes
        ] = await Promise.all([
          getStudentsApi(),
          getFeeSummaryApi(),
          getAttendanceApi({ date: today }),
          getFeesApi({ status: 'paid' }),
          getResultStatsApi(),
          getComplaintStatsApi(),
          getAllComplaintsApi({ status: 'open', priority: 'high' }),
          getSchoolRiskSummaryApi()
        ])

        setStats({
          totalStudents: studentsRes?.data?.data?.students?.length ?? 0,
          feeSummary: feeSummaryRes?.data?.data ?? null,
          attendance: { records: attendanceRes?.data?.data?.records ?? [] },
          recentFees: (recentFeesRes?.data?.data?.fees ?? []).slice(0, 5),
          resultStats: resultStatsRes?.data?.data ?? { resultsThisMonth: 0, upcomingExams: 0 },
          complaintStats: complaintStatsRes?.data?.data ?? null,
          highPriorityCount: highPriorityRes?.data?.complaints?.length ?? 0,
          aiStats: aiSummaryRes?.data?.data ?? { highRiskCount: 0, mediumRiskCount: 0, lowRiskCount: 0 }
        })
      } catch (err) {
        console.error('Dashboard fetch error:', err)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  // Attendance Calculations
  const attendanceRecords = stats.attendance?.records || []
  const present = attendanceRecords.filter(r => r.status === 'present').length
  const attendanceRate = attendanceRecords.length > 0 ? Math.round((present / attendanceRecords.length) * 100) : 0

  return (
    <DashboardLayout>
      {/* High Risk AI Alert */}
      {stats.aiStats?.highRiskCount > 0 && (
        <a 
          href="/admin/ai-analyzer" 
          className="flex items-center justify-between p-4 mb-4 bg-red-600/10 border border-red-600/20 rounded-2xl group hover:bg-red-600/20 transition-all"
        >
          <div className="flex items-center gap-3 text-red-500">
            <span className="text-lg">🔴</span>
            <span className="text-sm font-bold uppercase tracking-widest">{stats.aiStats.highRiskCount} students are at HIGH RISK — immediate attention needed</span>
          </div>
          <Button variant="secondary" size="sm" className="bg-red-600 text-white border-none hover:bg-red-700">View AI Analyzer</Button>
        </a>
      )}

      {/* High Priority Alert */}
      {stats.highPriorityCount > 0 && (
        <a 
          href="/admin/complaints?priority=high" 
          className="flex items-center justify-between p-4 mb-8 bg-red-500/10 border border-red-500/20 rounded-2xl group hover:bg-red-500/20 transition-all animate-pulse"
        >
          <div className="flex items-center gap-3 text-red-400">
            <AlertCircle size={20} />
            <span className="text-sm font-bold uppercase tracking-widest">Action Required: {stats.highPriorityCount} High Priority Complaints Pending</span>
          </div>
          <ArrowRight size={18} className="text-red-400 group-hover:translate-x-1 transition-transform" />
        </a>
      )}

      {/* Welcome Header */}
      <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="font-syne text-4xl font-bold text-white tracking-tight mb-2">
            Welcome, {user?.name?.split(' ')[0]}!
          </h1>
          <p className="text-muted-500 font-medium flex items-center gap-2 uppercase tracking-widest text-[10px]">
            <Calendar size={14} className="text-primary-500" />
            {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })} — System Overview
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="secondary" size="sm">Export Report</Button>
          <Button size="sm">New Admission</Button>
        </div>
      </div>

      {/* Hero Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6 mb-10">
        <StatCard
          label="Total Students"
          value={stats.totalStudents}
          icon={GraduationCap}
          trend="up"
          trendValue={12}
          color="blue"
          loading={loading}
        />
        <StatCard
          label="Revenue (PKR)"
          value={(stats.feeSummary?.totalCollected || 0).toLocaleString()}
          icon={Wallet}
          trend="up"
          trendValue={8}
          color="primary"
          loading={loading}
        />
        <StatCard
          label="Attendance Today"
          value={`${attendanceRate}%`}
          icon={CheckCircle2}
          trend="down"
          trendValue={2}
          color="purple"
          loading={loading}
        />
        <StatCard
          label="Pending Invoices"
          value={stats.feeSummary?.unpaid ?? 0}
          icon={AlertCircle}
          color="amber"
          loading={loading}
        />
      </div>

      {/* Result Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
        <div className="bg-surface-elevated border border-surface-border rounded-[2.5rem] p-8 flex items-center justify-between group hover:border-primary-500/30 transition-all duration-500">
          <div>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.2em] mb-2">Academic Output</p>
            <h3 className="text-3xl font-bold text-white mb-1">{stats.resultStats.resultsThisMonth}</h3>
            <p className="text-xs text-muted-400">Results recorded this month</p>
          </div>
          <div className="w-14 h-14 bg-primary-500/10 rounded-2xl flex items-center justify-center text-primary-400 group-hover:scale-110 transition-transform">
            <CheckCircle2 size={24} />
          </div>
        </div>
        <div className="bg-surface-elevated border border-surface-border rounded-[2.5rem] p-8 flex items-center justify-between group hover:border-purple-500/30 transition-all duration-500">
          <div>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.2em] mb-2">Exam Schedule</p>
            <h3 className="text-3xl font-bold text-white mb-1">{stats.resultStats.upcomingExams}</h3>
            <p className="text-xs text-muted-400">Upcoming assessment nodes</p>
          </div>
          <div className="w-14 h-14 bg-purple-500/10 rounded-2xl flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform">
            <Calendar size={24} />
          </div>
        </div>
      </div>

      {/* AI Insights Section */}
      <div className="mb-10">
        <div className="flex items-center justify-between mb-6 px-4">
          <h2 className="font-syne text-xl font-bold text-white flex items-center gap-2">
            <Sparkles size={20} className="text-primary-400" />
            AI Performance Insights
          </h2>
          <a href="/admin/ai-analyzer" className="text-[10px] font-black uppercase tracking-[0.2em] text-primary-400 hover:text-primary-300 transition-colors flex items-center gap-2">
            AI HUB <ArrowRight size={14} />
          </a>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-surface-elevated border border-surface-border p-6 rounded-[2rem] flex items-center gap-4 hover:border-red-500/30 transition-all">
            <div className="w-12 h-12 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-500 font-bold text-xl font-syne">
              {stats.aiStats?.highRiskCount || 0}
            </div>
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-muted-500">High Risk</p>
              <p className="text-xs text-muted-400">Needs immediate attention</p>
            </div>
          </div>
          <div className="bg-surface-elevated border border-surface-border p-6 rounded-[2rem] flex items-center gap-4 hover:border-yellow-500/30 transition-all">
            <div className="w-12 h-12 bg-yellow-500/10 rounded-2xl flex items-center justify-center text-yellow-500 font-bold text-xl font-syne">
              {stats.aiStats?.mediumRiskCount || 0}
            </div>
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-muted-500">Medium Risk</p>
              <p className="text-xs text-muted-400">Needs improvement</p>
            </div>
          </div>
          <div className="bg-surface-elevated border border-surface-border p-6 rounded-[2rem] flex items-center gap-4 hover:border-green-500/30 transition-all">
            <div className="w-12 h-12 bg-green-500/10 rounded-2xl flex items-center justify-center text-green-500 font-bold text-xl font-syne">
              {stats.aiStats?.lowRiskCount || 0}
            </div>
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-muted-500">Low Risk</p>
              <p className="text-xs text-muted-400">Performing well</p>
            </div>
          </div>
        </div>
      </div>

      {/* Complaint Overview */}
      <div className="mb-10">
        <div className="flex items-center justify-between mb-6 px-4">
          <h2 className="font-syne text-xl font-bold text-white">Institutional Feedback</h2>
          <a href="/admin/complaints" className="text-[10px] font-black uppercase tracking-[0.2em] text-primary-400 hover:text-primary-300 transition-colors flex items-center gap-2">
            Audit Hub <ArrowRight size={14} />
          </a>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-surface-base border border-surface-border p-6 rounded-[2rem] text-center">
            <p className="text-[10px] font-black uppercase tracking-widest text-muted-500 mb-2">Total</p>
            <h4 className="text-2xl font-bold text-white">{stats.complaintStats?.byStatus?.reduce((acc, curr) => acc + curr.count, 0) || 0}</h4>
          </div>
          <div className="bg-surface-base border border-surface-border p-6 rounded-[2rem] text-center">
            <p className="text-[10px] font-black uppercase tracking-widest text-red-400 mb-2">Open</p>
            <h4 className="text-2xl font-bold text-white">{stats.complaintStats?.byStatus?.find(s => s._id === 'open')?.count || 0}</h4>
          </div>
          <div className="bg-surface-base border border-surface-border p-6 rounded-[2rem] text-center">
            <p className="text-[10px] font-black uppercase tracking-widest text-yellow-400 mb-2">In Progress</p>
            <h4 className="text-2xl font-bold text-white">{stats.complaintStats?.byStatus?.find(s => s._id === 'in_progress')?.count || 0}</h4>
          </div>
          <div className="bg-surface-base border border-surface-border p-6 rounded-[2rem] text-center">
            <p className="text-[10px] font-black uppercase tracking-widest text-green-400 mb-2">Resolved</p>
            <h4 className="text-2xl font-bold text-white">{stats.complaintStats?.byStatus?.find(s => s._id === 'resolved')?.count || 0}</h4>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Transactions */}
        <div className="lg:col-span-2 space-y-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <h2 className="font-syne text-xl font-bold text-white">Recent Transactions</h2>
              <Button variant="ghost" size="sm" className="text-primary-500">View All</Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Month</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stats.recentFees.map((fee) => (
                    <TableRow key={fee._id}>
                      <TableCell className="font-bold">{fee.studentId?.name}</TableCell>
                      <TableCell className="uppercase">{fee.month}</TableCell>
                      <TableCell className="text-primary-400 font-black">PKR {fee.amount?.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge variant="success">Paid</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                  {stats.recentFees.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-10 text-muted-500">No recent payments found</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        {/* Quick Tools & Insights */}
        <div className="space-y-8">
          <Card className="bg-gradient-to-br from-primary-600 to-primary-900 border-none">
            <h3 className="text-white font-syne text-xl font-bold mb-2">Pro Insights</h3>
            <p className="text-primary-100 text-sm mb-6 leading-relaxed">
              Your school's attendance rate is up 4% compared to last month. Great job keeping students engaged!
            </p>
            <Button variant="secondary" className="w-full bg-white text-primary-900 border-none hover:bg-white/90">
              Generate Analysis
            </Button>
          </Card>

          <Card>
            <CardHeader>
              <h2 className="font-syne text-lg font-bold text-white">Quick Actions</h2>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { label: 'Register New Staff', icon: Users, href: '/admin/users' },
                { label: 'Push Notifications', icon: Bell, href: '/admin/notifications' },
                { label: 'Financial Reports', icon: TrendingUp, href: '/admin/fees' },
              ].map((tool) => (
                <a
                  key={tool.label}
                  href={tool.href}
                  className="flex items-center justify-between p-4 rounded-2xl bg-surface-base border border-surface-border hover:border-primary-500/50 hover:bg-primary-500/5 transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <tool.icon size={18} className="text-muted-400 group-hover:text-primary-400" />
                    <span className="text-sm font-bold text-muted-300 group-hover:text-white">{tool.label}</span>
                  </div>
                  <ChevronRight size={16} className="text-muted-500 group-hover:translate-x-1 transition-transform" />
                </a>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}

export default AdminDashboard
