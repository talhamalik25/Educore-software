import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getStudentsApi } from '../../api/studentApi'
import { getFeeSummaryApi, getFeesApi } from '../../api/feeApi'
import { getAttendanceApi } from '../../api/attendanceApi'
import { useAuth } from '../../context/AuthContext'

const StatCard = ({ label, value, icon, color }) => (
  <div className="bg-muted-800 border border-muted-700 rounded-3xl p-8 shadow-xl hover:shadow-2xl hover:border-muted-600 transition-all duration-300 group">
    <div className="flex items-center justify-between mb-5">
      <div className={`p-4 rounded-2xl ${color} bg-opacity-10 shadow-inner group-hover:scale-110 transition-transform duration-300`}>
        <span className="text-3xl leading-none">{icon}</span>
      </div>
      <span className={`text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-widest ${color} bg-opacity-10 border border-current border-opacity-10`}>Live</span>
    </div>
    <p className="text-4xl font-syne font-bold text-white tracking-tighter mb-2">{value ?? '—'}</p>
    <p className="text-muted-500 text-xs font-bold uppercase tracking-widest">{label}</p>
  </div>
)

const AdminDashboard = () => {
  const { user } = useAuth()
  const [stats, setStats] = useState({
    totalStudents: null,
    feeSummary: null,
    attendance: { records: [] },
    recentFees: [],
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const today = new Date().toISOString().slice(0, 10)
        const [studentsRes, feeSummaryRes, attendanceRes, recentFeesRes] = await Promise.all([
          getStudentsApi(),
          getFeeSummaryApi(),
          getAttendanceApi({ date: today }),
          getFeesApi({ status: 'paid' }),
        ])

        setStats({
          totalStudents: studentsRes?.data?.students?.length ?? 0,
          feeSummary: feeSummaryRes?.data ?? null,
          attendance: { records: attendanceRes?.data?.records ?? [] },
          recentFees: (recentFeesRes?.data?.fees ?? []).slice(0, 5),
        })
      } catch (err) {
        console.error('Dashboard fetch error:', err)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const currentMonth = new Date().toLocaleString('default', { month: 'long', year: 'numeric' })
  const todayDate = new Date().toLocaleDateString('default', { day: 'numeric', month: 'long', year: 'numeric' })

  // Attendance Calculations
  const attendanceRecords = stats.attendance?.records || []
  const present = attendanceRecords.filter(r => r.status === 'present').length
  const absent = attendanceRecords.filter(r => r.status === 'absent').length
  const late = attendanceRecords.filter(r => r.status === 'late').length
  const totalAttendance = attendanceRecords.length
  const attendanceRate = totalAttendance > 0 ? Math.round((present / totalAttendance) * 100) : 0

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />

      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">

        {/* Header (Dark Mode Refined) */}
        <div className="mb-12 animate-fade-in relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary-500/5 blur-[80px] rounded-full pointer-events-none" />
          <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">
            Welcome back, {user?.name?.split(' ')[0]} 👋
          </h1>
          <div className="flex items-center gap-3 mt-3">
             <div className="w-1.5 h-1.5 rounded-full bg-primary-500 shadow-[0_0_10px_rgba(16,185,129,0.5)] animate-pulse" />
             <p className="text-muted-500 text-[11px] font-black uppercase tracking-[0.2em]">{currentMonth} Dashboard Status</p>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-8">
          {loading ? (
            [...Array(5)].map((_, i) => (
              <div key={i} className="bg-muted-800 border border-muted-700 rounded-3xl p-8 h-40 animate-pulse shadow-xl" />
            ))
          ) : (
            <>
              <StatCard
                label="Student Body"
                value={stats.totalStudents}
                icon="🎓"
                color="text-blue-400"
              />
              <StatCard
                label="Total Revenue"
                value={`PKR ${(stats.feeSummary?.totalCollected || 0).toLocaleString()}`}
                icon="💰"
                color="text-primary-400"
              />
              <StatCard
                label="Fees Processed"
                value={stats.feeSummary?.paid ?? 0}
                icon="✅"
                color="text-emerald-400"
              />
              <StatCard
                label="Pending Dues"
                value={stats.feeSummary?.unpaid ?? 0}
                icon="⚠️"
                color="text-rose-400"
              />
              <StatCard
                label="Overdue"
                value={stats.feeSummary?.overdue ?? 0}
                icon="🔴"
                color="text-orange-400"
              />
            </>
          )}
        </div>

        {/* Today's Attendance Section */}
        <div className="mt-16 animate-fade-up">
          <div className="flex items-center gap-4 mb-10">
             <div className="h-[2px] w-8 bg-primary-500 rounded-full" />
             <h2 className="font-syne text-xl font-black text-white uppercase tracking-widest">Today's Attendance</h2>
             <span className="text-muted-500 text-xs font-bold">{todayDate}</span>
          </div>
          
          <div className="bg-muted-800 border border-muted-700 rounded-3xl p-8 shadow-xl">
            {loading ? (
              <div className="h-32 animate-pulse bg-muted-700 rounded-2xl" />
            ) : totalAttendance === 0 ? (
              <p className="text-muted-500 text-sm font-medium italic">No attendance marked yet</p>
            ) : (
              <div className="space-y-8">
                <div className="flex flex-wrap gap-4">
                  <div className="bg-emerald-500/10 border border-emerald-500/20 px-4 py-2 rounded-xl text-emerald-400 text-sm font-bold">
                    Present: {present}
                  </div>
                  <div className="bg-rose-500/10 border border-rose-500/20 px-4 py-2 rounded-xl text-rose-400 text-sm font-bold">
                    Absent: {absent}
                  </div>
                  <div className="bg-amber-500/10 border border-amber-500/20 px-4 py-2 rounded-xl text-amber-400 text-sm font-bold">
                    Late: {late}
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between items-end">
                    <p className="text-muted-400 text-xs font-black uppercase tracking-widest">Attendance Rate</p>
                    <p className="text-2xl font-syne font-bold text-white">{attendanceRate}%</p>
                  </div>
                  <div className="h-3 bg-muted-900 rounded-full overflow-hidden border border-muted-700">
                    <div 
                      className="h-full bg-gradient-to-r from-primary-600 to-primary-400 transition-all duration-1000"
                      style={{ width: `${attendanceRate}%` }}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Recent Fee Payments Section */}
        <div className="mt-16 animate-fade-up">
          <div className="flex items-center gap-4 mb-10">
             <div className="h-[2px] w-8 bg-primary-500 rounded-full" />
             <h2 className="font-syne text-xl font-black text-white uppercase tracking-widest">Recent Payments</h2>
          </div>
          
          <div className="bg-muted-800 border border-muted-700 rounded-3xl overflow-hidden shadow-xl">
            {loading ? (
              <div className="h-64 animate-pulse bg-muted-700" />
            ) : stats.recentFees.length === 0 ? (
              <div className="p-8">
                <p className="text-muted-500 text-sm font-medium italic">No payments recorded yet</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-muted-700 bg-muted-900/50">
                      <th className="px-6 py-4 text-muted-500 text-[10px] font-black uppercase tracking-widest">Student Name</th>
                      <th className="px-6 py-4 text-muted-500 text-[10px] font-black uppercase tracking-widest">Class</th>
                      <th className="px-6 py-4 text-muted-500 text-[10px] font-black uppercase tracking-widest">Amount (PKR)</th>
                      <th className="px-6 py-4 text-muted-500 text-[10px] font-black uppercase tracking-widest">Month</th>
                      <th className="px-6 py-4 text-muted-500 text-[10px] font-black uppercase tracking-widest">Date Paid</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-muted-700">
                    {stats.recentFees.map((fee) => (
                      <tr key={fee._id} className="hover:bg-muted-700/30 transition-colors">
                        <td className="px-6 py-4 font-bold text-sm text-white">{fee.student?.name}</td>
                        <td className="px-6 py-4 text-muted-400 text-sm font-medium">{fee.student?.class}</td>
                        <td className="px-6 py-4 text-primary-400 text-sm font-black tracking-tight">{fee.amount?.toLocaleString()}</td>
                        <td className="px-6 py-4 text-muted-400 text-sm font-medium uppercase tracking-tighter">{fee.month}</td>
                        <td className="px-6 py-4 text-muted-500 text-xs font-bold">
                          {new Date(fee.paidAt).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Quick Actions (Reverted to Dark) */}
        <div className="mt-16 animate-fade-up">
          <div className="flex items-center gap-4 mb-10">
             <div className="h-[2px] w-8 bg-primary-500 rounded-full" />
             <h2 className="font-syne text-xl font-black text-white uppercase tracking-widest">Operator Tools</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-8">
            {[
              { label: 'Enroll Student', icon: '➕', href: '/admin/students', color: 'bg-primary-500/10 text-primary-400 border-primary-500/20' },
              { label: 'Record Fee', icon: '💳', href: '/admin/fees', color: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
              { label: 'Manage Staff', icon: '👤', href: '/admin/users', color: 'bg-purple-500/10 text-purple-400 border-purple-500/20' },
              { label: 'Financials', icon: '📈', href: '/admin/fees', color: 'bg-orange-500/10 text-orange-400 border-orange-500/20' },
            ].map((action) => (
              <a
                key={action.label}
                href={action.href}
                className="group relative bg-muted-800 hover:bg-muted-700 border border-muted-700 rounded-[2rem] p-4 lg:p-8 text-center transition-all duration-300 shadow-xl hover:shadow-primary-900/10 hover:border-muted-600 block active:scale-95"
              >
                <div className={`w-16 h-16 rounded-2xl ${action.color} border mx-auto flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                  {action.icon}
                </div>
                <p className="text-white text-sm font-black uppercase tracking-widest">{action.label}</p>
                <div className="mt-2 opacity-0 group-hover:opacity-100 transition-all transform translate-y-2 group-hover:translate-y-0 duration-300">
                   <span className="text-[10px] text-muted-500 font-bold tracking-widest uppercase">Open Module →</span>
                </div>
              </a>
            ))}
          </div>
        </div>

      </main>
    </div>
  )
}

export default AdminDashboard
