import React, { useState, useEffect } from 'react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import { Card, CardHeader, CardContent } from '../../components/ui/Card'
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '../../components/ui/Table'
import Button from '../../components/ui/Button'
import Badge from '../../components/ui/Badge'
import { 
  Plus, 
  Key, 
  Copy, 
  Check, 
  Shield, 
  Trash2, 
  X, 
  FileCode, 
  Globe,
  AlertTriangle,
  History,
  Info,
  Loader2,
  ExternalLink
} from 'lucide-react'
import { getApiKeys, createApiKey, revokeApiKey } from '../../api/apiKeyApi'
import { cn } from '../../lib/utils'

const PERMISSIONS = [
    { id: 'students:read', label: 'Students (Read)' },
    { id: 'attendance:read', label: 'Attendance (Read)' },
    { id: 'fees:read', label: 'Fees (Read)' },
    { id: 'results:read', label: 'Results (Read)' },
    { id: 'timetable:read', label: 'Timetable (Read)' },
    { id: 'notifications:read', label: 'Notifications (Read)' },
];

const ApiAccess = () => {
    const [keys, setKeys] = useState([])
    const [loading, setLoading] = useState(true)
    const [showGenModal, setShowGenModal] = useState(false)
    const [showRevealModal, setShowRevealModal] = useState(false)
    const [generatedKeyData, setGeneratedKeyData] = useState(null)
    const [hasSavedKey, setHasSavedKey] = useState(false)
    const [copied, setCopied] = useState(false)

    // Form state
    const [form, setForm] = useState({
        name: '',
        permissions: [],
        expiresAt: ''
    })

    const fetchKeys = async () => {
        setLoading(true)
        try {
            const res = await getApiKeys()
            setKeys(res.data?.data || [])
        } catch (err) {
            console.error(err)
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchKeys()
    }, [])

    const handleCreateKey = async () => {
        try {
            const res = await createApiKey(form)
            setGeneratedKeyData(res.data.data)
            setShowGenModal(false)
            setShowRevealModal(true)
            fetchKeys()
        } catch (err) {
            alert(err.response?.data?.message || 'Failed to create key')
        }
    }

    const handleRevoke = async (id) => {
        if (!confirm('Are you sure? This cannot be undone.')) return
        try {
            await revokeApiKey(id)
            fetchKeys()
        } catch (err) {
            console.error(err)
        }
    }

    const copyToClipboard = () => {
        if (!generatedKeyData?.rawKey) return
        navigator.clipboard.writeText(generatedKeyData.rawKey)
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
    }

    return (
        <DashboardLayout title="API Developer Hub">
            <div className="space-y-8">
                {/* Header Section */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h1 className="text-3xl font-syne font-bold text-white tracking-tight">API Access Control</h1>
                        <p className="text-muted-500 font-medium tracking-widest text-[10px] uppercase mt-1">
                            Connect EduCore with your own custom solutions & workflows
                        </p>
                    </div>
                    <Button onClick={() => setShowGenModal(true)} className="gap-2 shadow-glow">
                        <Plus size={18} />
                        Generate Key
                    </Button>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <StatCard 
                        label="Active Keys" 
                        value={keys.filter(k => k.isActive).length} 
                        icon={Shield} 
                        color="bg-emerald-600" 
                    />
                    <StatCard 
                        label="Total Keys" 
                        value={keys.length} 
                        icon={Key} 
                        color="bg-primary-600" 
                    />
                    <StatCard 
                        label="Total API Calls" 
                        value={keys.reduce((acc, k) => acc + (k.requestCount || 0), 0).toLocaleString()} 
                        icon={History} 
                        color="bg-purple-600" 
                    />
                </div>

                {/* Keys Table */}
                <Card>
                    <CardHeader>
                        <h2 className="font-syne text-xl font-bold text-white">Management Dashboard</h2>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Instance Name</TableHead>
                                    <TableHead>Prefix</TableHead>
                                    <TableHead>Permissions</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Requests</TableHead>
                                    <TableHead>Last Sync</TableHead>
                                    <TableHead className="text-right">Administration</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {keys.map((k) => (
                                    <TableRow key={k._id}>
                                        <td className="px-6 py-4">
                                            <p className="font-bold text-white">{k.name}</p>
                                            <p className="text-[10px] text-muted-500">Created: {new Date(k.createdAt).toLocaleDateString()}</p>
                                        </td>
                                        <td className="px-6 py-4">
                                            <code className="bg-surface-base px-2 py-1 rounded text-primary-400 text-xs font-mono">
                                                {k.keyPrefix}....
                                            </code>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="flex flex-wrap gap-1 max-w-[200px]">
                                                {k.permissions.map(p => (
                                                    <span key={p} className="text-[9px] px-1.5 py-0.5 rounded-full bg-surface-base text-muted-400 border border-surface-border">
                                                        {p.split(':')[0]}
                                                    </span>
                                                ))}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="flex items-center gap-2">
                                                <div className={cn("w-2 h-2 rounded-full", k.isActive ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" : "bg-rose-500")} />
                                                <span className={cn("text-xs font-bold", k.isActive ? "text-emerald-500" : "text-rose-500 uppercase tracking-widest")}>
                                                    {k.isActive ? 'Active' : 'Revoked'}
                                                </span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 font-mono text-xs text-white">{k.requestCount || 0}</td>
                                        <td className="px-6 py-4 text-xs text-muted-500">{k.lastUsedAt ? new Date(k.lastUsedAt).toLocaleString() : 'Never'}</td>
                                        <td className="px-6 py-4 text-right">
                                            {k.isActive && (
                                                <Button 
                                                    variant="ghost" 
                                                    size="sm" 
                                                    className="text-rose-500 hover:bg-rose-500/10 h-8"
                                                    onClick={() => handleRevoke(k._id)}
                                                >
                                                    <Trash2 size={16} className="mr-2" />
                                                    Revoke
                                                </Button>
                                            )}
                                        </td>
                                    </TableRow>
                                ))}
                                {loading && (
                                    <TableRow>
                                        <td colSpan={7} className="py-12 text-center">
                                            <Loader2 size={32} className="mx-auto text-primary-500 animate-spin" />
                                        </td>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>

                {/* API Docs Section */}
                <Card className="bg-surface-elevated border-primary-500/10">
                    <CardHeader className="flex flex-row items-center gap-3">
                        <FileCode className="text-primary-400" />
                        <h3 className="font-syne text-xl font-bold text-white">Documentation Quickstart</h3>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-3">
                                <label className="text-[10px] font-black uppercase text-muted-500 tracking-widest">Base Interface URL</label>
                                <div className="bg-surface-base p-4 rounded-2xl border border-surface-border flex items-center justify-between">
                                    <code className="text-primary-400 font-mono text-sm">{window.location.origin}/api/v1</code>
                                    <Globe size={16} className="text-muted-600" />
                                </div>
                            </div>
                            <div className="space-y-3">
                                <label className="text-[10px] font-black uppercase text-muted-500 tracking-widest">Authentication Header</label>
                                <div className="bg-surface-base p-4 rounded-2xl border border-surface-border flex items-center justify-between font-mono">
                                    <span className="text-white text-sm">x-api-key: <span className="text-primary-400">ec_live_your_secret_key</span></span>
                                    <Shield size={16} className="text-muted-600" />
                                </div>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <label className="text-[10px] font-black uppercase text-muted-500 tracking-widest block">Available Endpoints</label>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                                {[
                                    { path: '/students', perm: 'students:read' },
                                    { path: '/attendance', perm: 'attendance:read' },
                                    { path: '/fees', perm: 'fees:read' },
                                    { path: '/results', perm: 'results:read' },
                                    { path: '/timetable', perm: 'timetable:read' },
                                ].map(route => (
                                    <div key={route.path} className="bg-surface-base/50 p-3 rounded-xl border border-surface-border flex items-center justify-between group hover:bg-surface-base transition-colors">
                                        <div className="flex flex-col">
                                            <span className="text-xs font-mono text-white">GET {route.path}</span>
                                            <span className="text-[9px] text-muted-500 uppercase tracking-tighter">{route.perm.split(':')[0]} module access</span>
                                        </div>
                                        <Badge variant="info" className="text-[8px] h-4">{route.perm}</Badge>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Generation Modal */}
            {showGenModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md transition-all">
                    <Card className="w-full max-w-lg animate-in zoom-in-95 duration-200">
                        <CardHeader className="flex flex-row items-center justify-between border-b border-surface-border">
                            <h3 className="text-xl font-bold text-white font-syne">Generate Secure Key</h3>
                            <button onClick={() => setShowGenModal(false)} className="text-muted-500 hover:text-white transition-colors">
                                <X size={20} />
                            </button>
                        </CardHeader>
                        <CardContent className="p-8 space-y-8">
                            <div className="space-y-2">
                                <label className="text-[10px] uppercase font-black text-muted-500 tracking-[0.2em] ml-1">Key Identity Name</label>
                                <input 
                                    placeholder="e.g. Mobile Application Access" 
                                    className="w-full bg-surface-base border border-surface-border rounded-xl p-4 text-sm text-white focus:outline-none focus:ring-4 focus:ring-primary-500/10 focus:border-primary-500 transition-all font-medium"
                                    value={form.name}
                                    onChange={e => setForm({...form, name: e.target.value})}
                                />
                            </div>

                            <div className="space-y-4">
                                <label className="text-[10px] uppercase font-black text-muted-500 tracking-[0.2em] ml-1">Scoped Permissions</label>
                                <div className="grid grid-cols-2 gap-3">
                                    {PERMISSIONS.map(p => (
                                        <label key={p.id} className="flex items-center gap-3 p-3 rounded-xl bg-surface-base border border-surface-border hover:border-primary-500/30 cursor-pointer group transition-all">
                                            <input 
                                                type="checkbox"
                                                checked={form.permissions.includes(p.id)}
                                                onChange={() => setForm(prev => ({
                                                    ...prev,
                                                    permissions: prev.permissions.includes(p.id) 
                                                        ? prev.permissions.filter(id => id !== p.id) 
                                                        : [...prev.permissions, p.id]
                                                }))}
                                                className="w-4 h-4 rounded border-surface-border bg-surface-elevated text-primary-600 focus:ring-primary-500 transition-all"
                                            />
                                            <span className="text-xs font-bold text-muted-400 group-hover:text-white">{p.label}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>

                            <div className="space-y-2">
                                <label className="text-[10px] uppercase font-black text-muted-500 tracking-[0.2em] ml-1">Expiry Handlers (Optional)</label>
                                <input 
                                    type="date"
                                    className="w-full bg-surface-base border border-surface-border rounded-xl p-4 text-sm text-white focus:outline-none focus:ring-4 focus:ring-primary-500/10 focus:border-primary-500 transition-all"
                                    value={form.expiresAt}
                                    onChange={e => setForm({...form, expiresAt: e.target.value})}
                                />
                                <p className="text-[9px] text-muted-500 italic mt-1 ml-1">Leave empty for a permanent production key</p>
                            </div>

                            <Button onClick={handleCreateKey} className="w-full py-4 rounded-xl shadow-glow gap-2" disabled={!form.name || form.permissions.length === 0}>
                                <Key size={18} />
                                Create Secret Key
                            </Button>
                        </CardContent>
                    </Card>
                </div>
            )}

            {/* Reveal Modal */}
            {showRevealModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl transition-all">
                    <Card className="w-full max-w-xl border-primary-500 animate-in fade-in zoom-in-95 duration-300">
                        <CardHeader className="text-center pb-2">
                            <div className="w-16 h-16 bg-primary-600/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-primary-500/20 shadow-glow">
                                <Shield className="text-primary-400" size={32} />
                            </div>
                            <h3 className="text-2xl font-bold text-white font-syne uppercase tracking-tight">Key Generated Successfully</h3>
                        </CardHeader>
                        <CardContent className="p-8 space-y-8">
                            <div className="bg-yellow-500/10 border border-yellow-500/20 p-4 rounded-2xl flex items-start gap-4">
                                <AlertTriangle className="text-yellow-500 shrink-0 mt-0.5" size={20} />
                                <div>
                                    <p className="text-sm font-bold text-yellow-500 uppercase tracking-widest mb-1">Critical Security Warning</p>
                                    <p className="text-xs text-yellow-500/80 leading-relaxed font-bold">
                                        Copy this key now and store it in a secure location (e.g. Password Manager). It will <span className="underline">NEVER</span> be shown again for security reasons.
                                    </p>
                                </div>
                            </div>

                            <div className="space-y-3">
                                <label className="text-[10px] uppercase font-black text-muted-500 tracking-[0.2em] ml-1">Your Production API Key</label>
                                <div className="group relative">
                                    <div className="bg-surface-base p-6 rounded-2xl border-2 border-primary-500/30 font-mono text-primary-400 break-all text-sm leading-relaxed shadow-glow">
                                        {generatedKeyData?.rawKey}
                                    </div>
                                    <button 
                                        onClick={copyToClipboard}
                                        className={cn(
                                            "absolute top-1/2 right-4 -translate-y-1/2 p-3 rounded-xl transition-all flex items-center gap-2 font-bold text-xs uppercase tracking-widest",
                                            copied ? "bg-emerald-600 text-white" : "bg-primary-600 text-white hover:bg-primary-500 shadow-saas"
                                        )}
                                    >
                                        {copied ? <Check size={16} /> : <Copy size={16} />}
                                        {copied ? 'Copied!' : 'Copy'}
                                    </button>
                                </div>
                            </div>

                            <label className="flex items-center gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 cursor-pointer hover:bg-white/10 transition-all select-none group">
                                <input 
                                    type="checkbox"
                                    checked={hasSavedKey}
                                    onChange={() => setHasSavedKey(!hasSavedKey)}
                                    className="w-5 h-5 rounded border-surface-border bg-surface-elevated text-primary-600 focus:ring-primary-500"
                                />
                                <span className={cn("text-xs font-bold transition-colors", hasSavedKey ? "text-white" : "text-muted-500 group-hover:text-muted-300")}>
                                    I have copied the key and stored it in a safe vault
                                </span>
                            </label>

                            <Button 
                                onClick={() => setShowRevealModal(false)} 
                                className="w-full py-4 rounded-xl shadow-glow" 
                                disabled={!hasSavedKey}
                            >
                                Done & Finalize
                            </Button>
                        </CardContent>
                    </Card>
                </div>
            )}
        </DashboardLayout>
    )
}

const StatCard = ({ label, value, icon: Icon, color }) => (
    <div className="bg-surface-elevated border border-surface-border p-6 rounded-3xl group hover:border-primary-500/30 transition-all shadow-saas">
        <div className="flex items-center justify-between mb-2">
            <div className={cn("p-3 rounded-2xl flex items-center justify-center text-white", color)}>
                <Icon size={20} />
            </div>
            <div className="text-right">
                <p className="text-3xl font-syne font-bold text-white tracking-tight">{value}</p>
                <p className="text-[10px] font-black uppercase tracking-widest text-muted-500 mt-1">{label}</p>
            </div>
        </div>
    </div>
)

export default ApiAccess
