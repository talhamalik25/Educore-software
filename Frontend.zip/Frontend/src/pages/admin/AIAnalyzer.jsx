import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { 
  getSchoolRiskSummaryApi, 
  getClassRiskReportApi, 
  analyzeStudentApi, 
  getStudentReportApi 
} from '../../api/aiApi'
import { 
  Brain, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Search, 
  X, 
  TrendingDown, 
  TrendingUp, 
  Lightbulb,
  ChevronRight,
  Loader2
} from 'lucide-react'

const AdminAIAnalyzer = () => {
  const [schoolSummary, setSchoolSummary] = useState(null)
  const [classReport, setClassReport] = useState([])
  const [loadingSummary, setLoadingSummary] = useState(true)
  const [loadingClass, setLoadingClass] = useState(false)
  const [analyzingId, setAnalyzingId] = useState(null)
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [showPanel, setShowPanel] = useState(false)
  const [filters, setFilters] = useState({ class: '', section: '' })

  const fetchSummary = async () => {
    try {
      const res = await getSchoolRiskSummaryApi()
      setSchoolSummary(res.data?.data)
    } catch (err) {
      console.error('Failed to fetch summary:', err)
    } finally {
      setLoadingSummary(false)
    }
  }

  const fetchClassReport = async () => {
    if (!filters.class || !filters.section) return
    setLoadingClass(true)
    try {
      const res = await getClassRiskReportApi(filters.class, filters.section)
      setClassReport(res.data?.data ?? [])
    } catch (err) {
      console.error('Failed to fetch class report:', err)
    } finally {
      setLoadingClass(false)
    }
  }

  const handleAnalyze = async (studentId) => {
    setAnalyzingId(studentId)
    try {
      await analyzeStudentApi(studentId)
      await fetchClassReport()
      fetchSummary()
    } catch (err) {
      alert('Analysis failed')
    } finally {
      setAnalyzingId(null)
    }
  }

  const handleDeepDive = async (student) => {
    setSelectedStudent(student)
    setShowPanel(true)
  }

  useEffect(() => {
    fetchSummary()
  }, [])

  const getRiskBadge = (level) => {
    switch (level) {
      case 'high': return 'bg-red-500/10 text-red-400 border-red-500/20'
      case 'medium': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
      case 'low': return 'bg-green-500/10 text-green-400 border-green-500/20'
      default: return 'bg-muted-700 text-muted-400 border-muted-600'
    }
  }

  const inputClass = "w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-3 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all text-sm"

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white relative overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        {/* Header */}
        <div className="mb-12">
          <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter flex items-center gap-4">
            <Brain className="text-primary-400" size={48} />
            Predictive AI Analyzer
          </h1>
          <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
             <span className="w-1.5 h-1.5 bg-primary-500 rounded-full animate-pulse" />
             Institutional Risk Assessment Node
          </p>
        </div>

        {/* Section 1: School Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-muted-800 border border-red-500/20 p-8 rounded-[2.5rem] shadow-xl relative overflow-hidden group">
             <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/5 blur-[50px] rounded-full -mr-16 -mt-16" />
             <div className="w-12 h-12 bg-red-500/10 rounded-2xl flex items-center justify-center text-red-400 mb-6 group-hover:scale-110 transition-transform">
               <AlertTriangle size={24} />
             </div>
             <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest mb-1">Critical Priority</p>
             <h3 className="text-4xl font-bold font-syne">{schoolSummary?.highRiskCount ?? 0} High Risk</h3>
          </div>

          <div className="bg-muted-800 border border-yellow-500/20 p-8 rounded-[2.5rem] shadow-xl relative overflow-hidden group">
             <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/5 blur-[50px] rounded-full -mr-16 -mt-16" />
             <div className="w-12 h-12 bg-yellow-500/10 rounded-2xl flex items-center justify-center text-yellow-400 mb-6 group-hover:scale-110 transition-transform">
               <Clock size={24} />
             </div>
             <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest mb-1">Standard Monitoring</p>
             <h3 className="text-4xl font-bold font-syne">{schoolSummary?.mediumRiskCount ?? 0} Medium Risk</h3>
          </div>

          <div className="bg-muted-800 border border-green-500/20 p-8 rounded-[2.5rem] shadow-xl relative overflow-hidden group">
             <div className="absolute top-0 right-0 w-32 h-32 bg-green-500/5 blur-[50px] rounded-full -mr-16 -mt-16" />
             <div className="w-12 h-12 bg-green-500/10 rounded-2xl flex items-center justify-center text-green-400 mb-6 group-hover:scale-110 transition-transform">
               <CheckCircle2 size={24} />
             </div>
             <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest mb-1">Optimal Performance</p>
             <h3 className="text-4xl font-bold font-syne">{schoolSummary?.lowRiskCount ?? 0} Low Risk</h3>
          </div>
        </div>

        {/* Section 2: Class Analysis */}
        <div className="bg-muted-800 border border-muted-700 rounded-[2.5rem] p-10 shadow-2xl mb-12">
          <div className="flex flex-col md:flex-row items-end gap-6 mb-10">
            <div className="flex-1">
              <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Academic Class</label>
              <input 
                type="text" 
                placeholder="e.g. 10" 
                className={inputClass}
                value={filters.class}
                onChange={e => setFilters({...filters, class: e.target.value})}
              />
            </div>
            <div className="flex-1">
              <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2 ml-1">Section Node</label>
              <input 
                type="text" 
                placeholder="e.g. A" 
                className={inputClass}
                value={filters.section}
                onChange={e => setFilters({...filters, section: e.target.value})}
              />
            </div>
            <button
              onClick={fetchClassReport}
              disabled={loadingClass || !filters.class || !filters.section}
              className="px-8 py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-widest bg-primary-500 text-white hover:bg-primary-600 transition-all shadow-xl shadow-primary-900/20 disabled:opacity-50"
            >
              {loadingClass ? <Loader2 className="animate-spin mx-auto" size={16} /> : 'Sync Class Report'}
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-muted-700/50">
                  <th className="px-6 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest">Student Identity</th>
                  <th className="px-6 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-center">Risk Vector</th>
                  <th className="px-6 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-center">Avg Score</th>
                  <th className="px-6 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-center">Analysis Node</th>
                  <th className="px-6 py-6 text-[10px] font-black text-muted-500 uppercase tracking-widest text-right">Control</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-muted-700/50">
                {classReport.map(student => (
                  <tr key={student._id} className="hover:bg-muted-700/30 transition-colors group cursor-pointer" onClick={() => handleDeepDive(student)}>
                    <td className="px-6 py-6">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-xl bg-muted-900 flex items-center justify-center text-primary-400 font-bold uppercase">
                          {student.name.charAt(0)}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-white">{student.name}</p>
                          <p className="text-[10px] text-muted-500 font-medium">Roll: {student.rollNumber}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-6 text-center">
                      <span className={`px-4 py-1 rounded-lg text-[10px] font-black border uppercase ${getRiskBadge(student.aiReport?.riskLevel)}`}>
                        {student.aiReport?.riskLevel ?? 'untested'}
                      </span>
                    </td>
                    <td className="px-6 py-6 text-center">
                      <span className="text-sm font-bold text-white">{student.aiReport?.averageGrade ?? '0'}%</span>
                    </td>
                    <td className="px-6 py-6 text-center">
                      <p className="text-[10px] text-muted-500 font-black uppercase tracking-widest">
                        {student.aiReport?.lastAnalyzed ? new Date(student.aiReport.lastAnalyzed).toLocaleDateString() : 'N/A'}
                      </p>
                    </td>
                    <td className="px-6 py-6 text-right" onClick={e => e.stopPropagation()}>
                      <button
                        onClick={() => handleAnalyze(student._id)}
                        disabled={analyzingId === student._id}
                        className="p-2.5 bg-primary-500/10 text-primary-400 hover:bg-primary-500 hover:text-white rounded-xl transition-all disabled:opacity-50"
                      >
                        {analyzingId === student._id ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Side Panel: Student Deep Dive */}
        {showPanel && selectedStudent && (
          <div className="fixed inset-0 z-[100] flex justify-end">
            <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={() => setShowPanel(false)} />
            <div className="relative w-full max-w-xl bg-muted-800 border-l border-muted-700 shadow-2xl h-full overflow-y-auto animate-slide-in-right">
              
              <div className="p-10 border-b border-muted-700/50 flex justify-between items-center bg-muted-800/80 backdrop-blur-xl sticky top-0 z-10">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-primary-500/10 flex items-center justify-center text-primary-400">
                    <Brain size={24} />
                  </div>
                  <div>
                    <h2 className="font-syne text-2xl font-bold text-white">{selectedStudent.name}</h2>
                    <p className="text-[10px] font-black text-muted-500 uppercase tracking-widest">Deep Intelligence Profile</p>
                  </div>
                </div>
                <button onClick={() => setShowPanel(false)} className="p-3 bg-muted-900 rounded-2xl hover:bg-muted-700 text-muted-400">
                  <X size={20} />
                </button>
              </div>

              {!selectedStudent.aiReport ? (
                <div className="p-20 text-center">
                  <Sparkles className="mx-auto mb-6 text-primary-400 animate-pulse" size={48} />
                  <h3 className="font-syne text-xl font-bold text-white mb-4">No Analysis Found</h3>
                  <button 
                    onClick={() => handleAnalyze(selectedStudent._id)}
                    className="px-8 py-3.5 rounded-2xl bg-primary-500 text-white font-black uppercase text-[10px] tracking-widest shadow-xl"
                  >
                    Run Neural Analysis
                  </button>
                </div>
              ) : (
                <div className="p-10 space-y-10">
                  {/* Risk & Performance */}
                  <div className="flex items-center justify-between p-8 bg-muted-900/50 border border-muted-700 rounded-[2.5rem]">
                    <div className="text-center">
                      <p className="text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2">Risk Vector</p>
                      <span className={`px-6 py-2 rounded-xl text-xs font-black uppercase border ${getRiskBadge(selectedStudent.aiReport.riskLevel)}`}>
                        {selectedStudent.aiReport.riskLevel}
                      </span>
                    </div>
                    <div className="w-px h-12 bg-muted-700" />
                    <div className="text-center">
                      <p className="text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2">Sync Grade</p>
                      <h4 className="text-2xl font-bold font-syne text-white">{selectedStudent.aiReport.averageGrade}%</h4>
                    </div>
                    <div className="w-px h-12 bg-muted-700" />
                    <div className="text-center">
                      <p className="text-[10px] font-black text-muted-500 uppercase tracking-widest mb-2">Attendance</p>
                      <h4 className="text-2xl font-bold font-syne text-white">{selectedStudent.aiReport.attendanceScore}%</h4>
                    </div>
                  </div>

                  {/* Skills Matrix */}
                  <div className="grid grid-cols-2 gap-6">
                    <div className="p-6 bg-red-500/5 border border-red-500/10 rounded-3xl">
                      <p className="text-[10px] font-black text-red-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <TrendingDown size={14} /> Weak Vectors
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {selectedStudent.aiReport.weakSubjects?.map((sub, i) => (
                          <span key={i} className="px-3 py-1 bg-red-500/10 text-red-400 text-[10px] font-bold rounded-lg border border-red-500/10 capitalize">
                            {sub}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="p-6 bg-green-500/5 border border-green-500/10 rounded-3xl">
                      <p className="text-[10px] font-black text-green-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <TrendingUp size={14} /> Power Vectors
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {selectedStudent.aiReport.strongSubjects?.map((sub, i) => (
                          <span key={i} className="px-3 py-1 bg-green-500/10 text-green-400 text-[10px] font-bold rounded-lg border border-green-500/10 capitalize">
                            {sub}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* AI Narrative */}
                  <div className="relative">
                    <div className="absolute top-0 left-0 -mt-4 -ml-2 text-primary-500/20">
                      <Sparkles size={64} />
                    </div>
                    <div className="relative p-10 bg-muted-900/80 border border-primary-500/20 rounded-[3rem] shadow-2xl">
                      <h3 className="text-xs font-black uppercase tracking-widest text-primary-400 mb-4 flex items-center gap-2">
                        Intelligence Narrative
                      </h3>
                      <p className="text-muted-300 leading-relaxed italic">
                        "{selectedStudent.aiReport.summary}"
                      </p>
                    </div>
                  </div>

                  {/* Strategy Nodes */}
                  <div className="space-y-6">
                    <h3 className="text-[10px] font-black uppercase tracking-widest text-muted-500 flex items-center gap-2 px-2">
                      <Lightbulb size={14} className="text-yellow-400" /> Improvement Protocol
                    </h3>
                    <div className="space-y-3">
                      {selectedStudent.aiReport.recommendations?.map((rec, i) => (
                        <div key={i} className="flex items-start gap-4 p-5 bg-muted-900/30 border border-muted-700/50 rounded-2xl group hover:border-primary-500/30 transition-all">
                          <span className="w-6 h-6 rounded-lg bg-muted-800 flex items-center justify-center text-[10px] font-black text-primary-400 shrink-0">
                            0{i + 1}
                          </span>
                          <p className="text-sm text-muted-400 group-hover:text-muted-200 transition-colors">{rec}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

      </main>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes slideInRight {
          from { transform: translateX(100%); }
          to { transform: translateX(0); }
        }
        .animate-slide-in-right {
          animation: slideInRight 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
      `}} />
    </div>
  )
}

export default AdminAIAnalyzer
