import { useEffect, useMemo, useRef, useState } from 'react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import { Card, CardHeader, CardContent } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import ReportCard from '../../components/ReportCard'
import { getSchoolDetails, updateSchoolSettings, uploadSchoolLogo } from '../../api/schoolApi'
import { Building2, ImageUp, Loader2, Save, Eye, X, Settings } from 'lucide-react'
import { cn } from '../../lib/utils'

const SchoolSettings = () => {
  const fileInputRef = useRef(null)

  const [school, setSchool] = useState(null)
  const [form, setForm] = useState({
    name: '',
    principalName: '',
    phone: '',
    address: '',
    city: '',
    website: '',
    motto: '',
  })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  const [logoFile, setLogoFile] = useState(null)
  const [logoPreviewUrl, setLogoPreviewUrl] = useState('')
  const [savingLogo, setSavingLogo] = useState(false)

  const [toast, setToast] = useState(null) // { type: 'success' | 'error', message: string }
  const toastTimerRef = useRef(null)

  const [previewOpen, setPreviewOpen] = useState(false)

  const showToast = (type, message) => {
    setToast({ type, message })
    if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current)
    toastTimerRef.current = window.setTimeout(() => setToast(null), 3200)
  }

  useEffect(() => {
    return () => {
      if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current)
      if (logoPreviewUrl) URL.revokeObjectURL(logoPreviewUrl)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const load = async () => {
      setLoading(true)
      try {
        const res = await getSchoolDetails()
        const data = res?.data || res?.school || res?.data?.school || res
        const s = data?.school || data

        setSchool(s)
        setForm({
          name: s?.name || '',
          principalName: s?.principalName || '',
          phone: s?.phone || '',
          address: s?.address || '',
          city: s?.city || '',
          website: s?.website || '',
          motto: s?.motto || '',
        })
      } catch (err) {
        console.error(err)
        showToast('error', 'Failed to load school settings.')
      } finally {
        setLoading(false)
      }
    }
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const initials = useMemo(() => {
    const n = (form.name || school?.name || '').trim()
    if (!n) return 'SC'
    const parts = n.split(/\s+/).filter(Boolean)
    return (parts[0]?.[0] || 'S').toUpperCase() + (parts[1]?.[0] || parts[0]?.[1] || 'C').toUpperCase()
  }, [form.name, school?.name])

  const currentLogoUrl = useMemo(() => {
    return logoPreviewUrl || school?.logoUrl || school?.logo || school?.logoURL || ''
  }, [logoPreviewUrl, school])

  const handlePickLogo = () => fileInputRef.current?.click()

  const handleLogoSelected = (file) => {
    if (!file) return
    if (!file.type?.startsWith('image/')) {
      showToast('error', 'Please select an image file.')
      return
    }
    setLogoFile(file)
    if (logoPreviewUrl) URL.revokeObjectURL(logoPreviewUrl)
    setLogoPreviewUrl(URL.createObjectURL(file))
  }

  const handleSaveLogo = async () => {
    if (!logoFile) return
    setSavingLogo(true)
    try {
      const fd = new FormData()
      fd.append('logo', logoFile)
      const res = await uploadSchoolLogo(fd)

      const updated = res?.data?.school || res?.data || res?.school || res
      setSchool((prev) => ({ ...(prev || {}), ...(updated || {}) }))
      setLogoFile(null)
      showToast('success', 'Logo saved successfully.')
    } catch (err) {
      console.error(err)
      showToast('error', 'Failed to upload logo. Please try again.')
    } finally {
      setSavingLogo(false)
    }
  }

  const handleSaveSettings = async () => {
    setSaving(true)
    try {
      const payload = {
        principalName: form.principalName,
        phone: form.phone,
        address: form.address,
        city: form.city,
        website: form.website,
        motto: form.motto,
      }
      const res = await updateSchoolSettings(payload)
      const updated = res?.data?.school || res?.data || res?.school || res
      setSchool((prev) => ({ ...(prev || {}), ...(updated || {}) }))
      showToast('success', 'School settings saved successfully.')
    } catch (err) {
      console.error(err)
      showToast('error', 'Failed to save settings. Please try again.')
    } finally {
      setSaving(false)
    }
  }

  const previewSchool = useMemo(() => {
    return {
      name: form.name || school?.name || 'Your School',
      city: form.city || school?.city || '',
      motto: form.motto || school?.motto || '',
      principalName: form.principalName || school?.principalName || '',
      logoUrl: currentLogoUrl,
    }
  }, [currentLogoUrl, form, school])

  const previewData = useMemo(() => {
    return {
      student: {
        name: 'Ayaan Khan',
        rollNumber: 'STU-0142',
        class: '8',
        section: 'B',
      },
      results: [
        { subject: 'Mathematics', totalMarks: 100, obtainedMarks: 92, percentage: 92, grade: 'A+' },
        { subject: 'English', totalMarks: 100, obtainedMarks: 84, percentage: 84, grade: 'A' },
        { subject: 'Science', totalMarks: 100, obtainedMarks: 79, percentage: 79, grade: 'B' },
        { subject: 'Social Studies', totalMarks: 100, obtainedMarks: 73, percentage: 73, grade: 'B' },
      ],
      summary: {
        totalMarks: 400,
        totalObtained: 328,
        overallPercentage: 82,
        overallGrade: 'A',
        classPosition: '3rd in Class',
        academicYear: new Date().getFullYear() + '-' + String(new Date().getFullYear() + 1).slice(-2),
      },
      examType: 'final',
    }
  }, [])

  return (
    <DashboardLayout>
      {/* Toast */}
      {toast && (
        <div className="fixed top-6 right-6 z-[120] no-print">
          <div
            className={cn(
              'px-5 py-4 rounded-2xl border shadow-2xl backdrop-blur-xl max-w-sm',
              toast.type === 'success'
                ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300'
                : 'bg-red-500/10 border-red-500/20 text-red-300'
            )}
          >
            <p className="text-xs font-black uppercase tracking-widest mb-1">
              {toast.type === 'success' ? 'Saved' : 'Error'}
            </p>
            <p className="text-sm font-bold">{toast.message}</p>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="mb-10">
        <h1 className="font-syne text-4xl font-bold text-white tracking-tight mb-2 flex items-center gap-3">
          <Settings className="text-primary-400" size={26} />
          School Settings & Branding
        </h1>
        <p className="text-muted-500 font-medium uppercase tracking-widest text-[10px]">
          This information appears on report cards and official documents
        </p>
      </div>

      {loading ? (
        <div className="py-24 flex flex-col items-center justify-center text-muted-500">
          <Loader2 className="animate-spin mb-4" size={48} />
          <p className="font-syne font-bold uppercase tracking-widest">Loading School Profile...</p>
        </div>
      ) : (
        <div className="space-y-10">
          {/* Section 1 — Logo */}
          <Card className="border-primary-500/15 bg-surface-elevated/50 backdrop-blur-xl">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-primary-600/15 border border-primary-500/20 flex items-center justify-center">
                  <ImageUp className="text-primary-400" size={18} />
                </div>
                <div>
                  <h2 className="font-syne text-xl font-bold text-white">School Logo</h2>
                  <p className="text-muted-500 text-xs">Used on report cards and headers</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row md:items-center gap-8">
                <div className="w-[100px] h-[100px] rounded-2xl bg-surface-base border border-surface-border overflow-hidden flex items-center justify-center">
                  {currentLogoUrl ? (
                    <img src={currentLogoUrl} alt="School logo" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary-600/20 to-white/5">
                      <span className="font-syne text-2xl font-black text-primary-300">{initials}</span>
                    </div>
                  )}
                </div>

                <div className="flex-1">
                  <p className="text-sm text-muted-400 mb-4">
                    Upload a square image for best results. PNG with transparent background is recommended.
                  </p>
                  <div className="flex flex-wrap gap-3">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleLogoSelected(e.target.files?.[0])}
                    />
                    <Button variant="secondary" onClick={handlePickLogo} className="gap-2 rounded-2xl bg-white/5 border-white/10 hover:bg-white/10">
                      <ImageUp size={18} />
                      Upload Logo
                    </Button>
                    <Button
                      onClick={handleSaveLogo}
                      disabled={!logoFile || savingLogo}
                      className="gap-2 rounded-2xl"
                    >
                      {savingLogo ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                      Save Logo
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Section 2 — School Information */}
          <Card className="border-primary-500/15 bg-surface-elevated/50 backdrop-blur-xl">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-primary-600/15 border border-primary-500/20 flex items-center justify-center">
                  <Building2 className="text-primary-400" size={18} />
                </div>
                <div>
                  <h2 className="font-syne text-xl font-bold text-white">School Information</h2>
                  <p className="text-muted-500 text-xs">Keep this accurate for official documents</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-muted-500 ml-1">School Name</label>
                  <input
                    value={form.name}
                    disabled
                    className="w-full bg-muted-800/40 border border-muted-700 rounded-2xl px-5 py-3 text-white/70 text-sm cursor-not-allowed"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-muted-500 ml-1">Principal Name</label>
                  <input
                    value={form.principalName}
                    onChange={(e) => setForm((p) => ({ ...p, principalName: e.target.value }))}
                    className="w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-3 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all text-sm"
                    placeholder="e.g. Dr. Sana Malik"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-muted-500 ml-1">Phone</label>
                  <input
                    value={form.phone}
                    onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))}
                    className="w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-3 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all text-sm"
                    placeholder="+92 300 1234567"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-muted-500 ml-1">City</label>
                  <input
                    value={form.city}
                    onChange={(e) => setForm((p) => ({ ...p, city: e.target.value }))}
                    className="w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-3 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all text-sm"
                    placeholder="Karachi"
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-muted-500 ml-1">Address</label>
                  <textarea
                    value={form.address}
                    onChange={(e) => setForm((p) => ({ ...p, address: e.target.value }))}
                    className="w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-3 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all text-sm min-h-[110px]"
                    placeholder="Street, area, building, etc."
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-muted-500 ml-1">Website (optional)</label>
                  <input
                    value={form.website}
                    onChange={(e) => setForm((p) => ({ ...p, website: e.target.value }))}
                    className="w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-3 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all text-sm"
                    placeholder="https://yourschool.edu.pk"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-muted-500 ml-1">School Motto (optional)</label>
                  <input
                    value={form.motto}
                    onChange={(e) => setForm((p) => ({ ...p, motto: e.target.value }))}
                    className="w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-3 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all text-sm"
                    placeholder="Excellence in Education"
                  />
                </div>
              </div>

              <div className="mt-8 flex justify-end">
                <Button onClick={handleSaveSettings} disabled={saving} className="gap-2 rounded-2xl">
                  {saving ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Section 3 — Preview */}
          <Card className="border-primary-500/15 bg-surface-elevated/50 backdrop-blur-xl">
            <CardHeader>
              <h2 className="font-syne text-xl font-bold text-white">Report Card Preview</h2>
              <p className="text-muted-500 text-xs">See exactly how branding appears before generating real report cards</p>
            </CardHeader>
            <CardContent>
              <Button variant="secondary" onClick={() => setPreviewOpen(true)} className="gap-2 rounded-2xl bg-white/5 border-white/10 hover:bg-white/10">
                <Eye size={18} />
                Preview Report Card
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Preview Modal */}
      {previewOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 md:p-10 no-print">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" onClick={() => setPreviewOpen(false)} />
          <div className="relative w-full max-w-4xl h-full bg-surface-elevated rounded-[3rem] border border-white/10 shadow-2xl flex flex-col overflow-hidden animate-zoom-in">
            <div className="flex items-center justify-between p-8 border-b border-white/5">
              <div>
                <h3 className="font-syne text-xl font-bold text-white">Preview Report Card</h3>
                <p className="text-[10px] font-black uppercase tracking-widest text-muted-500 mt-1">
                  Branding preview with sample student data
                </p>
              </div>
              <button
                onClick={() => setPreviewOpen(false)}
                className="p-3 bg-white/5 hover:bg-red-500/20 rounded-xl transition-all text-muted-400 hover:text-red-400"
              >
                <X size={20} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-8 bg-muted-950">
              <ReportCard
                student={previewData.student}
                school={previewSchool}
                results={previewData.results}
                summary={previewData.summary}
                examType={previewData.examType}
              />
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  )
}

export default SchoolSettings

