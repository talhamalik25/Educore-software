import { useMemo, useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getFeesApi, createFeeApi, markFeePaidApi } from '../../api/feeApi'
import { getStudentsApi } from '../../api/studentApi'

const AdminFees = () => {
  const [fees, setFees] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')
  const [showCreate, setShowCreate] = useState(false)
  const [students, setStudents] = useState([])
  const [creating, setCreating] = useState(false)
  const [createError, setCreateError] = useState('')
  const [createForm, setCreateForm] = useState({
    studentId: '',
    amount: '',
    month: new Date().toISOString().slice(0, 7),
    dueDate: new Date().toISOString().slice(0, 10),
  })

  const [showPayModal, setShowPayModal] = useState(false)
  const [pendingFeeId, setPendingFeeId] = useState(null)
  const [paymentMethod, setPaymentMethod] = useState('cash')
  const [payLoading, setPayLoading] = useState(false)
  const [payError, setPayError] = useState('')

  const inputClass = useMemo(
    () =>
      'w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-4 text-white placeholder-muted-700 focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 transition-all duration-300',
    [],
  )

  const fetchFees = async () => {
    try {
      const params = filter !== 'all' ? { status: filter } : {}
      const res = await getFeesApi(params)
      setFees(res.data?.fees ?? [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchFees() }, [filter])

  const openCreate = async () => {
    setShowCreate(true)
    setCreateError('')
    try {
      const res = await getStudentsApi()
      const list = res.data?.students ?? []
      setStudents(list)
      if (!createForm.studentId && list.length > 0) {
        setCreateForm((prev) => ({ ...prev, studentId: list[0]._id }))
      }
    } catch (err) {
      setCreateError(err.response?.data?.message || 'Failed to load students.')
    }
  }

  const closeCreate = () => {
    setShowCreate(false)
    setCreateError('')
  }

  const handleCreateChange = (e) => {
    setCreateForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
    setCreateError('')
  }

  const handleCreateFee = async (e) => {
    e.preventDefault()
    setCreating(true)
    setCreateError('')
    try {
      await createFeeApi({
        studentId: createForm.studentId,
        amount: Number(createForm.amount),
        month: createForm.month,
        dueDate: createForm.dueDate,
      })
      closeCreate()
      setCreateForm((prev) => ({
        ...prev,
        amount: '',
        month: new Date().toISOString().slice(0, 7),
        dueDate: new Date().toISOString().slice(0, 10),
      }))
      fetchFees()
    } catch (err) {
      setCreateError(err.response?.data?.message || 'Failed to create fee.')
    } finally {
      setCreating(false)
    }
  }

  const handleMarkPaid = (feeId) => {
    setPendingFeeId(feeId)
    setShowPayModal(true)
    setPaymentMethod('cash')
    setPayError('')
  }

  const closePayModal = () => {
    setShowPayModal(false)
    setPendingFeeId(null)
    setPaymentMethod('cash')
    setPayError('')
  }

  const handleConfirmPayment = async (e) => {
    e.preventDefault()
    setPayLoading(true)
    setPayError('')
    try {
      await markFeePaidApi(pendingFeeId, { paymentMethod })
      closePayModal()
      fetchFees()
    } catch (err) {
      setPayError(err.response?.data?.message || 'Failed to mark paid')
    } finally {
      setPayLoading(false)
    }
  }

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">

        {/* Header (Dark Refined) */}
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8 mb-12 animate-fade-in relative">
          <div className="absolute -top-10 -right-10 w-48 h-48 bg-blue-500/5 blur-[60px] rounded-full pointer-events-none" />
          <div>
            <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter duration-1000">Fee Console</h1>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
               <span className="w-1 h-1 bg-primary-500 rounded-full animate-pulse" />
               {fees.length} Total Billing Nodes Active
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={openCreate}
              className="inline-flex items-center justify-center px-8 py-3.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all duration-300 active:scale-95 cursor-pointer shadow-xl bg-primary-500 text-white hover:bg-primary-600 shadow-primary-900/20"
            >
              <span className="flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" /></svg>
                New Fee
              </span>
            </button>

            <div className="flex flex-nowrap overflow-x-auto pb-2 sm:pb-0 gap-3 bg-muted-800/50 p-2 rounded-[1.5rem] border border-muted-700/50 backdrop-blur-sm shadow-xl no-scrollbar">
            {['all', 'unpaid', 'paid', 'overdue'].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`flex-1 sm:flex-none px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[0.15em] transition-all duration-500 shadow-sm cursor-pointer border ${
                  filter === f
                    ? 'bg-primary-500 text-white border-primary-400 shadow-[0_0_20px_rgba(16,185,129,0.2)]'
                    : 'bg-transparent text-muted-500 border-transparent hover:text-white hover:bg-muted-700'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
          </div>
        </div>

        {/* Create Fee Modal */}
        {showCreate && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={closeCreate}
            />
            <div className="relative w-full max-w-2xl bg-muted-800 border border-muted-700 rounded-[2.5rem] shadow-2xl overflow-hidden animate-fade-up">
              <div className="p-6 md:p-10 border-b border-muted-700/50 flex items-center justify-between gap-6">
                <div>
                  <h2 className="font-syne text-2xl font-bold text-white">Create Fee</h2>
                  <p className="text-muted-500 text-[11px] font-black uppercase tracking-[0.2em] mt-2">Generate a new fee record</p>
                </div>
                <button
                  onClick={closeCreate}
                  className="p-3 rounded-2xl bg-muted-900/40 hover:bg-muted-700 border border-muted-700 text-muted-400 hover:text-white transition-all duration-300 active:scale-95"
                  aria-label="Close"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              </div>

              <form onSubmit={handleCreateFee} className="p-6 md:p-10 grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-7">
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-[0.2em] mb-3 ml-1">Student</label>
                  <select
                    name="studentId"
                    value={createForm.studentId}
                    onChange={handleCreateChange}
                    className={`${inputClass} appearance-none`}
                    required
                  >
                    {students.length === 0 ? (
                      <option value="">No students found</option>
                    ) : (
                      students.map((s) => (
                        <option key={s._id} value={s._id}>
                          {s.name} — {s.class} {s.section} ({s.rollNumber})
                        </option>
                      ))
                    )}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-[0.2em] mb-3 ml-1">Amount (PKR)</label>
                  <input
                    type="number"
                    name="amount"
                    value={createForm.amount}
                    onChange={handleCreateChange}
                    min={0}
                    step={1}
                    placeholder="5000"
                    className={inputClass}
                    required
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-[0.2em] mb-3 ml-1">Month</label>
                  <input
                    type="month"
                    name="month"
                    value={createForm.month}
                    onChange={handleCreateChange}
                    className={inputClass}
                    required
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-[0.2em] mb-3 ml-1">Due Date</label>
                  <input
                    type="date"
                    name="dueDate"
                    value={createForm.dueDate}
                    onChange={handleCreateChange}
                    className={inputClass}
                    required
                  />
                </div>

                {createError && (
                  <div className="md:col-span-2 flex items-center gap-3 text-red-400 text-sm bg-red-500/5 border border-red-500/20 rounded-2xl px-5 py-4">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                    {createError}
                  </div>
                )}

                <div className="md:col-span-2 pt-2 flex flex-col sm:flex-row gap-4">
                  <button
                    type="button"
                    onClick={closeCreate}
                    className="w-full sm:flex-1 bg-muted-900/50 hover:bg-muted-700 border border-muted-700 text-white font-bold py-4 rounded-2xl transition-all duration-300 active:scale-95 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={creating || students.length === 0}
                    className="w-full sm:flex-1 bg-primary-500 hover:bg-primary-600 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-2xl transition-all duration-300 shadow-lg shadow-primary-900/20 cursor-pointer"
                  >
                    {creating ? 'Creating...' : 'Create Fee'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Payment Modal */}
        {showPayModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={closePayModal}
            />
            <div className="relative w-full max-w-lg bg-muted-800 border border-muted-700 rounded-[2.5rem] shadow-2xl overflow-hidden animate-fade-up">
              <div className="p-6 md:p-10 border-b border-muted-700/50 flex items-center justify-between gap-6">
                <div>
                  <h2 className="font-syne text-2xl font-bold text-white">Mark Fee as Paid</h2>
                  <p className="text-muted-500 text-[11px] font-black uppercase tracking-[0.2em] mt-2">Update transaction status</p>
                </div>
                <button
                  onClick={closePayModal}
                  className="p-3 rounded-2xl bg-muted-900/40 hover:bg-muted-700 border border-muted-700 text-muted-400 hover:text-white transition-all duration-300 active:scale-95"
                  aria-label="Close"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              </div>

              <form onSubmit={handleConfirmPayment} className="p-6 md:p-10 flex flex-col gap-6">
                <div>
                  <label className="block text-[10px] font-black text-muted-500 uppercase tracking-[0.2em] mb-3 ml-1">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className={`${inputClass} appearance-none`}
                    required
                  >
                    <option value="cash">Cash</option>
                    <option value="jazzcash">JazzCash</option>
                    <option value="easypaisa">EasyPaisa</option>
                    <option value="bank">Bank Transfer</option>
                  </select>
                </div>

                {payError && (
                  <div className="flex items-center gap-3 text-red-400 text-sm bg-red-500/5 border border-red-500/20 rounded-2xl px-5 py-4">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                    {payError}
                  </div>
                )}

                <div className="pt-2 flex flex-col sm:flex-row gap-4">
                  <button
                    type="button"
                    onClick={closePayModal}
                    className="w-full sm:flex-1 bg-muted-900/50 hover:bg-muted-700 border border-muted-700 text-white font-bold py-4 rounded-2xl transition-all duration-300 active:scale-95 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={payLoading}
                    className="w-full sm:flex-1 bg-primary-500 hover:bg-primary-600 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-2xl transition-all duration-300 shadow-lg shadow-primary-900/20 cursor-pointer"
                  >
                    {payLoading ? 'Processing...' : 'Confirm Payment'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Financial Records (Dark) */}
        <div className="bg-muted-800 border border-muted-700 rounded-[2.5rem] shadow-2xl overflow-hidden animate-fade-up border-t-muted-600/20">
          {loading ? (
            <div className="p-20 text-center text-muted-500 font-black uppercase tracking-[0.3em] animate-pulse">Syncing Blockchain Records...</div>
          ) : fees.length === 0 ? (
            <div className="p-24 text-center bg-muted-900/20">
               <div className="w-24 h-24 bg-muted-700/40 rounded-[2rem] flex items-center justify-center mx-auto mb-8 text-5xl opacity-80 backdrop-blur-sm border border-muted-700 shadow-inner">💳</div>
               <p className="font-syne text-2xl font-bold text-white mb-3">Quiet Market</p>
               <p className="text-muted-500 text-[11px] font-bold uppercase tracking-widest max-w-[200px] mx-auto leading-relaxed">No financial transactions match your current query.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[700px]">
                <thead>
                  <tr className="bg-muted-900/50 border-b border-muted-700">
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-10 py-6">Payer Hierarchy</th>
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-10 py-6">Billing Cycle</th>
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-10 py-6">Quantum</th>
                    <th className="text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-10 py-6">Protocol Status</th>
                    <th className="text-right text-[10px] uppercase tracking-[0.2em] text-muted-500 font-black px-10 py-6">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-muted-700/50">
                  {fees.map((fee) => (
                    <tr key={fee._id} className="hover:bg-muted-700/30 transition-all duration-300 group">
                      <td className="px-10 py-7">
                        <p className="text-white text-sm font-bold tracking-tight mb-1 group-hover:text-primary-400 transition-colors">{fee.studentId?.name}</p>
                        <div className="flex items-center gap-2">
                           <span className="text-[9px] font-black text-muted-500 uppercase tracking-widest bg-muted-900/50 px-2 py-0.5 rounded-lg border border-muted-700/50">C: {fee.studentId?.class}</span>
                           <span className="text-[9px] font-black text-muted-500 uppercase tracking-widest bg-muted-900/50 px-2 py-0.5 rounded-lg border border-muted-700/50">ID: {fee.studentId?.rollNumber}</span>
                        </div>
                      </td>
                      <td className="px-10 py-7 text-muted-400 text-xs font-black uppercase tracking-[0.1em]">{fee.month}</td>
                      <td className="px-10 py-7">
                         <div className="flex items-baseline gap-1">
                            <span className="text-primary-400 text-[10px] font-black uppercase">PKR</span>
                            <span className="text-white text-lg font-black tracking-tighter">{fee.amount?.toLocaleString()}</span>
                         </div>
                      </td>
                      <td className="px-10 py-7">
                        <span className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-[0.2em] border shadow-inner ${
                          fee.status === 'paid'
                            ? 'bg-green-500/10 text-green-400 border-green-500/20 shadow-green-900/10'
                            : fee.status === 'overdue'
                            ? 'bg-red-500/10 text-red-400 border-red-500/20 shadow-red-900/10'
                            : 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20 shadow-yellow-900/10'
                        }`}>
                          <div className={`w-1.5 h-1.5 rounded-full ${
                             fee.status === 'paid' ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.4)]' : fee.status === 'overdue' ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.4)]' : 'bg-yellow-500 animate-pulse shadow-[0_0_8px_rgba(234,179,8,0.4)]'
                          }`} />
                          {fee.status}
                        </span>
                      </td>
                      <td className="px-10 py-7 text-right">
                        {fee.status !== 'paid' ? (
                          <button
                            onClick={() => handleMarkPaid(fee._id)}
                            className="bg-primary-500/5 text-primary-400 hover:bg-primary-500 hover:text-white px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all duration-300 shadow-md active:scale-95 cursor-pointer border border-primary-500/20 hover:border-transparent"
                          >
                            Execute Pmt
                          </button>
                        ) : (
                          <div className="inline-flex items-center gap-2 text-muted-600 bg-muted-900/50 px-4 py-2 rounded-xl border border-muted-700/50">
                             <span className="text-[10px] font-black uppercase tracking-widest">Finalized</span>
                             <svg className="w-4 h-4 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </main>
    </div>
  )
}

export default AdminFees
