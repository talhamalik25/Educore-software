import { useState, useEffect } from 'react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import StatCard from '../../components/ui/StatCard'
import { Card, CardHeader, CardContent } from '../../components/ui/Card'
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '../../components/ui/Table'
import Badge from '../../components/ui/Badge'
import Button from '../../components/ui/Button'
import { 
  Wallet, 
  CreditCard, 
  Search, 
  Filter, 
  X, 
  Plus, 
  CheckCircle2, 
  AlertCircle,
  FileText,
  DollarSign
} from 'lucide-react'
import { getFeesApi, createFeeApi, markFeePaidApi } from '../../api/feeApi'
import { getStudentsApi } from '../../api/studentApi'
import { cn } from '../../lib/utils'

const AdminFees = () => {
  const [fees, setFees] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')
  const [showCreate, setShowCreate] = useState(false)
  const [students, setStudents] = useState([])
  const [creating, setCreating] = useState(false)
  const [createError, setCreateError] = useState('')
  const [createForm, setCreateForm] = useState({
    studentId: '',
    amount: '',
    month: new Date().toISOString().slice(0, 7),
    dueDate: new Date().toISOString().slice(0, 10),
  })

  const [showPayModal, setShowPayModal] = useState(false)
  const [pendingFeeId, setPendingFeeId] = useState(null)
  const [paymentMethod, setPaymentMethod] = useState('cash')
  const [payLoading, setPayLoading] = useState(false)
  const [payError, setPayError] = useState('')

  const fetchFees = async () => {
    try {
      const params = filter !== 'all' ? { status: filter } : {}
      const res = await getFeesApi(params)
      setFees(res.data?.fees ?? [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchFees() }, [filter])

  const openCreate = async () => {
    setShowCreate(true)
    setCreateError('')
    try {
      const res = await getStudentsApi()
      const list = res.data?.students ?? []
      setStudents(list)
      if (!createForm.studentId && list.length > 0) {
        setCreateForm((prev) => ({ ...prev, studentId: list[0]._id }))
      }
    } catch (err) {
      setCreateError(err.response?.data?.message || 'Failed to load students.')
    }
  }

  const closeCreate = () => {
    setShowCreate(false)
    setCreateError('')
  }

  const handleCreateChange = (e) => {
    setCreateForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
    setCreateError('')
  }

  const handleCreateFee = async (e) => {
    e.preventDefault()
    setCreating(true)
    setCreateError('')
    try {
      await createFeeApi({
        studentId: createForm.studentId,
        amount: Number(createForm.amount),
        month: createForm.month,
        dueDate: createForm.dueDate,
      })
      closeCreate()
      fetchFees()
    } catch (err) {
      setCreateError(err.response?.data?.message || 'Failed to create fee.')
    } finally {
      setCreating(false)
    }
  }

  const handleMarkPaid = (feeId) => {
    setPendingFeeId(feeId)
    setShowPayModal(true)
    setPaymentMethod('cash')
    setPayError('')
  }

  const handleConfirmPayment = async (e) => {
    e.preventDefault()
    setPayLoading(true)
    setPayError('')
    try {
      await markFeePaidApi(pendingFeeId, { paymentMethod })
      setShowPayModal(false)
      fetchFees()
    } catch (err) {
      setPayError(err.response?.data?.message || 'Failed to mark paid')
    } finally {
      setPayLoading(false)
    }
  }

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="font-syne text-4xl font-bold text-white tracking-tight mb-2">
            Financial Center
          </h1>
          <p className="text-muted-500 font-medium flex items-center gap-2 uppercase tracking-widest text-[10px]">
            <DollarSign size={14} className="text-primary-500" />
            Billing Operations — Cloud Ledger Active
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={() => {}} className="gap-2">
             <FileText size={18} />
             Reports
          </Button>
          <Button onClick={openCreate} className="gap-2">
            <Plus size={18} />
            Generate Invoice
          </Button>
        </div>
      </div>

      {/* Hero Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6 mb-10">
        <StatCard
          label="Collected Total"
          value="PKR 450K"
          icon={Wallet}
          trend="up"
          trendValue={15}
          color="primary"
          loading={loading}
        />
        <StatCard
          label="Pending Sync"
          value="12 Units"
          icon={AlertCircle}
          color="rose"
          loading={loading}
        />
        <StatCard
          label="Processed"
          value="85%"
          icon={CheckCircle2}
          color="blue"
          loading={loading}
        />
        <Card className="flex flex-col justify-center">
            <p className="text-muted-500 text-[10px] items-center gap-2 font-black uppercase tracking-widest mb-4 flex">
              <Filter size={12} className="text-primary-500" />
              Quick Filters
            </p>
            <div className="flex gap-2 overflow-x-auto no-scrollbar">
               {['all', 'unpaid', 'paid', 'overdue'].map(f => (
                 <button
                   key={f}
                   onClick={() => setFilter(f)}
                   className={cn(
                     "px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all",
                     filter === f 
                       ? "bg-primary-600 border-primary-500 text-white shadow-glow" 
                       : "bg-surface-base border-surface-border text-muted-500 hover:text-white"
                   )}
                 >
                   {f}
                 </button>
               ))}
            </div>
        </Card>
      </div>

      {/* Main Ledger */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
           <h2 className="font-syne text-xl font-bold text-white">Transactional Ledger</h2>
           <Badge variant="info">Verified Nodes</Badge>
        </CardHeader>
        <CardContent>
           <Table>
             <TableHeader>
               <TableRow>
                 <TableHead>System Entry</TableHead>
                 <TableHead>Billing Cycle</TableHead>
                 <TableHead>Amount</TableHead>
                 <TableHead>Protocol Status</TableHead>
                 <TableHead className="text-right">Administration</TableHead>
               </TableRow>
             </TableHeader>
             <TableBody>
               {fees.map((fee) => (
                 <TableRow key={fee._id}>
                   <TableCell>
                      <p className="font-bold text-white leading-tight">{fee.studentId?.name}</p>
                      <p className="text-[10px] text-muted-500 font-bold uppercase mt-1">ID: {fee.studentId?.rollNumber}</p>
                   </TableCell>
                   <TableCell className="font-mono text-[11px] tracking-widest uppercase">{fee.month}</TableCell>
                   <TableCell>
                      <div className="flex items-baseline gap-1">
                         <span className="text-primary-400 text-[10px] font-black uppercase">PKR</span>
                         <span className="text-white text-lg font-black tracking-tighter">{fee.amount?.toLocaleString()}</span>
                      </div>
                   </TableCell>
                   <TableCell>
                      <Badge variant={fee.status === 'paid' ? 'success' : fee.status === 'overdue' ? 'danger' : 'warning'}>
                        {fee.status}
                      </Badge>
                   </TableCell>
                   <TableCell className="text-right">
                      {fee.status !== 'paid' ? (
                        <Button 
                          variant="secondary" 
                          size="sm" 
                          className="h-9 px-4 rounded-xl text-primary-400 border-primary-500/20 hover:bg-primary-500 hover:text-white"
                          onClick={() => handleMarkPaid(fee._id)}
                        >
                          Mark Paid
                        </Button>
                      ) : (
                        <div className="flex items-center justify-end gap-2 text-muted-500">
                           <CheckCircle2 size={16} className="text-primary-500" />
                           <span className="text-[10px] font-black uppercase tracking-widest">Recorded</span>
                        </div>
                      )}
                   </TableCell>
                 </TableRow>
               ))}
               {fees.length === 0 && (
                 <TableRow>
                    <TableCell colSpan={5} className="py-20 text-center text-muted-600">
                       <CreditCard size={48} className="mx-auto mb-4 opacity-10" />
                       <p className="text-xs font-black uppercase tracking-[0.3em]">No transactional data in current segment</p>
                    </TableCell>
                 </TableRow>
               )}
             </TableBody>
           </Table>
        </CardContent>
      </Card>

      {/* Create Fee Modal */}
      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-muted-950/80 backdrop-blur-md">
           <Card className="w-full max-w-2xl animate-fade-up shadow-saas-heavy relative">
              <button onClick={closeCreate} className="absolute top-6 right-6 text-muted-500 hover:text-white transition-colors">
                <X size={24} />
              </button>
              <CardHeader>
                <h2 className="text-3xl font-syne font-bold text-white mb-1">Generate Invoice</h2>
                <p className="text-muted-500 font-medium">Inject new billing node into the school ledger</p>
              </CardHeader>
              <CardContent>
                 <form onSubmit={handleCreateFee} className="space-y-8">
                    <div className="space-y-4">
                       <label className="text-[10px] font-black text-muted-500 uppercase tracking-widest ml-1">Target Student</label>
                       <select
                         name="studentId"
                         value={createForm.studentId}
                         onChange={handleCreateChange}
                         className="w-full bg-surface-base border border-surface-border rounded-2xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                         required
                       >
                         {students.map(s => (
                           <option key={s._id} value={s._id}>{s.name} ({s.rollNumber})</option>
                         ))}
                       </select>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                       <div className="space-y-4">
                          <label className="text-[10px] font-black text-muted-500 uppercase tracking-widest ml-1">Quantum (PKR)</label>
                          <input
                            type="number"
                            name="amount"
                            value={createForm.amount}
                            onChange={handleCreateChange}
                            className="w-full bg-surface-base border border-surface-border rounded-2xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                            required
                          />
                       </div>
                       <div className="space-y-4">
                          <label className="text-[10px] font-black text-muted-500 uppercase tracking-widest ml-1">Cycle Month</label>
                          <input
                            type="month"
                            name="month"
                            value={createForm.month}
                            onChange={handleCreateChange}
                            className="w-full bg-surface-base border border-surface-border rounded-2xl p-4 text-white uppercase focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                            required
                          />
                       </div>
                    </div>
                    <div className="flex gap-4 pt-6">
                       <Button variant="ghost" onClick={closeCreate} className="flex-1">Discard</Button>
                       <Button type="submit" isLoading={creating} className="flex-1">Authorize Sync</Button>
                    </div>
                 </form>
              </CardContent>
           </Card>
        </div>
      )}

      {/* Payment Confirmation Modal */}
      {showPayModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-muted-950/80 backdrop-blur-md">
           <Card className="w-full max-w-md animate-fade-in shadow-saas-heavy">
              <CardHeader>
                <h2 className="text-2xl font-syne font-bold text-white mb-1">Mark as Paid</h2>
                <p className="text-muted-500 font-medium">Confirm the physical reception of funds</p>
              </CardHeader>
              <CardContent className="space-y-8">
                 <div className="space-y-4">
                    <label className="text-[10px] font-black text-muted-500 uppercase tracking-widest ml-1">Reception Method</label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="w-full bg-surface-base border border-surface-border rounded-2xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                    >
                      <option value="cash">Direct Cash</option>
                      <option value="easy_paisa">EasyPaisa Hub</option>
                      <option value="jazz_cash">JazzCash Hub</option>
                      <option value="bank">Bank Wire</option>
                    </select>
                 </div>
                 <div className="flex gap-4">
                    <Button variant="ghost" onClick={() => setShowPayModal(false)} className="flex-1">Abort</Button>
                    <Button onClick={handleConfirmPayment} isLoading={payLoading} className="flex-1">Confirm Sync</Button>
                 </div>
              </CardContent>
           </Card>
        </div>
      )}
    </DashboardLayout>
  )
}

export default AdminFees
