import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import {
  getSuperAdminStatsApi,
  getAllSchoolsApi,
  createSchoolWithAdminApi,
  updateSchoolApi,
  toggleSchoolStatusApi
} from '../../api/superadminApi'

const StatCard = ({ label, value, icon, color }) => (
  <div className="bg-muted-800 border border-muted-700 rounded-3xl p-8 shadow-xl hover:shadow-2xl hover:border-muted-600 transition-all duration-300 group">
    <div className="flex items-center justify-between mb-5">
      <div className={`p-4 rounded-2xl ${color} bg-opacity-10 shadow-inner group-hover:scale-110 transition-transform duration-300`}>
        <span className="text-3xl leading-none">{icon}</span>
      </div>
      <span className={`text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-widest ${color} bg-opacity-10 border border-current border-opacity-10`}>System</span>
    </div>
    <p className="text-4xl font-syne font-bold text-white tracking-tighter mb-2">{value ?? '—'}</p>
    <p className="text-muted-500 text-xs font-bold uppercase tracking-widest">{label}</p>
  </div>
)

const SuperAdminDashboard = () => {
  const [stats, setStats] = useState(null)
  const [schools, setSchools] = useState([])
  const [loading, setLoading] = useState(true)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [selectedSchool, setSelectedSchool] = useState(null)
  
  // Create School Form State
  const [form, setForm] = useState({
    schoolName: '', schoolEmail: '', schoolPhone: '', schoolAddress: '', plan: 'starter',
    adminName: '', adminEmail: '', adminPassword: ''
  })
  const [submitting, setSubmitting] = useState(false)
  const [successData, setSuccessData] = useState(null)

  // Edit Plan State
  const [editPlan, setEditPlan] = useState('starter')

  const fetchData = async () => {
    try {
      setLoading(true)
      const [statsRes, schoolsRes] = await Promise.all([
        getSuperAdminStatsApi(),
        getAllSchoolsApi()
      ])
      setStats(statsRes.data)
      setSchools(schoolsRes.data.schools)
    } catch (err) {
      console.error('Fetch error:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [])

  const handleToggleStatus = async (id) => {
    try {
      await toggleSchoolStatusApi(id)
      fetchData()
    } catch (err) {
      alert(err.response?.data?.message || 'Toggle failed')
    }
  }

  const handleCreateSchool = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      const res = await createSchoolWithAdminApi(form)
      setSuccessData(res.data)
      fetchData()
    } catch (err) {
      alert(err.response?.data?.message || 'Creation failed')
    } finally {
      setSubmitting(false)
    }
  }

  const handleUpdatePlan = async (e) => {
    e.preventDefault()
    try {
      await updateSchoolApi(selectedSchool._id, { plan: editPlan })
      setIsEditModalOpen(false)
      fetchData()
    } catch (err) {
      alert(err.response?.data?.message || 'Update failed')
    }
  }

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white font-syne">
      <Sidebar />

      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        <div className="mb-12 animate-fade-in relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary-500/5 blur-[80px] rounded-full pointer-events-none" />
          <h1 className="text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">
            SuperAdmin Command Port
          </h1>
          <p className="text-muted-500 text-sm mt-3 uppercase tracking-widest font-bold">Network Infrastructure Management</p>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-8 mb-16">
          <StatCard label="Total Schools" value={stats?.totalSchools} icon="🏫" color="text-blue-400" />
          <StatCard label="Active Schools" value={stats?.activeSchools} icon="✅" color="text-primary-400" />
          <StatCard label="Total Students" value={stats?.totalStudents} icon="🎓" color="text-purple-400" />
          <div className="bg-muted-800 border border-muted-700 rounded-3xl p-8 shadow-xl">
             <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest mb-4">Plan Distribution</p>
             <div className="flex flex-col gap-2">
                <div className="flex justify-between items-center text-sm font-bold">
                   <span className="text-blue-400">Starter</span>
                   <span>{stats?.planBreakdown?.starter || 0}</span>
                </div>
                <div className="flex justify-between items-center text-sm font-bold">
                   <span className="text-emerald-400">Growth</span>
                   <span>{stats?.planBreakdown?.growth || 0}</span>
                </div>
                <div className="flex justify-between items-center text-sm font-bold">
                   <span className="text-purple-400">Pro</span>
                   <span>{stats?.planBreakdown?.pro || 0}</span>
                </div>
             </div>
          </div>
        </div>

        {/* Schools Table */}
        <div className="animate-fade-up">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-10">
            <div className="flex items-center gap-4">
               <div className="h-[2px] w-8 bg-primary-500 rounded-full" />
               <h2 className="text-xl font-black text-white uppercase tracking-widest">Registered Schools</h2>
            </div>
            <button 
              onClick={() => {
                setSuccessData(null)
                setIsModalOpen(true)
              }}
              className="bg-primary-500 hover:bg-primary-600 text-white px-6 py-3 rounded-2xl font-bold text-sm transition-all active:scale-95 shadow-lg shadow-primary-900/20"
            >
              + Add New School
            </button>
          </div>

          <div className="bg-muted-800 border border-muted-700 rounded-3xl overflow-hidden shadow-xl">
            {loading ? (
              <div className="h-64 animate-pulse bg-muted-700" />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-muted-700 bg-muted-900/50">
                      <th className="px-6 py-4 text-muted-500 text-[10px] font-black uppercase tracking-widest">School Name</th>
                      <th className="px-6 py-4 text-muted-500 text-[10px] font-black uppercase tracking-widest">Plan</th>
                      <th className="px-6 py-4 text-muted-500 text-[10px] font-black uppercase tracking-widest">Students</th>
                      <th className="px-6 py-4 text-muted-500 text-[10px] font-black uppercase tracking-widest">Status</th>
                      <th className="px-6 py-4 text-muted-500 text-[10px] font-black uppercase tracking-widest">Registered</th>
                      <th className="px-6 py-4 text-muted-500 text-[10px] font-black uppercase tracking-widest text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-muted-700">
                    {schools.map((school) => (
                      <tr key={school._id} className="hover:bg-muted-700/30 transition-colors">
                        <td className="px-6 py-4">
                          <p className="font-bold text-white leading-tight">{school.name}</p>
                          <p className="text-[10px] text-muted-500 font-medium uppercase mt-0.5">{school.email}</p>
                        </td>
                        <td className="px-6 py-4">
                           <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                             school.plan === 'pro' ? 'bg-purple-500/10 text-purple-400 border-purple-500/20' :
                             school.plan === 'growth' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                             'bg-blue-500/10 text-blue-400 border-blue-500/20'
                           }`}>
                             {school.plan}
                           </span>
                        </td>
                        <td className="px-6 py-4 font-bold text-sm text-muted-300">{school.studentCount}</td>
                        <td className="px-6 py-4">
                           <span className={`flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest ${school.isActive ? 'text-primary-400' : 'text-rose-400'}`}>
                             <div className={`w-1.5 h-1.5 rounded-full ${school.isActive ? 'bg-primary-500' : 'bg-rose-500'}`} />
                             {school.isActive ? 'Active' : 'Inactive'}
                           </span>
                        </td>
                        <td className="px-6 py-4 text-muted-500 text-xs font-bold">
                          {new Date(school.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 text-right space-x-2">
                           <button 
                             onClick={() => {
                               setSelectedSchool(school)
                               setEditPlan(school.plan)
                               setIsEditModalOpen(true)
                             }}
                             className="text-muted-400 hover:text-white text-xs font-bold uppercase transition-colors"
                           >
                             Edit Plan
                           </button>
                           <button 
                             onClick={() => handleToggleStatus(school._id)}
                             className={`text-xs font-bold uppercase transition-colors ${school.isActive ? 'text-rose-400 hover:text-rose-300' : 'text-primary-400 hover:text-primary-300'}`}
                           >
                             {school.isActive ? 'Deactivate' : 'Activate'}
                           </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Add School Modal */}
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-muted-950/80 backdrop-blur-sm animate-fade-in">
            <div className="bg-muted-800 border border-muted-700 w-full max-w-2xl rounded-[2.5rem] p-8 md:p-12 shadow-2xl relative animate-scale-up">
              <button onClick={() => setIsModalOpen(false)} className="absolute top-8 right-8 text-muted-500 hover:text-white transition-colors">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>

              <h2 className="text-3xl font-bold mb-2">Configure School</h2>
              <p className="text-muted-500 mb-8 font-medium">Provision new node in the EduCore grid</p>

              {successData ? (
                <div className="space-y-6">
                  <div className="bg-primary-500/10 border border-primary-500/20 p-6 rounded-3xl">
                     <p className="text-primary-400 font-bold mb-4 uppercase tracking-widest text-xs">Provisioning Successful ✅</p>
                     <div className="space-y-3">
                        <div>
                           <p className="text-muted-400 text-[10px] font-bold uppercase tracking-widest">Admin Email</p>
                           <p className="text-white font-mono">{successData.admin.email}</p>
                        </div>
                        <div>
                           <p className="text-muted-400 text-[10px] font-bold uppercase tracking-widest">Temporary Password</p>
                           <p className="text-white font-mono">{successData.tempPassword}</p>
                        </div>
                     </div>
                  </div>
                  <button 
                    onClick={() => setIsModalOpen(false)}
                    className="w-full bg-muted-700 hover:bg-muted-600 text-white font-bold py-4 rounded-2xl transition-all"
                  >
                    Close Window
                  </button>
                </div>
              ) : (
                <form onSubmit={handleCreateSchool} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* School Details */}
                    <div className="space-y-4">
                       <p className="text-muted-400 text-[10px] font-black uppercase tracking-widest mb-2">School Infrastructure</p>
                       <input 
                         placeholder="School Name" 
                         className="w-full bg-muted-900 border border-muted-700 rounded-2xl p-4 text-white focus:outline-none focus:border-primary-500"
                         required value={form.schoolName} onChange={(e) => setForm({...form, schoolName: e.target.value})}
                       />
                       <input 
                         type="email" placeholder="System Email" 
                         className="w-full bg-muted-900 border border-muted-700 rounded-2xl p-4 text-white focus:outline-none focus:border-primary-500"
                         required value={form.schoolEmail} onChange={(e) => setForm({...form, schoolEmail: e.target.value})}
                       />
                       <div className="flex gap-4">
                          <input 
                            placeholder="Phone" 
                            className="w-full bg-muted-900 border border-muted-700 rounded-2xl p-4 text-white focus:outline-none focus:border-primary-500"
                            required value={form.schoolPhone} onChange={(e) => setForm({...form, schoolPhone: e.target.value})}
                          />
                          <select 
                            className="bg-muted-900 border border-muted-700 rounded-2xl p-4 text-white focus:outline-none focus:border-primary-500 uppercase font-black text-xs tracking-widest"
                            value={form.plan} onChange={(e) => setForm({...form, plan: e.target.value})}
                          >
                            <option value="starter">Starter</option>
                            <option value="growth">Growth</option>
                            <option value="pro">Pro</option>
                          </select>
                       </div>
                       <input 
                         placeholder="Physical Address" 
                         className="w-full bg-muted-900 border border-muted-700 rounded-2xl p-4 text-white focus:outline-none focus:border-primary-500"
                         required value={form.schoolAddress} onChange={(e) => setForm({...form, schoolAddress: e.target.value})}
                       />
                    </div>

                    {/* Admin Details */}
                    <div className="space-y-4">
                       <p className="text-muted-400 text-[10px] font-black uppercase tracking-widest mb-2">Primary Node Operator</p>
                       <input 
                         placeholder="Admin Full Name" 
                         className="w-full bg-muted-900 border border-muted-700 rounded-2xl p-4 text-white focus:outline-none focus:border-primary-500"
                         required value={form.adminName} onChange={(e) => setForm({...form, adminName: e.target.value})}
                       />
                       <input 
                         type="email" placeholder="Admin Email" 
                         className="w-full bg-muted-900 border border-muted-700 rounded-2xl p-4 text-white focus:outline-none focus:border-primary-500"
                         required value={form.adminEmail} onChange={(e) => setForm({...form, adminEmail: e.target.value})}
                       />
                       <input 
                         type="password" placeholder="Access Key (Min 6 characters)" 
                         className="w-full bg-muted-900 border border-muted-700 rounded-2xl p-4 text-white focus:outline-none focus:border-primary-500"
                         required minLength={6} value={form.adminPassword} onChange={(e) => setForm({...form, adminPassword: e.target.value})}
                       />
                    </div>
                  </div>

                  <button 
                    type="submit" disabled={submitting}
                    className="w-full bg-primary-500 hover:bg-primary-600 text-white font-bold py-5 rounded-2xl transition-all shadow-lg shadow-primary-900/20 active:scale-95 disabled:opacity-50"
                  >
                    {submitting ? 'Provisioning...' : 'Confirm System Launch'}
                  </button>
                </form>
              )}
            </div>
          </div>
        )}

        {/* Edit Plan Modal */}
        {isEditModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-muted-950/80 backdrop-blur-sm animate-fade-in">
            <div className="bg-muted-800 border border-muted-700 w-full max-w-md rounded-[2.5rem] p-10 shadow-2xl relative animate-scale-up">
               <h3 className="text-2xl font-bold mb-1">Upgrade Protocol</h3>
               <p className="text-muted-500 mb-8 font-medium italic">{selectedSchool?.name}</p>

               <form onSubmit={handleUpdatePlan} className="space-y-8">
                  <div className="bg-muted-900 border border-muted-700 rounded-2xl p-2 flex gap-1">
                    {['starter', 'growth', 'pro'].map(p => (
                      <button
                        key={p} type="button"
                        onClick={() => setEditPlan(p)}
                        className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                          editPlan === p ? 'bg-primary-500 text-white shadow-lg' : 'text-muted-500 hover:text-white'
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>

                  <div className="flex gap-4">
                     <button type="button" onClick={() => setIsEditModalOpen(false)} className="flex-1 text-muted-400 font-bold text-sm">Cancel</button>
                     <button type="submit" className="flex-1 bg-primary-500 text-white font-bold py-4 rounded-2xl shadow-lg">Save Config</button>
                  </div>
               </form>
            </div>
          </div>
        )}

      </main>
    </div>
  )
}

export default SuperAdminDashboard
