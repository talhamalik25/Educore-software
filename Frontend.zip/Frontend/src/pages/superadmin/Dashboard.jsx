import { useState, useEffect } from 'react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import StatCard from '../../components/ui/StatCard'
import { Card, CardHeader, CardContent } from '../../components/ui/Card'
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from '../../components/ui/Table'
import Badge from '../../components/ui/Badge'
import Button from '../../components/ui/Button'
import {
  getSuperAdminStatsApi,
  getAllSchoolsApi,
  createSchoolWithAdminApi,
  updateSchoolApi,
  toggleSchoolStatusApi
} from '../../api/superadminApi'
import { 
  School, 
  PlusCircle, 
  Settings2, 
  Activity, 
  Globe, 
  Layers,
  ChevronRight,
  ShieldAlert,
  X
} from 'lucide-react'
import { cn } from '../../lib/utils'

const SuperAdminDashboard = () => {
  const [stats, setStats] = useState(null)
  const [schools, setSchools] = useState([])
  const [loading, setLoading] = useState(true)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [selectedSchool, setSelectedSchool] = useState(null)
  
  const [form, setForm] = useState({
    schoolName: '', schoolEmail: '', schoolPhone: '', schoolAddress: '', plan: 'starter',
    adminName: '', adminEmail: '', adminPassword: ''
  })
  const [submitting, setSubmitting] = useState(false)
  const [successData, setSuccessData] = useState(null)
  const [editPlan, setEditPlan] = useState('starter')

  const fetchData = async () => {
    try {
      setLoading(true)
      const [statsRes, schoolsRes] = await Promise.all([
        getSuperAdminStatsApi(),
        getAllSchoolsApi()
      ])
      setStats(statsRes.data?.data)
      setSchools(schoolsRes.data?.data?.schools ?? [])
    } catch (err) {
      console.error('Fetch error:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [])

  const handleToggleStatus = async (id) => {
    try {
      await toggleSchoolStatusApi(id)
      fetchData()
    } catch (err) {
      alert(err.response?.data?.message || 'Toggle failed')
    }
  }

  const handleCreateSchool = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      const res = await createSchoolWithAdminApi(form)
      setSuccessData(res.data?.data)
      fetchData()
    } catch (err) {
      alert(err.response?.data?.message || 'Creation failed')
    } finally {
      setSubmitting(false)
    }
  }

  const handleUpdatePlan = async (e) => {
    e.preventDefault()
    try {
      await updateSchoolApi(selectedSchool._id, { plan: editPlan })
      setIsEditModalOpen(false)
      fetchData()
    } catch (err) {
      alert(err.response?.data?.message || 'Update failed')
    }
  }

  return (
    <DashboardLayout>
      {/* Network Header */}
      <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="font-syne text-4xl font-bold text-white tracking-tight mb-2">
            Network Operations
          </h1>
          <p className="text-muted-500 font-medium flex items-center gap-2 uppercase tracking-widest text-[10px]">
            <Globe size={14} className="text-primary-500" />
            Infrastructure Control — Global Node Overview
          </p>
        </div>
        <Button 
          onClick={() => {
            setSuccessData(null)
            setIsModalOpen(true)
          }}
          className="gap-2"
        >
          <PlusCircle size={18} />
          Provision New Node
        </Button>
      </div>

      {/* Grid Status */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6 mb-10">
        <StatCard
          label="Total Nodes"
          value={stats?.totalSchools ?? 0}
          icon={School}
          color="blue"
          loading={loading}
        />
        <StatCard
          label="Active Services"
          value={stats?.activeSchools ?? 0}
          icon={Activity}
          color="primary"
          loading={loading}
        />
        <StatCard
          label="Network Users"
          value={stats?.totalStudents ?? 0}
          icon={Layers}
          color="purple"
          loading={loading}
        />
        <Card className="flex flex-col justify-center">
           <p className="text-muted-500 text-[10px] items-center gap-2 font-black uppercase tracking-widest mb-4 flex">
             <ShieldAlert size={12} className="text-accent-amber" />
             Plan Distribution
           </p>
           <div className="space-y-3">
              {['starter', 'growth', 'enterprise'].map(p => (
                <div key={p} className="flex justify-between items-center text-xs font-bold uppercase tracking-wider">
                   <span className="text-muted-400">{p}</span>
                   <span className="text-white">{stats?.planBreakdown?.[p] || 0}</span>
                </div>
              ))}
           </div>
        </Card>
      </div>

      {/* Node Registry */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
           <h2 className="font-syne text-xl font-bold text-white">Cloud Node Registry</h2>
           <Badge variant="info">Live Feed</Badge>
        </CardHeader>
        <CardContent>
           <Table>
             <TableHeader>
               <TableRow>
                 <TableHead>System Entry</TableHead>
                 <TableHead>Service Plan</TableHead>
                 <TableHead>Infrastructure</TableHead>
                 <TableHead>Global Status</TableHead>
                 <TableHead className="text-right">Administration</TableHead>
               </TableRow>
             </TableHeader>
             <TableBody>
               {schools.map((school) => (
                 <TableRow key={school._id}>
                   <TableCell>
                      <p className="font-bold text-white leading-tight">{school.name}</p>
                      <p className="text-[10px] text-muted-500 font-bold uppercase mt-1">{school.email}</p>
                   </TableCell>
                   <TableCell>
                      <Badge variant={school.plan === 'enterprise' ? 'info' : school.plan === 'growth' ? 'success' : 'default'}>
                        {school.plan}
                      </Badge>
                   </TableCell>
                   <TableCell>
                      <p className="text-white font-black">{school.studentCount}</p>
                      <p className="text-[9px] text-muted-500 uppercase font-bold">Students</p>
                   </TableCell>
                   <TableCell>
                      <div className="flex items-center gap-2">
                         <div className={cn("w-1.5 h-1.5 rounded-full", school.isActive ? "bg-primary-500 shadow-glow" : "bg-accent-rose")} />
                         <span className={cn("text-[10px] font-black uppercase tracking-widest", school.isActive ? "text-primary-400" : "text-accent-rose")}>
                           {school.isActive ? "Online" : "Terminated"}
                         </span>
                      </div>
                   </TableCell>
                   <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-3">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 px-3 rounded-lg text-primary-400 hover:bg-primary-500/10"
                          onClick={() => {
                            setSelectedSchool(school)
                            setEditPlan(school.plan)
                            setIsEditModalOpen(true)
                          }}
                        >
                          <Settings2 size={14} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className={cn("h-8 px-3 rounded-lg", school.isActive ? "text-accent-rose hover:bg-accent-rose/10" : "text-primary-400 hover:bg-primary-500/10")}
                          onClick={() => handleToggleStatus(school._id)}
                        >
                          {school.isActive ? "Kill" : "Resume"}
                        </Button>
                      </div>
                   </TableCell>
                 </TableRow>
               ))}
             </TableBody>
           </Table>
        </CardContent>
      </Card>

      {/* Provisioning Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-muted-950/80 backdrop-blur-md">
          <Card className="w-full max-w-2xl relative shadow-saas-heavy animate-fade-up">
            <button onClick={() => setIsModalOpen(false)} className="absolute top-6 right-6 text-muted-500 hover:text-white transition-colors">
              <X size={24} />
            </button>

            <CardHeader>
              <h2 className="text-3xl font-syne font-bold text-white mb-1">Provision Node</h2>
              <p className="text-muted-500 font-medium">Inject new institution into the global infrastructure</p>
            </CardHeader>

            <CardContent>
              {successData ? (
                <div className="space-y-6">
                   <div className="bg-primary-500/10 border border-primary-500/20 p-8 rounded-3xl">
                      <p className="text-primary-400 font-black uppercase tracking-widest text-[10px] mb-4">Node Active ✅</p>
                      <div className="grid grid-cols-2 gap-8">
                         <div>
                            <p className="text-muted-500 text-[9px] font-black uppercase tracking-widest mb-1">Root Login</p>
                            <p className="text-white font-mono text-sm">{successData.admin.email}</p>
                         </div>
                         <div>
                            <p className="text-muted-500 text-[9px] font-black uppercase tracking-widest mb-1">Security Key</p>
                            <p className="text-white font-mono text-sm uppercase">{successData.tempPassword}</p>
                         </div>
                      </div>
                   </div>
                   <Button onClick={() => setIsModalOpen(false)} className="w-full">Dashboard Return</Button>
                </div>
              ) : (
                <form onSubmit={handleCreateSchool} className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                       <p className="text-muted-600 text-[9px] font-black uppercase tracking-widest">Institution Data</p>
                       <input 
                         placeholder="Institutional Name" 
                         className="w-full bg-surface-base border border-surface-border rounded-2xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                         required value={form.schoolName} onChange={(e) => setForm({...form, schoolName: e.target.value})}
                       />
                       <input 
                         type="email" placeholder="System Contact Email" 
                         className="w-full bg-surface-base border border-surface-border rounded-2xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                         required value={form.schoolEmail} onChange={(e) => setForm({...form, schoolEmail: e.target.value})}
                       />
                       <div className="flex gap-4">
                          <input 
                            placeholder="Phone Relay" 
                            className="w-full bg-surface-base border border-surface-border rounded-2xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                            required value={form.schoolPhone} onChange={(e) => setForm({...form, schoolPhone: e.target.value})}
                          />
                          <select 
                            className="bg-surface-base border border-surface-border rounded-2xl px-4 text-muted-300 focus:outline-none focus:ring-2 focus:ring-primary-500/20 text-xs font-black uppercase tracking-widest"
                            value={form.plan} onChange={(e) => setForm({...form, plan: e.target.value})}
                          >
                            <option value="starter">Starter</option>
                            <option value="growth">Growth</option>
                            <option value="enterprise">Enterprise</option>
                          </select>
                       </div>
                    </div>
                    <div className="space-y-4">
                       <p className="text-muted-600 text-[9px] font-black uppercase tracking-widest">Admin Authorization</p>
                       <input 
                         placeholder="Root Administrator Name" 
                         className="w-full bg-surface-base border border-surface-border rounded-2xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                         required value={form.adminName} onChange={(e) => setForm({...form, adminName: e.target.value})}
                       />
                       <input 
                         type="email" placeholder="Admin Direct Email" 
                         className="w-full bg-surface-base border border-surface-border rounded-2xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                         required value={form.adminEmail} onChange={(e) => setForm({...form, adminEmail: e.target.value})}
                       />
                       <input 
                         type="password" placeholder="Access Cipher (Min 6 chars)" 
                         className="w-full bg-surface-base border border-surface-border rounded-2xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-primary-500/20"
                         required minLength={6} value={form.adminPassword} onChange={(e) => setForm({...form, adminPassword: e.target.value})}
                       />
                    </div>
                  </div>
                  <Button type="submit" isLoading={submitting} className="w-full">Execute Launch Protocol</Button>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Protocol Update Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-muted-950/80 backdrop-blur-md">
          <Card className="w-full max-w-md animate-fade-in">
             <CardHeader>
               <h3 className="text-2xl font-syne font-bold text-white mb-1">Plan Configuration</h3>
               <p className="text-primary-500 font-bold text-xs uppercase tracking-widest">{selectedSchool?.name}</p>
             </CardHeader>

             <CardContent className="space-y-8">
                <div className="bg-surface-base border border-surface-border rounded-2xl p-1.5 flex gap-1">
                  {['starter', 'growth', 'enterprise'].map(p => (
                    <button
                      key={p} 
                      onClick={() => setEditPlan(p)}
                      className={cn(
                        "flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                        editPlan === p ? "bg-primary-600 text-white shadow-glow" : "text-muted-500 hover:text-white"
                      )}
                    >
                      {p}
                    </button>
                  ))}
                </div>

                <div className="flex gap-4">
                   <Button variant="ghost" onClick={() => setIsEditModalOpen(false)} className="flex-1">Abort</Button>
                   <Button onClick={handleUpdatePlan} className="flex-1">Authorize Sync</Button>
                </div>
             </CardContent>
          </Card>
        </div>
      )}
    </DashboardLayout>
  )
}

export default SuperAdminDashboard
