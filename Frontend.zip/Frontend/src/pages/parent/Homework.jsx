import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getHomeworkApi, submitHomeworkApi } from '../../api/homeworkApi'
import { getStudentsApi } from '../../api/studentApi'

const ParentHomework = () => {
  const [homeworkList, setHomeworkList] = useState([])
  const [students, setStudents] = useState([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [selectedStudent, setSelectedStudent] = useState('')
  const [showSubmitModal, setShowSubmitModal] = useState(null)
  const [file, setFile] = useState(null)
  
  const fetchData = async () => {
    try {
      const [hwRes, stuRes] = await Promise.all([
        getHomeworkApi(),
        getStudentsApi()
      ])
      setHomeworkList(hwRes.data?.homework ?? [])
      const stuList = stuRes.data?.students ?? []
      setStudents(stuList)
      if (stuList.length > 0) setSelectedStudent(stuList[0]._id)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchData() }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!file) return alert('Please select an artifact to transmit.')
    setSubmitting(true)

    const formData = new FormData()
    formData.append('submission', file)
    formData.append('studentId', selectedStudent)

    try {
      await submitHomeworkApi(showSubmitModal._id, formData)
      setShowSubmitModal(null)
      setFile(null)
      alert('Archive updated successfully.')
    } catch (err) {
      alert(err.response?.data?.message || 'Transmission failed.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8 mb-12 animate-fade-in relative">
          <div>
            <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">Transmission Node</h1>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
               <span className="w-1.5 h-1.5 bg-primary-500 rounded-full animate-pulse" />
               External Artifact Submission Portal
            </p>
          </div>
          <div className="flex items-center gap-4 bg-muted-800 border border-muted-700 p-2 rounded-2xl">
             <span className="text-[10px] font-black uppercase tracking-widest pl-4 text-muted-500">Node Select:</span>
             <select 
                value={selectedStudent} 
                onChange={e => setSelectedStudent(e.target.value)}
                className="bg-muted-900 border-none rounded-xl px-4 py-2 text-xs font-bold focus:ring-0"
             >
                {students.map(s => <option key={s._id} value={s._id}>{s.name} ({s.rollNumber})</option>)}
             </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {loading ? (
             [...Array(4)].map((_, i) => <div key={i} className="h-64 bg-muted-800 rounded-3xl animate-pulse" />)
          ) : homeworkList.length === 0 ? (
            <div className="md:col-span-2 text-center py-20 bg-muted-800/50 rounded-[3rem] border border-muted-700">
               <p className="text-muted-500 font-bold uppercase tracking-widest">No Incoming Directives</p>
            </div>
          ) : (
            homeworkList.map(hw => (
              <div key={hw._id} className="bg-muted-800 border border-muted-700 p-10 rounded-[3rem] hover:border-primary-500/30 transition-all duration-500 group relative overflow-hidden">
                <div className="flex justify-between items-start mb-8">
                   <div className="flex flex-col gap-2">
                      <span className="w-fit px-3 py-1 bg-primary-500/10 text-primary-400 text-[9px] font-black uppercase tracking-widest rounded-lg border border-primary-500/20">{hw.subject}</span>
                      <h3 className="font-syne text-2xl font-bold group-hover:text-primary-400 transition-colors uppercase tracking-tight">{hw.title}</h3>
                   </div>
                   <div className="text-right">
                      <p className="text-muted-500 text-[9px] font-black uppercase tracking-widest">Target Deadline</p>
                      <p className="text-white text-xs font-black">{new Date(hw.dueDate).toLocaleDateString()}</p>
                   </div>
                </div>
                
                <p className="text-muted-400 text-sm mb-10 leading-relaxed font-medium">{hw.description}</p>
                
                <div className="flex flex-wrap gap-4 mb-10">
                   {hw.attachments?.map((att, i) => (
                      <a key={i} href={att.url} target="_blank" rel="noreferrer" className="flex items-center gap-2 px-4 py-2 bg-muted-900 border border-muted-700 rounded-xl text-[10px] font-bold text-muted-300 hover:text-white hover:border-muted-500 transition-all">
                         📎 Artifact {i+1}
                      </a>
                   ))}
                </div>

                <button 
                   onClick={() => setShowSubmitModal(hw)}
                   className="w-full bg-primary-500/10 text-primary-400 border border-primary-500/20 hover:bg-primary-500 hover:text-white py-5 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] transition-all duration-300 active:scale-95 shadow-xl hover:shadow-primary-900/20"
                >
                   Finalize & Commit Submission
                </button>
              </div>
            ))
          )}
        </div>

        {showSubmitModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-md" onClick={() => setShowSubmitModal(null)} />
            <div className="relative w-full max-w-lg bg-muted-800 border border-muted-700 rounded-[2.5rem] shadow-2xl p-10 animate-fade-up">
              <h2 className="font-syne text-2xl font-bold mb-2">Initialize Transfer</h2>
              <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest mb-8 border-b border-muted-700 pb-8">Source Node: {students.find(s => s._id === selectedStudent)?.name}</p>
              
              <form onSubmit={handleSubmit} className="space-y-8">
                <div>
                   <label className="block text-[10px] font-black text-muted-500 uppercase tracking-widest mb-4">Select Artifact (PDF/Image)</label>
                   <input 
                      type="file" 
                      onChange={e => setFile(e.target.files[0])}
                      className="w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-4 text-xs font-bold file:hidden cursor-pointer" 
                      required
                   />
                </div>
                {file && <p className="text-[10px] font-bold text-primary-400 uppercase tracking-widest">Buffer Status: {file.name} ready</p>}
                <div className="flex gap-4 pt-4">
                  <button type="button" onClick={() => setShowSubmitModal(null)} className="flex-1 bg-muted-900 py-4 rounded-xl font-bold text-xs">ABORT</button>
                  <button type="submit" disabled={submitting} className="flex-1 bg-primary-500 py-4 rounded-xl font-bold text-xs">{submitting ? 'UPLOADING...' : 'COMMIT'}</button>
                </div>
              </form>
            </div>
          </div>
        )}

      </main>
    </div>
  )
}

export default ParentHomework
