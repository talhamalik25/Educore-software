import { useState, useEffect, useRef } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import ReportCard from '../../components/ReportCard'
import { getMyResultsApi } from '../../api/resultApi'
import { Printer, Download, Search, BookOpen, Award, Filter, ChevronRight } from 'lucide-react'

const ParentResults = () => {
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(true)
  const [examTypeFilter, setExamTypeFilter] = useState('')
  const reportRef = useRef()

  const fetchResults = async () => {
    try {
      const res = await getMyResultsApi()
      setResults(res.data?.results ?? [])
    } catch (err) {
      console.error('Failed to fetch results:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchResults()
  }, [])

  const filteredResults = examTypeFilter 
    ? results.filter(r => r.examType === examTypeFilter)
    : results

  const groupedResults = filteredResults.reduce((acc, curr) => {
    const subject = curr.subject
    if (!acc[subject]) acc[subject] = []
    acc[subject].push(curr)
    return acc
  }, {})

  const handlePrint = () => {
    window.print()
  }

  const getGradeColor = (grade) => {
    switch (grade) {
      case 'A+': return 'bg-green-500/10 text-green-400 border-green-500/20'
      case 'A': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
      case 'B': return 'bg-blue-500/10 text-blue-400 border-blue-500/20'
      case 'C': return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
      case 'D': return 'bg-orange-500/10 text-orange-400 border-orange-500/20'
      case 'F': return 'bg-red-500/10 text-red-400 border-red-500/20'
      default: return 'bg-muted-700 text-muted-400 border-muted-600'
    }
  }

  // Get student info from first result if available
  const studentInfo = results.length > 0 ? results[0].studentId : null

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        {/* Header */}
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8 mb-12 animate-fade-in">
          <div>
            <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">Academic Progress</h1>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
               <span className="w-1.5 h-1.5 bg-primary-500 rounded-full animate-pulse" />
               Child Achievement Monitoring
            </p>
          </div>
          <button
            onClick={handlePrint}
            disabled={results.length === 0}
            className="inline-flex items-center justify-center gap-3 px-8 py-3.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all duration-300 active:scale-95 cursor-pointer shadow-xl bg-primary-500 text-white hover:bg-primary-600 shadow-primary-900/20 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Printer size={16} />
            Download Report Card
          </button>
        </div>

        {/* Filter Bar */}
        <div className="flex flex-col md:flex-row items-center gap-6 mb-10">
          <div className="relative w-full md:w-72">
            <Filter className="absolute left-5 top-1/2 -translate-y-1/2 text-muted-500" size={16} />
            <select
              className="w-full bg-muted-800 border border-muted-700 rounded-2xl pl-12 pr-6 py-4 text-sm font-bold text-white focus:outline-none focus:border-primary-500 transition-all appearance-none"
              value={examTypeFilter}
              onChange={(e) => setExamTypeFilter(e.target.value)}
            >
              <option value="">All Exam Cycles</option>
              <option value="monthly">Monthly Tests</option>
              <option value="midterm">Midterm Examination</option>
              <option value="final">Final Examination</option>
              <option value="quiz">Quizzes & Assignments</option>
            </select>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-64 bg-muted-800 rounded-[2.5rem] animate-pulse" />
            ))}
          </div>
        ) : results.length === 0 ? (
          <div className="py-20 text-center bg-muted-800/50 rounded-[3rem] border border-muted-700">
             <div className="w-20 h-20 bg-muted-900 rounded-3xl flex items-center justify-center mx-auto mb-6 text-muted-500">
                <Search size={32} />
             </div>
             <h3 className="font-syne text-xl font-bold text-white mb-2">No Records Detected</h3>
             <p className="text-muted-500 text-sm max-w-md mx-auto">Academic nodes are currently empty. Results will appear here once published by the faculty.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {Object.keys(groupedResults).map((subject, index) => (
              <div key={index} className="bg-muted-800 border border-muted-700 p-8 rounded-[2.5rem] shadow-xl hover:border-primary-500/30 transition-all duration-500 group">
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-12 bg-primary-500/10 rounded-2xl flex items-center justify-center text-primary-400">
                    <BookOpen size={24} />
                  </div>
                  <div>
                    <h3 className="font-syne text-xl font-bold text-white">{subject}</h3>
                    <p className="text-[10px] text-muted-500 font-black uppercase tracking-widest mt-1">Academic Performance</p>
                  </div>
                </div>

                <div className="space-y-4">
                  {groupedResults[subject].map((res, idx) => (
                    <div key={idx} className="bg-muted-900/50 border border-muted-700/50 p-5 rounded-3xl flex items-center justify-between group/item hover:bg-muted-900 transition-colors">
                      <div>
                        <p className="text-xs font-black uppercase tracking-widest text-muted-500 mb-1">{res.examType}</p>
                        <p className="text-sm font-bold text-white">{res.obtainedMarks} / {res.totalMarks}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className={`px-4 py-1.5 rounded-xl text-[10px] font-black border ${getGradeColor(res.grade)}`}>
                          {res.grade}
                        </span>
                        <ChevronRight size={16} className="text-muted-600 group-hover/item:text-primary-400 transition-colors" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Hidden Printable Report Card */}
        <div className="hidden">
          <div className="print-area">
            <ReportCard 
              ref={reportRef} 
              student={studentInfo} 
              results={filteredResults}
              schoolName="EduCore OS Academy"
            />
          </div>
        </div>

      </main>
    </div>
  )
}

export default ParentResults
