import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getStudentsApi } from '../../api/studentApi'
import { getStudentAttendanceApi } from '../../api/attendanceApi'
import { getFeesApi } from '../../api/feeApi'
import { useAuth } from '../../context/AuthContext'

const ParentDashboard = () => {
  const { user } = useAuth()
  const [students, setStudents] = useState([])
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [attendance, setAttendance] = useState(null)
  const [fees, setFees] = useState([])
  const [loading, setLoading] = useState(true)

  const currentMonth = new Date().toISOString().slice(0, 7) // "2025-01"

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const res = await getStudentsApi()
        const list = res.data.students
        setStudents(list)
        if (list.length > 0) setSelectedStudent(list[0])
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    fetchStudents()
  }, [])

  useEffect(() => {
    if (!selectedStudent) return
    const fetchDetails = async () => {
      try {
        const [attendanceRes, feesRes] = await Promise.all([
          getStudentAttendanceApi(selectedStudent._id, currentMonth),
          getFeesApi({ studentId: selectedStudent._id }),
        ])
        setAttendance(attendanceRes.data)
        setFees(feesRes.data.fees)
      } catch (err) {
        console.error(err)
      }
    }
    fetchDetails()
  }, [selectedStudent])

  const currentMonthLabel = new Date().toLocaleString('default', { month: 'long', year: 'numeric' })

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">

        {/* Welcome Header */}
        <div className="mb-10 animate-fade-in relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary-500/5 blur-[80px] rounded-full pointer-events-none" />
          <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter">
            Assalam o Alaikum, {user?.name?.split(' ')[0]} 👋
          </h1>
          <p className="text-muted-500 text-[11px] font-black uppercase tracking-[0.2em] mt-3 flex items-center gap-2">
             <span className="w-1.5 h-1.5 bg-primary-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
             Accessing Child Guardian Portal
          </p>
        </div>

        {loading ? (
          <div className="space-y-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-muted-800 border border-muted-700 rounded-[2.5rem] p-8 animate-pulse h-40 shadow-xl" />
            ))}
          </div>
        ) : students.length === 0 ? (
          <div className="bg-muted-800 border border-muted-700 rounded-[3rem] p-20 text-center shadow-2xl">
            <div className="w-24 h-24 bg-muted-900 border border-muted-700 rounded-[2rem] flex items-center justify-center mx-auto mb-8 text-5xl opacity-80 backdrop-blur-sm shadow-inner">👨‍👩‍👦</div>
            <p className="font-syne text-2xl font-bold mb-3 text-white">No Linkage Detected</p>
            <p className="text-muted-500 text-sm max-w-xs mx-auto leading-relaxed uppercase font-bold tracking-widest text-[10px]">Please contact the academic administration to link your child to this console.</p>
          </div>
        ) : (
          <div className="lg:max-w-5xl mx-auto">
            
            {/* Child Selector - Horizontal Optimized for Mobile */}
            <div className="mb-10 animate-fade-in">
              <p className="text-muted-400 text-[10px] uppercase font-black tracking-[0.2em] mb-4 ml-4">Authorized Profiles:</p>
              <div className="flex gap-4 overflow-x-auto pb-4 px-4 no-scrollbar scroll-smooth">
                {students.map(s => (
                  <button
                    key={s._id}
                    onClick={() => setSelectedStudent(s)}
                    className={`flex-shrink-0 flex items-center gap-4 px-6 py-4 rounded-[1.5rem] border transition-all duration-500 group relative ${
                      selectedStudent?._id === s._id
                        ? 'bg-primary-500 border-primary-400 text-white shadow-lg shadow-primary-900/30 ring-2 ring-primary-500/20'
                        : 'bg-muted-800 border-muted-700 text-muted-400 hover:border-muted-600 hover:bg-muted-700'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-black shadow-inner transition-colors duration-300 ${
                       selectedStudent?._id === s._id ? 'bg-white/20 text-white' : 'bg-muted-900 text-primary-400'
                    }`}>
                      {s.name.charAt(0)}
                    </div>
                    <div className="text-left pr-4">
                      <p className="text-xs font-black uppercase tracking-widest leading-none mb-1">{s.name}</p>
                      <p className={`text-[9px] font-bold ${selectedStudent?._id === s._id ? 'text-white/70' : 'text-muted-500'}`}>Class {s.class}{s.section}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {selectedStudent && (
              <div className="space-y-8 animate-fade-up">
                
                {/* Visual Identity Card */}
                <div className="bg-muted-800 border border-muted-700 rounded-[2.5rem] p-8 md:p-12 shadow-2xl relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-primary-500/5 blur-[60px] rounded-full pointer-events-none" />
                  <div className="flex flex-col md:flex-row items-center gap-8 relative z-10">
                    <div className="w-20 h-20 md:w-24 md:h-24 rounded-[2rem] bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center text-white text-3xl font-black font-syne shadow-xl shadow-primary-900/40 border-2 border-primary-400/30">
                      {selectedStudent.name.charAt(0)}
                    </div>
                    <div className="text-center md:text-left">
                      <h2 className="font-syne text-3xl font-black text-white mb-2 tracking-tight group-hover:text-primary-400 transition-colors">{selectedStudent.name}</h2>
                      <div className="flex flex-wrap justify-center md:justify-start gap-3">
                         <span className="text-[10px] font-black text-muted-400 border border-muted-700 px-3 py-1.5 rounded-xl bg-muted-900/50 uppercase tracking-widest">Grade {selectedStudent.class} • Section {selectedStudent.section}</span>
                         <span className="text-[10px] font-black text-muted-400 border border-muted-700 px-3 py-1.5 rounded-xl bg-muted-900/50 uppercase tracking-widest">ID: {selectedStudent.rollNumber}</span>
                      </div>
                    </div>
                    <div className="mt-4 w-full md:w-auto md:mt-0 md:ml-auto text-center md:text-right">
                      <div className={`inline-flex items-center gap-2.5 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest border shadow-xl ${
                        selectedStudent.feeStatus === 'paid'
                          ? 'bg-green-500/10 text-green-400 border-green-500/20'
                          : 'bg-red-500/10 text-red-400 border-red-500/20'
                      }`}>
                         <div className={`w-2 h-2 rounded-full ${selectedStudent.feeStatus === 'paid' ? 'bg-green-500' : 'bg-red-500 animate-pulse'}`} />
                         Account {selectedStudent.feeStatus}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Performance Analytics (Attendance) */}
                {attendance && (
                  <div className="bg-muted-800 border border-muted-700 rounded-[2.5rem] p-6 md:p-12 shadow-2xl relative overflow-hidden group">
                    <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-500/5 blur-[50px] rounded-full pointer-events-none" />
                    <div className="flex items-center justify-between mb-10">
                       <h3 className="font-syne text-xl font-black text-white uppercase tracking-widest">Monthly Sync</h3>
                       <p className="text-muted-500 text-[10px] font-black uppercase tracking-widest">{currentMonthLabel}</p>
                    </div>
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                      {[
                        { label: 'Total Sessions', value: attendance.summary?.total, color: 'text-white', bg: 'bg-muted-900' },
                        { label: 'Attended', value: attendance.summary?.present, color: 'text-green-400', bg: 'bg-green-500/5' },
                        { label: 'Absentee', value: attendance.summary?.absent, color: 'text-red-400', bg: 'bg-red-500/5' },
                        { label: 'Late Commits', value: attendance.summary?.late, color: 'text-yellow-400', bg: 'bg-yellow-500/5' },
                      ].map(item => (
                        <div key={item.label} className={`${item.bg} border border-muted-700/50 rounded-3xl p-6 text-center transition-all duration-300 hover:scale-105 hover:border-muted-600`}>
                          <p className={`text-3xl md:text-5xl font-syne font-black mb-2 tracking-tighter ${item.color}`}>{item.value ?? 0}</p>
                          <p className="text-muted-500 text-[9px] font-black uppercase tracking-widest leading-none">{item.label}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Financial Ledger (Fees) */}
                <div className="bg-muted-800 border border-muted-700 rounded-[2.5rem] p-6 md:p-12 shadow-2xl">
                  <h3 className="font-syne text-xl font-black text-white uppercase tracking-widest mb-10">Financial Ledger</h3>
                  {fees.length === 0 ? (
                    <div className="flex flex-col items-center py-10 opacity-40">
                       <span className="text-4xl mb-4">📜</span>
                       <p className="text-muted-500 text-xs font-black uppercase tracking-[0.2em]">No transactional logs available.</p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {fees.map(fee => (
                        <div key={fee._id} className="flex flex-col sm:flex-row items-center justify-between gap-6 p-6 rounded-[1.5rem] border border-muted-700 hover:border-muted-600 hover:bg-muted-700/20 transition-all duration-300">
                          <div className="text-center sm:text-left">
                            <p className="text-white text-base font-black tracking-tight mb-1">{fee.month}</p>
                            <div className="flex items-center gap-2 justify-center sm:justify-start">
                               <div className="w-1.5 h-1.5 rounded-full bg-muted-600" />
                               <p className="text-muted-500 text-[10px] font-bold uppercase tracking-widest">Entry: {new Date(fee.dueDate).toLocaleDateString('en-PK')}</p>
                            </div>
                          </div>
                          <div className="flex flex-col items-center sm:items-end gap-2.5">
                            <div className="flex items-baseline gap-1.5">
                               <span className="text-primary-400 text-[10px] font-black uppercase">PKR</span>
                               <span className="text-white text-2xl font-black tracking-tighter">{fee.amount?.toLocaleString()}</span>
                            </div>
                            <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest border transition-all duration-300 ${
                              fee.status === 'paid'
                                ? 'bg-green-500/10 text-green-400 border-green-500/20'
                                : fee.status === 'overdue'
                                ? 'bg-red-500/10 text-red-400 border-red-500/20'
                                : 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
                            }`}>
                              {fee.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

      </main>

      <style dangerouslySetInnerHTML={{ __html: `
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}} />
    </div>
  )
}

export default ParentDashboard
