import { useState, useEffect } from 'react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import StatCard from '../../components/ui/StatCard'
import { Card, CardHeader, CardContent } from '../../components/ui/Card'
import Badge from '../../components/ui/Badge'
import { Table, TableRow, TableCell, TableBody, TableHeader, TableHead } from '../../components/ui/Table'
import { getStudentsApi } from '../../api/studentApi'
import { getStudentAttendanceApi } from '../../api/attendanceApi'
import { getFeesApi } from '../../api/feeApi'
import { useAuth } from '../../context/AuthContext'
import { 
  User, 
  Baby, 
  Wallet, 
  CalendarCheck, 
  Award,
  ChevronRight,
  ShieldCheck,
  CreditCard
} from 'lucide-react'
import { cn } from '../../lib/utils'

const ParentDashboard = () => {
  const { user } = useAuth()
  const [students, setStudents] = useState([])
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [attendance, setAttendance] = useState(null)
  const [fees, setFees] = useState([])
  const [loading, setLoading] = useState(true)

  const currentMonth = new Date().toISOString().slice(0, 7)

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const res = await getStudentsApi()
        const list = res.data?.data?.students ?? []
        setStudents(list)
        if (list.length > 0) setSelectedStudent(list[0])
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    fetchStudents()
  }, [])

  useEffect(() => {
    if (!selectedStudent) return
    const fetchDetails = async () => {
      try {
        const [attendanceRes, feesRes] = await Promise.all([
          getStudentAttendanceApi(selectedStudent._id, currentMonth),
          getFeesApi({ studentId: selectedStudent._id }),
        ])
        setAttendance(attendanceRes.data?.data)
        setFees(feesRes.data?.data?.fees ?? [])
      } catch (err) {
        console.error(err)
      }
    }
    fetchDetails()
  }, [selectedStudent])

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="font-syne text-4xl font-bold text-white tracking-tight mb-2">
            Hello, {user?.name?.split(' ')[0]}
          </h1>
          <p className="text-muted-500 font-medium flex items-center gap-2 uppercase tracking-widest text-[10px]">
            <ShieldCheck size={14} className="text-primary-500" />
            Guardian Control Center — Secure Access
          </p>
        </div>
      </div>

      {!loading && students.length > 0 ? (
        <div className="space-y-10">
          {/* Student/Child Selector */}
          <div className="flex gap-4 overflow-x-auto pb-4 -mx-2 px-2 no-scrollbar">
            {students.map(s => (
              <button
                key={s._id}
                onClick={() => setSelectedStudent(s)}
                className={cn(
                  "flex-shrink-0 flex items-center gap-4 px-6 py-4 rounded-[2rem] border transition-all duration-500 group",
                  selectedStudent?._id === s._id
                    ? "bg-primary-600 border-primary-500 text-white shadow-glow"
                    : "bg-surface-elevated border-surface-border text-muted-400 hover:border-muted-600"
                )}
              >
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center text-lg font-black transition-colors shadow-inner",
                  selectedStudent?._id === s._id ? "bg-white/20" : "bg-surface-base text-primary-400"
                )}>
                  {s.name.charAt(0)}
                </div>
                <div className="text-left">
                  <p className="text-xs font-black uppercase tracking-widest mb-1">{s.name}</p>
                  <p className={cn("text-[10px] font-bold opacity-70")}>Grade {s.class}</p>
                </div>
              </button>
            ))}
          </div>

          {selectedStudent && (
            <>
              {/* Snapshot Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
                 <StatCard
                   label="Attendance Rate"
                   value={`${attendance?.summary?.present || 0}/${attendance?.summary?.total || 0}`}
                   icon={CalendarCheck}
                   color="primary"
                 />
                 <StatCard
                   label="Late Arrivals"
                   value={attendance?.summary?.late || 0}
                   icon={Award}
                   color="amber"
                 />
                 <StatCard
                   label="Fee Status"
                   value={selectedStudent.feeStatus || 'Pending'}
                   icon={Wallet}
                   color={selectedStudent.feeStatus === 'paid' ? 'primary' : 'rose'}
                 />
                 <StatCard
                   label="Academic Status"
                   value="Enrolled"
                   icon={Baby}
                   color="blue"
                 />
              </div>

              {/* Main Info */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between">
                      <h2 className="font-syne text-xl font-bold text-white">Payment History</h2>
                      <CreditCard size={20} className="text-muted-500" />
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Month</TableHead>
                            <TableHead>Amount</TableHead>
                            <TableHead>Due Date</TableHead>
                            <TableHead>Status</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {fees.map(fee => (
                            <TableRow key={fee._id}>
                              <TableCell className="font-bold text-white">{fee.month}</TableCell>
                              <TableCell className="text-primary-400 font-bold">PKR {fee.amount?.toLocaleString()}</TableCell>
                              <TableCell>{new Date(fee.dueDate).toLocaleDateString()}</TableCell>
                              <TableCell>
                                <Badge variant={fee.status === 'paid' ? 'success' : 'danger'}>
                                  {fee.status}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                </div>

                <Card className="bg-gradient-to-br from-accent-purple/20 to-accent-blue/20 border-surface-border">
                  <h3 className="font-syne text-lg font-bold text-white mb-4">Communication</h3>
                  <div className="space-y-4">
                    <p className="text-muted-400 text-sm leading-relaxed">
                      Stay updated with {selectedStudent.name.split(' ')[0]}'s school activities and parent-teacher meetings.
                    </p>
                    <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-3 group cursor-pointer hover:bg-white/10 transition-all">
                       <Bell size={18} className="text-accent-purple" />
                       <span className="text-xs font-bold text-white">View Announcements</span>
                       <ChevronRight size={14} className="ml-auto text-muted-500 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </Card>
              </div>
            </>
          )}
        </div>
      ) : !loading && (
        <Card className="max-w-xl mx-auto text-center py-20">
          <Baby size={64} className="mx-auto text-muted-700 mb-6" />
          <h2 className="font-syne text-2xl font-bold text-white mb-3">No Child Profiles Found</h2>
          <p className="text-muted-500 text-sm leading-relaxed mb-8">
            Your guardian account is not currently linked to any student profile. Please contact the school office to verify linkage.
          </p>
        </Card>
      )}
    </DashboardLayout>
  )
}

export default ParentDashboard
