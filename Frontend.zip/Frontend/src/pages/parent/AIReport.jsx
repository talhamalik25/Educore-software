import { useState, useEffect } from 'react'
import Sidebar from '../../components/ui/Sidebar'
import { getStudentReportApi } from '../../api/aiApi'
import { getStudentsApi } from '../../api/studentApi'
import { 
  Brain, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown, 
  Lightbulb, 
  Clock,
  ArrowRight,
  ShieldAlert,
  Loader2
} from 'lucide-react'

const ParentAIReport = () => {
  const [students, setStudents] = useState([])
  const [selectedStudent, setSelectedStudent] = useState(null)
  const [report, setReport] = useState(null)
  const [loading, setLoading] = useState(true)
  const [loadingReport, setLoadingReport] = useState(false)

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const res = await getStudentsApi()
        const list = res.data?.data?.students ?? []
        setStudents(list)
        if (list.length > 0) setSelectedStudent(list[0])
      } catch (err) {
        console.error('Failed to fetch children:', err)
      } finally {
        setLoading(false)
      }
    }
    fetchStudents()
  }, [])

  useEffect(() => {
    if (!selectedStudent) return
    const fetchReport = async () => {
      setLoadingReport(true)
      try {
        const res = await getStudentReportApi(selectedStudent._id)
        setReport(res.data?.data)
      } catch (err) {
        setReport(null)
      } finally {
        setLoadingReport(false)
      }
    }
    fetchReport()
  }, [selectedStudent])

  const getRiskMeta = (level) => {
    switch (level) {
      case 'high': return { 
        label: 'Needs Immediate Attention', 
        color: 'text-red-400', 
        bg: 'bg-red-500/10', 
        border: 'border-red-500/20', 
        icon: ShieldAlert 
      }
      case 'medium': return { 
        label: 'Needs Improvement', 
        color: 'text-yellow-400', 
        bg: 'bg-yellow-500/10', 
        border: 'border-yellow-500/20', 
        icon: AlertTriangle 
      }
      case 'low': return { 
        label: 'Performing Well', 
        color: 'text-green-400', 
        bg: 'bg-green-500/10', 
        border: 'border-green-500/20', 
        icon: CheckCircle2 
      }
      default: return null
    }
  }

  const getProgressColor = (val) => {
    if (val < 70) return 'bg-red-500'
    if (val < 80) return 'bg-yellow-500'
    return 'bg-primary-500'
  }

  if (loading) return null

  const risk = report ? getRiskMeta(report.riskLevel) : null

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white relative overflow-hidden">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        {/* Header */}
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8 mb-12 animate-fade-in">
          <div>
            <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter flex items-center gap-4">
              <Brain className="text-primary-400" size={40} />
              Academic Intelligence
            </h1>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
               <span className="w-1.5 h-1.5 bg-primary-500 rounded-full animate-pulse" />
               AI-Driven Performance Diagnostics
            </p>
          </div>

          {students.length > 1 && (
            <div className="flex gap-2">
              {students.map(s => (
                <button
                  key={s._id}
                  onClick={() => setSelectedStudent(s)}
                  className={`px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest border transition-all ${
                    selectedStudent?._id === s._id 
                    ? 'bg-primary-500 border-primary-500 text-white shadow-lg shadow-primary-900/20' 
                    : 'bg-muted-800 border-muted-700 text-muted-500 hover:border-muted-600'
                  }`}
                >
                  {s.name}
                </button>
              ))}
            </div>
          )}
        </div>

        {loadingReport ? (
          <div className="py-20 text-center animate-pulse">
            <Loader2 className="animate-spin mx-auto text-primary-500 mb-4" size={32} />
            <p className="text-muted-500 font-black uppercase tracking-[0.2em]">Synthesizing Neural Data...</p>
          </div>
        ) : !report ? (
          <div className="py-20 text-center bg-muted-800/50 rounded-[3rem] border border-muted-700 p-10 max-w-2xl mx-auto">
             <div className="w-20 h-20 bg-muted-900 rounded-3xl flex items-center justify-center mx-auto mb-6 text-muted-500">
                <Sparkles size={32} />
             </div>
             <h3 className="font-syne text-2xl font-bold text-white mb-4">No Analysis Available</h3>
             <p className="text-muted-400 text-sm leading-relaxed mb-8">
               An academic performance report has not been generated for {selectedStudent?.name} yet. 
               Please contact the school administration to request a neural analysis of current results and attendance.
             </p>
          </div>
        ) : (
          <div className="space-y-8 max-w-5xl mx-auto">
            {/* Risk Card */}
            <div className={`${risk.bg} border ${risk.border} p-10 rounded-[3rem] shadow-2xl flex flex-col md:flex-row items-center gap-10 relative overflow-hidden`}>
              <div className="absolute top-0 right-0 p-10 text-white/5"><Sparkles size={120} /></div>
              <div className={`w-24 h-24 rounded-3xl ${risk.bg} border ${risk.border} flex items-center justify-center ${risk.color}`}>
                <risk.icon size={48} />
              </div>
              <div className="text-center md:text-left">
                <p className="text-[10px] font-black uppercase tracking-[0.3em] text-muted-500 mb-2">Performance Status</p>
                <h2 className={`font-syne text-3xl md:text-5xl font-bold ${risk.color}`}>{risk.label}</h2>
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-muted-800 border border-muted-700 p-10 rounded-[2.5rem] shadow-xl">
                <div className="flex justify-between items-center mb-6">
                  <p className="text-[10px] font-black uppercase tracking-widest text-muted-500">Attendance Sync</p>
                  <span className="text-2xl font-bold font-syne text-white">{report.attendanceScore}%</span>
                </div>
                <div className="h-4 bg-muted-900 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-1000 ${getProgressColor(report.attendanceScore)}`}
                    style={{ width: `${report.attendanceScore}%` }}
                  />
                </div>
              </div>
              <div className="bg-muted-800 border border-muted-700 p-10 rounded-[2.5rem] shadow-xl">
                <div className="flex justify-between items-center mb-6">
                  <p className="text-[10px] font-black uppercase tracking-widest text-muted-500">Average Grade</p>
                  <span className="text-2xl font-bold font-syne text-white">{report.averageGrade}%</span>
                </div>
                <div className="h-4 bg-muted-900 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-1000 ${getProgressColor(report.averageGrade)}`}
                    style={{ width: `${report.averageGrade}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Subject Vectors */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-red-500/5 border border-red-500/10 p-8 rounded-[2.5rem]">
                <p className="text-[10px] font-black text-red-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                  <TrendingDown size={14} /> Subject Weaknesses
                </p>
                <div className="flex flex-wrap gap-3">
                  {report.weakSubjects?.map((sub, i) => (
                    <span key={i} className="px-5 py-2 bg-red-500/10 text-red-400 text-[10px] font-black uppercase tracking-widest rounded-xl border border-red-500/10">
                      {sub}
                    </span>
                  ))}
                </div>
              </div>
              <div className="bg-green-500/5 border border-green-500/10 p-8 rounded-[2.5rem]">
                <p className="text-[10px] font-black text-green-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                  <TrendingUp size={14} /> Power Subjects
                </p>
                <div className="flex flex-wrap gap-3">
                  {report.strongSubjects?.map((sub, i) => (
                    <span key={i} className="px-5 py-2 bg-green-500/10 text-green-400 text-[10px] font-black uppercase tracking-widest rounded-xl border border-green-500/10">
                      {sub}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* AI Summary */}
            <div className="bg-muted-800 border-l-4 border-l-primary-500 border border-muted-700 p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 text-primary-500/5"><Brain size={64} /></div>
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-primary-400 mb-4">Deep Intelligence Synthesis</h3>
              <p className="text-muted-200 text-lg leading-relaxed italic font-medium">
                "{report.summary}"
              </p>
            </div>

            {/* Recommendations */}
            <div className="space-y-6">
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-500 flex items-center gap-3 px-6">
                <Lightbulb size={16} className="text-yellow-400" /> Recommendations for You
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {report.recommendations?.slice(0, 3).map((rec, i) => (
                  <div key={i} className="bg-muted-800 border border-muted-700 p-8 rounded-[2.5rem] shadow-xl hover:border-primary-500/30 transition-all group">
                    <div className="w-10 h-10 rounded-xl bg-muted-900 flex items-center justify-center text-primary-400 font-bold mb-6 group-hover:scale-110 transition-transform">
                      0{i+1}
                    </div>
                    <p className="text-sm text-muted-300 leading-relaxed">{rec}</p>
                    <div className="mt-6 flex justify-end">
                       <CheckCircle2 size={16} className="text-primary-500/30 group-hover:text-primary-500 transition-colors" />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="pt-12 border-t border-muted-800 flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-muted-600">
               <span>Generated by EduCore Neural Analyzer</span>
               <span>Last Updated: {new Date(report.lastAnalyzed).toLocaleDateString()}</span>
            </div>
          </div>
        )}

      </main>
    </div>
  )
}

export default ParentAIReport
