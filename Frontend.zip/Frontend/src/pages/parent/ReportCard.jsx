import { useState, useEffect, useMemo } from 'react';
import Sidebar from '../../components/ui/Sidebar';
import { getStudentsApi } from '../../api/studentApi';
import { getReportCardData, downloadReportCardPDF } from '../../api/reportCardApi';
import ReportCard from '../../components/ReportCard';
import { useAuth } from '../../context/AuthContext';
import { 
  Printer, 
  Download, 
  Loader2, 
  AlertCircle,
  Award,
  Filter,
  FileText
} from 'lucide-react';
import Button from '../../components/ui/Button';

const ParentReportCard = () => {
  const { user } = useAuth();
  const [students, setStudents] = useState([]); // fallback if user has no linked student
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [examType, setExamType] = useState('final');
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [fetchingReport, setFetchingReport] = useState(false);
  const [error, setError] = useState(null);

  const linkedStudentId = useMemo(() => {
    return (
      user?.studentId ||
      user?.linkedStudentId ||
      user?.student?._id ||
      user?.student || // sometimes backend returns just an id
      null
    );
  }, [user]);

  useEffect(() => {
    // Preferred: parent account already linked to a student in auth context
    if (linkedStudentId) {
      setSelectedStudent({ _id: linkedStudentId, name: user?.student?.name || user?.childName || 'Student' });
      setLoading(false);
      return;
    }

    // Fallback: load children list (some backends do not embed student linkage in auth payload)
    const fetchStudents = async () => {
      try {
        const res = await getStudentsApi();
        const studentList = res.data?.data?.students ?? [];
        setStudents(studentList);
        if (studentList.length > 0) setSelectedStudent(studentList[0]);
        else setSelectedStudent(null);
      } catch (err) {
        console.error('Failed to fetch students:', err);
        setError('Could not load student information.');
      } finally {
        setLoading(false);
      }
    };
    fetchStudents();
  }, [linkedStudentId, user]);

  useEffect(() => {
    if (selectedStudent) {
      fetchReport();
    }
  }, [selectedStudent, examType]);

  const fetchReport = async () => {
    setFetchingReport(true);
    setError(null);
    try {
      const data = await getReportCardData(selectedStudent._id, examType);
      setReportData(data.data);
    } catch (err) {
      setReportData(null);
      if (err.response?.status === 404) {
        // Not really an error, just no data for this exam type
      } else {
        setError('Failed to fetch report card data.');
      }
    } finally {
      setFetchingReport(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!reportData) return;
    try {
      await downloadReportCardPDF(selectedStudent._id, examType, selectedStudent.name);
    } catch (err) {
      console.error('Download failed:', err);
    }
  };

  const inputClass = "w-full bg-muted-800 border border-muted-700 rounded-2xl pl-12 pr-6 py-4 text-sm font-bold text-white focus:outline-none focus:border-primary-500 transition-all appearance-none cursor-pointer";

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-muted-900 text-white">
      <Sidebar />
      <main className="flex-1 p-4 md:p-10 lg:p-14 overflow-y-auto">
        
        {/* Header */}
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8 mb-12 animate-fade-in no-print">
          <div>
            <h1 className="font-syne text-3xl md:text-5xl font-bold bg-gradient-to-r from-white to-muted-500 bg-clip-text text-transparent tracking-tighter flex items-center gap-4">
              <Award className="text-primary-400" size={40} />
              Report Card
            </h1>
            <p className="text-muted-500 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
               <span className="w-1.5 h-1.5 bg-primary-500 rounded-full animate-pulse" />
               Official Student Credentials
            </p>
          </div>
          <div className="flex gap-3">
            <Button 
              variant="secondary" 
              onClick={() => window.print()}
              disabled={!reportData}
              className="gap-2 rounded-2xl bg-white/5 border-white/10 hover:bg-white/10"
            >
              <Printer size={18} />
              Print Report Card
            </Button>
            <Button 
              variant="secondary" 
              onClick={handleDownloadPDF}
              disabled={!reportData}
              className="gap-2 rounded-2xl bg-white/5 border-white/10 hover:bg-white/10"
            >
              <Download size={18} />
              Download PDF
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row items-center gap-6 mb-12 no-print">
          {!linkedStudentId && students.length > 1 && (
            <div className="relative w-full md:w-72">
              <FileText className="absolute left-5 top-1/2 -translate-y-1/2 text-muted-500" size={16} />
              <select
                className={inputClass}
                value={selectedStudent?._id}
                onChange={(e) => setSelectedStudent(students.find(s => s._id === e.target.value))}
              >
                {students.map(s => (
                  <option key={s._id} value={s._id}>{s.name}</option>
                ))}
              </select>
            </div>
          )}
          <div className="relative w-full md:w-72">
            <Filter className="absolute left-5 top-1/2 -translate-y-1/2 text-muted-500" size={16} />
            <select
              className={inputClass}
              value={examType}
              onChange={(e) => setExamType(e.target.value)}
            >
              <option value="monthly">Monthly Test</option>
              <option value="midterm">Midterm Exam</option>
              <option value="final">Final Exam</option>
              <option value="quiz">Class Quiz</option>
            </select>
          </div>
        </div>

        {/* Content */}
        {loading || fetchingReport ? (
          <div className="py-32 flex flex-col items-center justify-center text-muted-500">
            <Loader2 className="animate-spin mb-4" size={48} />
            <p className="font-syne font-bold uppercase tracking-widest">Fetching Report Data...</p>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center py-20 bg-red-500/5 border border-red-500/10 rounded-[3rem] text-red-400">
            <AlertCircle size={48} className="mb-4 opacity-50" />
            <p className="font-syne text-xl font-bold uppercase tracking-widest">{error}</p>
          </div>
        ) : !selectedStudent ? (
          <div className="flex flex-col items-center justify-center py-32 bg-surface-elevated/50 border border-white/5 rounded-[3rem] text-muted-500 text-center px-10">
            <FileText size={64} className="mb-6 opacity-20" />
            <h3 className="font-syne text-2xl font-bold text-white mb-2 uppercase tracking-widest">No Linked Student</h3>
            <p className="text-sm max-w-md">
              Your parent account is not linked to a student profile yet. Please contact your school admin to link your account.
            </p>
          </div>
        ) : reportData ? (
          <div className="animate-fade-in">
            <ReportCard 
              student={reportData.student}
              school={reportData.school}
              results={reportData.results}
              summary={reportData.summary}
              examType={examType}
            />
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-32 bg-surface-elevated/50 border border-white/5 rounded-[3rem] text-muted-500 text-center px-10">
            <FileText size={64} className="mb-6 opacity-20" />
            <h3 className="font-syne text-2xl font-bold text-white mb-2 uppercase tracking-widest">No Results Found</h3>
            <p className="text-sm max-w-md">
              No results found for this exam type. Results will appear here once your school admin adds them.
            </p>
          </div>
        )}

      </main>
    </div>
  );
};

export default ParentReportCard;
