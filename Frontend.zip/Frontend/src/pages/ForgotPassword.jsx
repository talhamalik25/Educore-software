import { useState } from 'react'
import { Link } from 'react-router-dom'
import axiosInstance from '../api/axiosInstance'

const ForgotPassword = () => {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      await axiosInstance.post('/auth/forgot-password', { email })
      setSent(true)
    } catch (err) {
      setError(err.response?.data?.message || 'Something went wrong. Try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-muted-900 flex items-center justify-center px-4 relative overflow-hidden text-white">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary-900/20 blur-[120px] rounded-full -mr-48 -mt-48" />
      <div className="w-full max-w-md relative z-10 animate-fade-in">

        <div className="text-center mb-10">
          <h1 className="font-syne text-4xl font-bold bg-gradient-to-r from-white to-muted-400 bg-clip-text text-transparent tracking-tight">EduCore</h1>
          <p className="text-muted-500 mt-2 text-sm font-medium">Reset your password</p>
        </div>

        <div className="bg-muted-800 border border-muted-700 rounded-3xl p-8 md:p-10 shadow-2xl">
          {sent ? (
            <div className="text-center py-6">
              <div className="w-16 h-16 bg-primary-500/10 border border-primary-500/20 rounded-2xl flex items-center justify-center mx-auto mb-6 text-3xl">📧</div>
              <h2 className="font-syne text-2xl font-bold text-white mb-3">Check Your Email</h2>
              <p className="text-muted-400 text-sm leading-relaxed mb-8">If this email is registered, a reset link has been sent. Check your inbox (and spam folder).</p>
              <Link to="/login" className="text-primary-400 hover:text-primary-300 text-sm font-bold uppercase tracking-widest">← Back to Login</Link>
            </div>
          ) : (
            <>
              <h2 className="font-syne text-2xl font-bold text-white mb-2">Forgot Password?</h2>
              <p className="text-muted-400 text-sm mb-8">Enter your email and we'll send you a reset link.</p>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-xs font-bold text-muted-400 uppercase tracking-widest mb-2 ml-1">Email Address</label>
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    required
                    className="w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-4 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all"
                  />
                </div>

                {error && (
                  <div className="text-red-400 text-sm bg-red-500/5 border border-red-500/20 rounded-2xl px-5 py-4">{error}</div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-primary-500 hover:bg-primary-600 disabled:opacity-50 text-white font-bold py-4 rounded-2xl transition-all shadow-lg"
                >
                  {loading ? 'Sending...' : 'Send Reset Link'}
                </button>

                <div className="text-center">
                  <Link to="/login" className="text-muted-500 hover:text-white text-sm transition-colors">← Back to Login</Link>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export default ForgotPassword
