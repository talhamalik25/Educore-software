import { Link } from 'react-router-dom'
import LoginForm from '../../components/auth/LoginForm'

const SuperAdminLoginPage = () => {
  return (
    <div className="min-h-screen bg-[#0a0f0d] flex items-center justify-center p-4">
      <div className="w-full max-w-md animate-fade-in">
        
        {/* Logo & Portal Branding */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[#111a14] border border-[#1a2e2d] shadow-2xl mb-4">
            <svg className="w-8 h-8 text-[#dc2626]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
            </svg>
          </div>
          <h1 className="font-syne text-3xl font-bold text-white tracking-tight">EduCore OS</h1>
          <div className="mt-3 inline-flex items-center px-3 py-1 rounded-full bg-[#dc2626]/10 border border-[#dc2626]/20 text-[#dc2626] text-[10px] font-bold uppercase tracking-widest">
            Super Admin Portal
          </div>
        </div>

        {/* Card */}
        <div className="bg-[#111a14] border border-[#1a2e2d] rounded-[32px] p-8 md:p-10 shadow-[0_0_50px_rgba(0,0,0,0.5)]">
          <LoginForm role="superadmin" />
          
          <div className="mt-6 pt-6 border-t border-[#1a2e2d]">
            <p className="text-[#dc2626] text-xs font-bold text-center leading-relaxed px-4">
              ⚠ THIS PORTAL IS FOR PLATFORM ADMINISTRATORS ONLY. ALL ACTIONS ARE LOGGED and MONITORED.
            </p>
          </div>
        </div>

        {/* Back Link */}
        <div className="text-center mt-8">
          <Link 
            to="/login" 
            className="text-muted-500 hover:text-white transition-colors text-sm font-medium flex items-center justify-center gap-2 group"
          >
            <svg className="w-4 h-4 group-hover:-translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to User Login
          </Link>
        </div>

      </div>
    </div>
  )
}

export default SuperAdminLoginPage
