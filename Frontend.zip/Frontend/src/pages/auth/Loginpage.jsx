import { useState } from 'react'
import RoleSelector from '../../components/auth/RoleSelector'
import LoginForm from '../../components/auth/LoginForm'
import LoginLeftPanel from '../../components/auth/LoginLeftPanel'
import { motion, AnimatePresence } from 'framer-motion'
import { School } from 'lucide-react'

const LoginPage = () => {
  const [step, setStep] = useState(1)
  const [selectedRole, setSelectedRole] = useState(null)

  const handleRoleSelect = (roleId) => {
    setSelectedRole(roleId)
  }

  const handleContinue = () => {
    setStep(2)
  }

  const handleBack = () => {
    setStep(1)
  }

  return (
    <div className="min-h-screen bg-surface-base flex items-center justify-center p-4 relative overflow-hidden">
      
      {/* Background Glows */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-primary-600/10 blur-[120px] rounded-full -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-accent-purple/10 blur-[120px] rounded-full translate-x-1/2 translate-y-1/2" />

      <AnimatePresence mode="wait">
        {/* Step 1: Role Selection (Centered) */}
        {step === 1 && (
          <motion.div 
            key="step1"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            className="w-full max-w-xl relative z-10"
          >
            <div className="text-center mb-10">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-primary-600 shadow-glow mb-6">
                 <School className="text-white" size={36} strokeWidth={2.5} />
              </div>
              <h1 className="font-syne text-5xl font-bold text-white tracking-tighter mb-2">EduCore OS</h1>
              <p className="text-muted-500 font-bold uppercase tracking-widest text-[10px]">Universal Access Gateway</p>
            </div>
            
            <div className="bg-surface-elevated border border-surface-border rounded-[2.5rem] p-8 md:p-12 shadow-saas-heavy relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary-500/5 blur-3xl rounded-full" />
              <RoleSelector 
                selectedRole={selectedRole} 
                onSelect={handleRoleSelect} 
                onContinue={handleContinue} 
              />
            </div>
            
            <p className="text-center text-muted-600 text-[10px] mt-8 font-black uppercase tracking-[0.2em]">
              Authorized Use Only • Contact System Admin for Node Access
            </p>
          </motion.div>
        )}

        {/* Step 2: Login Form (Split Layout) */}
        {step === 2 && (
          <motion.div 
            key="step2"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="w-full max-w-6xl h-[85vh] bg-surface-elevated border border-surface-border rounded-[3rem] overflow-hidden shadow-saas-heavy flex relative z-10"
          >
            <LoginLeftPanel role={selectedRole} />
            <div className="flex-1 flex items-center justify-center p-8 md:p-16 overflow-y-auto bg-gradient-to-b from-transparent to-white/[0.02]">
              <LoginForm role={selectedRole} onBack={handleBack} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
    </div>
  )
}

export default LoginPage
