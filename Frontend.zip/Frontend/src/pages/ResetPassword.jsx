import { useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import axiosInstance from '../api/axiosInstance'

const ResetPassword = () => {
  const { token } = useParams()
  const navigate = useNavigate()
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    if (password !== confirm) return setError('Passwords do not match.')
    if (password.length < 6) return setError('Password must be at least 6 characters.')

    setLoading(true)
    try {
      await axiosInstance.post(`/auth/reset-password/${token}`, { password })
      setSuccess(true)
      setTimeout(() => navigate('/login'), 3000)
    } catch (err) {
      setError(err.response?.data?.message || 'Reset failed. Link may have expired.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-muted-900 flex items-center justify-center px-4 relative overflow-hidden text-white">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary-900/20 blur-[120px] rounded-full -mr-48 -mt-48" />
      <div className="w-full max-w-md relative z-10 animate-fade-in">

        <div className="text-center mb-10">
          <h1 className="font-syne text-4xl font-bold bg-gradient-to-r from-white to-muted-400 bg-clip-text text-transparent tracking-tight">EduCore</h1>
          <p className="text-muted-500 mt-2 text-sm font-medium">Set your new password</p>
        </div>

        <div className="bg-muted-800 border border-muted-700 rounded-3xl p-8 md:p-10 shadow-2xl">
          {success ? (
            <div className="text-center py-6">
              <div className="w-16 h-16 bg-green-500/10 border border-green-500/20 rounded-2xl flex items-center justify-center mx-auto mb-6 text-3xl">✅</div>
              <h2 className="font-syne text-2xl font-bold text-white mb-3">Password Updated!</h2>
              <p className="text-muted-400 text-sm mb-2">Redirecting you to login...</p>
            </div>
          ) : (
            <>
              <h2 className="font-syne text-2xl font-bold text-white mb-2">New Password</h2>
              <p className="text-muted-400 text-sm mb-8">Choose a strong password for your account.</p>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-xs font-bold text-muted-400 uppercase tracking-widest mb-2 ml-1">New Password</label>
                  <input
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Min. 6 characters"
                    required
                    className="w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-4 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-muted-400 uppercase tracking-widest mb-2 ml-1">Confirm Password</label>
                  <input
                    type="password"
                    value={confirm}
                    onChange={e => setConfirm(e.target.value)}
                    placeholder="Repeat password"
                    required
                    className="w-full bg-muted-900 border border-muted-700 rounded-2xl px-5 py-4 text-white placeholder-muted-600 focus:outline-none focus:border-primary-500 transition-all"
                  />
                </div>

                {error && (
                  <div className="text-red-400 text-sm bg-red-500/5 border border-red-500/20 rounded-2xl px-5 py-4">{error}</div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-primary-500 hover:bg-primary-600 disabled:opacity-50 text-white font-bold py-4 rounded-2xl transition-all shadow-lg"
                >
                  {loading ? 'Updating...' : 'Update Password'}
                </button>

                <div className="text-center">
                  <Link to="/login" className="text-muted-500 hover:text-white text-sm transition-colors">← Back to Login</Link>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export default ResetPassword
