import { initializeApp } from 'firebase/app' 
 import { getAuth, GoogleAuthProvider, signInWithPopup } from 'firebase/auth' 
  
 const firebaseConfig = { 
   apiKey: import.meta.env.VITE_FIREBASE_API_KEY, 
   authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN, 
   projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID, 
   storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET, 
   messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID, 
   appId: import.meta.env.VITE_FIREBASE_APP_ID, 
 } 
  
 const app = initializeApp(firebaseConfig) 
 export const auth = getAuth(app) 
 export const googleProvider = new GoogleAuthProvider() 
  
 export const signInWithGoogle = async () => { 
   const result = await signInWithPopup(auth, googleProvider) 
   const idToken = await result.user.getIdToken() 
   return { 
     idToken, 
     name: result.user.displayName, 
     email: result.user.email, 
     photoURL: result.user.photoURL, 
   } 
 } 
